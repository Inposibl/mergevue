# STAGE2_SUPPORTCLASS_EVALUABILITY_SEMANTIC_SEPARATION_1.CORR1 — METHODOLOGY CANDIDATE (CORRECTION)

- **Act:** MERGEVUE — STAGE-2 CORR4 PILOT — SUPPORTCLASS / EVALUABILITY SEMANTIC SEPARATION-1.CORR1
- **Actor:** Claude Opus 5.5
- **Role:** METHODOLOGY AUTHOR (assigned by the Owner for this act only)
- **Mode:** bounded methodology-candidate correction. Read-only except the three CORR1 outputs. No implementation, no data mutation, no Git.
- **Date:** 2026-10-05
- **Repository root:** `/Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)`
- **Branch / HEAD at act:** `main` / `2567223087d99b40bdfd174eed32566be7080e44`. Read-only Git inspection only (`GIT_OPTIONAL_LOCKS=0`).
- **Status:** AUTHOR CANDIDATE ONLY. `ownerAccepted = false`, `independentlyVerified = false`, `controlling = false`, `implemented = false`.
- **Next step:** a fresh, independent methodology IV by a non-Claude eligible verifier.

This document is the successor text to the parent candidate. Every corrected rule is restated here in full. Sections the parent carries unchanged are incorporated by reference to the hash-pinned parent (`3642de40…`); each such reference names the parent section:

- §3.3 evidence;
- §5 options table;
- the unchanged §7.3 rows;
- the unchanged §9.4 facets;
- the §10.3 table;
- SEP-FW-1..FW-18.

CORR1 corrects exactly IV1-F01..F05 and the IV1-A01 overclaim, and changes nothing else on purpose. It changes nothing in force today:

- The controlling Stage-2 methodology `cb08b51e…6c73` stays byte-intact and controlling.
- CASE-3.4 v1.3 `dae81438…e293ae39`, CASE-1, the parent package, the IV1 package and every historical artifact stay byte-intact.
- Nothing in this candidate, including Architecture C, is controlling because the Owner authorized this correction act.

Rule identifiers keep the parent's `SEP-` prefix. New or changed rules are marked **[CORR1]**.

---

## 0. REQUIRED SUMMARY (Owner task §21)

```text
PARENT_IV_VERDICT =
  FAIL

F01_EV_CLOSURE =
  CLOSED_CANDIDATE

EVALUABILITY_GATE_SET =
  COMPLETE_CANDIDATE
  (four gates, unchanged names; the gate set is complete relative to the enumerated
   authority routes of §7.5; no gate reads edgeState)

METHOD_DECLARED_NONASSESSABILITY_OBSERVABLE =
  YES
  (through the existing view-schema `abstention` declaration, restricted to the
   Non-Assessability Clause Registry SEP-NACR; edgeState is never read)

F02_UNIQUENESS_COMPLETENESS =
  CLOSED_CANDIDATE

UNIQUENESS_DENOMINATOR_PROOF =
  A per-fact selectionCensusWitness W(f) over all 74 frozen-registry Ms, bound to
  the registry identity and to the coder output, with mechanical closure:
    W-1 coverage       every registry M dispositioned exactly once (SELECTED / NOT_SELECTABLE);
    W-2 identity       same contract, vocabulary, coder output and factual package as the records;
    W-3 materialization every SELECTED M has SUPPORTS_LEAF records of f for all of its
                        registry-consuming TTs; no record exists for a NOT_SELECTABLE M;
    W-4 consistency    every co-entailment named in a directionalityTrace of f points to a
                        SELECTED M.
  DIRECT_SUPPORT only under SEP-U-0 / SEP-U-1 on a closed W(f).
  Otherwise SEP-U-X: HOLD-U (no unique classification).

FALSE_UNIQUE_FROM_MISSING_SIBLING =
  PREVENTED

F03_DE4_CLASSIFICATION =
  C

DE4_SUCCESSOR_POLICY =
  SEP-DE4 (Class C, NEW_SUCCESSOR_METHODOLOGY_PROPOSAL; Owner decision surface 3):
  for an admissible record with evidenceForm = DE-4, evaluability is computed first
  and DE-4 is never an evaluability reason; INDETERMINATE -> supportBearing = null;
  EVALUABLE -> supportBearing = NON_DISCRIMINATING in every direction, unless the
  C34 §6 constitutive-rule exception is AVAILABLE for the consuming TT through all
  four elements of its mandatory instance test (currently NOT AVAILABLE for every TT).
  C34 §6 does not compel this selector; it is a proposed successor policy.

F04_B3_DIRECTIONALITY =
  CLOSED_CANDIDATE

B3_COMPARATOR_UNIVERSE =
  Cmp+(r) = Cmp(M) ∪ Sel_other(f), where
  Cmp(M) = { M' ≠ M : Env(M') ≠ Env(M) ∧ ( Dset(M') ∩ Dset(M) ≠ ∅  [§D row D field, C-1]
                                           ∨ M' named in M's alt/counter cell or M in M''s ) }
  (frozen, registry-derived, published for all 74 Ms in the impact census), and
  Sel_other(f) = Ms of other Environments marked SELECTED in W(f).

B3_COMPONENT_CORRESPONDENCE =
  Co-entailment, never component-ID matching: component c of M corresponds to
  component c' of M' for record r iff the certified content that entails c (its
  recorded basis) also entails c' under M''s preciseMeaning (the H-3 / C34 §7.3
  entailment standard).

B3_JUDGMENT_TRACE =
  A directionalityTrace T(r) per (edge × consuming TT), stored as a companion record
  keyed by edgeId + treeTargetId, holding:
    the exact Cmp+(r) list;
    per supplied component: its basis, the MD-2 explicitNonMeaning result (clause
      quoted or NONE), and an MD-3 disposition for every comparator
      (NO_CO_ENTAILMENT / CO_ENTAILS c' / UNRESOLVED) with rationale;
    component and record verdicts; judgment flags; coder identity;
    the mechanically derived uniqueness basis.
  DIRECTIONAL requires one component with MD-2 NOT_TRIGGERED and NO_CO_ENTAILMENT
  against every comparator. An incomplete trace is HOLD-T and never DIRECTIONAL.

F05_MIG5 =
  CLOSED_CANDIDATE

LEGACY_ND_MECHANICAL_CARRY =
  Deleted as a universal rule. Legacy NON_DISCRIMINATING projects mechanically only if:
    SEP-MIG-5A  a successor cap fires on recorded states (B-1a under accepted SEP-DE4;
                B-1b only where the prohibited-criterion basis is recorded), or
    SEP-MIG-5B  successor nondirectionality is independently established from bound
                inputs (a B-2 counter record that mechanically fails lawful-counter
                conditions, or a complete successor directionalityTrace with a
                NON_DIRECTIONAL verdict).
  Otherwise SEP-MIG-5C: RECOMPUTE / FIELD-LOCAL RE-ADJUDICATION.
  Label agreement is never sufficient; the legacy value and provenance stay in the
  SEP-MIG-0 ledger.

PARTIAL_DIRECT_SUPPORT_CLASSIFICATION =
  C

ENVIRONMENT_OUTCOME_PRESERVATION =
  NOT_YET_PROVEN

A_E023_EVALUABILITY =
  EVALUABLE

A_E023_BEARING =
  NON_DISCRIMINATING
  (a candidate successor projection, conditional on Owner acceptance of SEP-DE4;
   not a controlling physical value)

A_E001_REQUIRES_READJUDICATION =
  YES

CONTROLLING_VIEW_MECHANICAL_PROJECTIONS =
  5   (conditional on Owner acceptance of SEP-DE4; under its option B: 0)

CONTROLLING_VIEW_READJUDICATION =
  1   (A-E001; under SEP-DE4 option B: 6 records require recomputation)

HISTORICAL_DATA_MUTATION_REQUIRED =
  NO

LOAD_BEARING_CLASS_D_RULES =
  0

READY_FOR_INDEPENDENT_IV =
  YES
```

Terminal state: **`STAGE2_SUPPORTCLASS_EVALUABILITY_SEMANTIC_SEPARATION_1_CORR1_READY_FOR_IV`**

---

## 1. IV1 CLOSURE MAP

| IV1 finding | Severity | Defect (IV1) | CORR1 correction | Where |
|---|---|---|---|---|
| IV1-F01 | BLOCKING | EV-3 read only `edgeState = NOT_DETERMINABLE`. H-7 leaves PARTIAL vs NOT_DETERMINABLE open for a record that has supplied components plus a method-declared non-assessable one, so CM-EV-1 passed every gate. | No EV gate reads edgeState. EV-3 reads the existing view-schema `abstention` declaration, restricted to the registry's closed clause list SEP-NACR (currently NACR-1 = M-RES-ASYMMETRIC-RETENTION c3). An NACR-domain record must carry an explicit clause disposition (SEP-AV-3). EV-2 now reads the ambiguity record instead of edgeState. The closure is restated relative to the enumerated authority routes. | §6.4, §7, §8 |
| IV1-F02 | BLOCKING | Dir(f) read whichever sibling records happened to exist; deleting a sibling turned SHARED into DIRECT. | Uniqueness may be emitted only on a closed per-fact `selectionCensusWitness` (W-1..W-4). Missing materialization or an invalid witness gives HOLD-U, never DIRECT_SUPPORT. The four required cases are distinguished (SEP-U-0/1/2/X), plus an unresolved-alternative case (SEP-U-3). | §6.5, §9.5 |
| IV1-F03 | BLOCKING | SEP-DE4, B-1a and SD-4 were labelled A/B; C34 §6 does not compel the EV-conditioned selector. | SEP-DE4, SEP-B-1a, SEP-SD-4, SEP-I-5 and the dependent MIG-5A/MIG-6a projections are reclassified **C**. Predecessor authority and the successor policy are separated. SEP-B-2 is split: A predicates, C partial counter bearing. | §9.2, §9.3, §10, §13, §21 |
| IV1-F04 | MAJOR | B-3's comparator, "corresponding component" and "materially different mechanism" were undefined; a mechanical full-supply shortcut was asserted. | Finite comparator universe Cmp⁺(r); correspondence by co-entailment; material-difference test MD-1..MD-3; mandatory directionalityTrace; explicit judgment boundary; fail-closed rule. The full-supply shortcut is deleted. explicitNonMeaning is a bounded negative test only. | §9.4 |
| IV1-F05 | MAJOR | MIG-5 carried every evaluable legacy ND as successor ND. | MIG-5 is replaced by MIG-5A/5B/5C. MIG-6b (mechanical carry of legacy DIRECT/SHARED) is deleted. All counts are recomputed, with the delta reported. | §14 |
| IV1-A01 | ADVISORY | Outcome neutrality was asserted. | ENVIRONMENT_OUTCOME_PRESERVATION = NOT_YET_PROVEN. O-1 is restated as a minimum future-consumer obligation with exact witness coupling. | §11 |

Everything not in this table is carried over from the parent with only cross-reference changes. That covers the Architecture C core, the four evaluability reasons, the four bearing values, SD-1, the field-level version boundary, no dual write, CASE-1 untouched and historical bytes immutable.

---

## 2. ROLE, SCOPE, INDEPENDENCE

**Role and authority.** The Owner's current instruction assigns METHODOLOGY AUTHOR for this act. It authorizes exactly three new artifacts in this directory. The analyst mandate (`AGENTS_A.md` `3c73d681…`) supplies read-only and source-classification discipline. The project quality skill (`skills/mergevue-agent-quality-gate/SKILL.md` `c80d3aa9…`) was applied in its bounded failure-correction mode, because the parent returned FAIL. It was used for evidence classification and adversarial self-testing only; no retrospective artifact was produced.

**Scope.** Correct F01–F05 and the A01 overclaim; nothing else. No A-E001 adjudication, no A-E023 physical change and no Environment work.

**Independence disclosure.**

- Claude authored the parent candidate and now authors this correction. Correcting one's own candidate after an independent FAIL is authoring, not verification.
- Claude also authored Final Measurement Regression CORRECTION-1 (successor view `3737bd5d…`, not accepted). That correction kept A-E023 = DIRECT_SUPPORT; the SEP-DE4 projection here would not keep it.
- Codex authored IV1. Codex authored no part of this candidate.

The fresh IV of CORR1 must be **non-Claude** (Codex or Z-Ai under AGENTS.md §10).

---

## 3. IDENTITY VERIFICATION AND AUTHORITY LEDGER

### 3.1 Parent and IV1 identities (independently recomputed this act)

| Artifact | SHA-256 | Bytes | Result |
|---|---|---:|---|
| Parent candidate | `3642de4054e2dcc11bce7182ce1266ba07753cf8d813a0cea32e4878a9dc2e8f` | 89381 | exact match |
| Parent impact census | `4b535753b3b5faabd993cace807c5c7ff6046d44796d07d5141832b20b9965ee` | 79393 | exact match |
| Parent manifest | `c5129eba7661141c21d0ae0750d490f373d2823f1ebdd539065909ee49340ecd` | 22147 | exact match |
| IV1 report | `5ec12b32f4bcb1f61d0aeda26ed4d9e0e00c95b35189f545e4babe3bfe7c399e` | 32421 | exact match |
| IV1 findings | `7db623a3b52deb7163ab3c3a100ea5f7c3e434d49dccbd4dc4d22c4b7a48cce6` | 46415 | exact match |
| IV1 manifest (read, not in the task's list) | `9344e617482eb8d7bcd891d1e9b9be0cda7fc698dd942591377d3ceb19f9cf41` | 87764 | inspected |

### 3.2 Evidence ledger (AGENTS.md §14A.2 form)

```text
ACT:  produce a corrected, standalone successor candidate that closes IV1-F01..F05
      and the A01 overclaim while preserving Architecture C.
ROLE: METHODOLOGY AUTHOR (Owner-assigned for this act).

READ (SHA-256 verified this act; full list in the manifest):
- AGENTS.md f1f34b93… ; AGENTS_A.md 3c73d681… ;
  MERGEVUE_CAUSALITY_PROOF_AND_AGENT_CONTROL.md 06770667… ; quality skill c80d3aa9…
- Control Tree v2.1 360bafa2… (.sha256 matches; no later full Tree found)
- Controlling Stage-2 methodology cb08b51e… (344754 B):
    §A.5–A.8 (l.160–191), TT-NTSTJ-RS (l.325–335), TT-SFPSFJ-RES/DOC (l.757–781),
    §C (l.794–905), §D (l.906–998), §E (l.1025–1042), §F (l.1107–1197),
    §G (l.1199–1208), §H (l.1210–1222), §I (l.1224–1226), §J (l.1228–1234), §L-4 (l.1286)
- CASE-3.4 v1.3 dae81438… : §6 (l.147–221; DE-4 default l.218–219; exception l.205;
  non-authority l.221), §7.3–§7.5 (l.254–290), §14 (l.517–525), §15 (l.533)
- CASE-1.CORR2.CORR2 3672c929… (52684 B) and CASE-1.CORR2.CORR2.CORR1 5c14b2aa…
  (54754 B), re-read in memory from Downloads/CASE-3.4.CORR2_BASELINE_SEAL_ORDER_CLAUDE_PACK.zip
  (a64ad01e…); both match the archive's 05_SHA256SUMS.txt.
  -> §13 (l.154–170), §14 (l.172–179), §22 (l.300–325)
- Coder view schema 0cb5a6b5… (git-tracked; bound by commit 2567223
  "docs: bind Stage2 pilot execution dependencies"): requiredCodingFields group
  "abstention" (groups[14])
- Field-source matrix 1fb84aed… (git-tracked, same commit): fields[23] supportClass,
  fields[46] abstention
- Controlling effective view a1fcae68… (6 SECTION_I_RECORD + 110 execution cells)
- Parent package and IV1 package (identities in §3.1)

DERIVED (mechanical; reproducible from the methodology bytes):
- 62 TT blocks; 40 EXACT documentary TTs; 74 §D M rows (8 PRES + 66 mechanism);
  74/74 consumed; 0 consumed by more than one Environment.
- SEP-NACR clause list = { NACR-1: M-RES-ASYMMETRIC-RETENTION c3 } — the only §D
  requiredComponents cell that declares NOT_DETERMINABLE / abstention.
- Cmp(M) for all 74 Ms (impact census registryFacts.b3ComparatorUniverse);
  10 Ms have Cmp(M) = ∅ (single-Environment D questions).

INSPECTED:
- root / branch main / HEAD 2567223 / 700 porcelain entries (-uall), all untracked,
  no tracked or staged diff, before the act.
- 2078 JSON/JSONL files under the parent census roots; 377 supportClass-bearing records.

ELIMINATED:
- "Is there an existing recorded input that observes method-declared non-assessability
   independently of edgeState?" — GATE 3: yes, the view-schema `abstention` field.
- "Does any artifact already hold a full-registry per-fact selection census?" — GATE 3: no
  (max 2 Ms per fact in any selection-bearing artifact; 0 NOT_SELECTABLE dispositions).
- "Does C34 §6 compel the EV-conditioned DE-4 selector?" — GATE 1: no (IV1-F03 accepted).

UNRESOLVED AFTER SEARCH (none blocks this candidate; all go to the future Owner frame, §20):
- acceptance of the Class-C choices (Architecture C package; direction-only bearing on
  incomplete content; the DE-4 ceiling).
```

### 3.3 Source-class discipline

| Class | Items |
|---|---|
| **OWNER FACT** | This act's role, scope, outputs, prohibitions and stop point. The fixed A-E023 inputs (F-M-0205; M-RES-CAPABILITY-ADVANTAGE; TT-NTSTJ-RS; PLAN; DE-4; FORMAL_ONLY; PARTIAL; [c2,c3,c4]; OPEN). The instruction to preserve A-E001 as re-adjudication. The parent and IV1 identities. |
| **METHODOLOGY FACT** | Controlling Stage-2 methodology text; CASE-3.4 v1.3 text. |
| **INCORPORATED AUTHORITY** | CASE-1 §13, §14, §15, §18, §22, incorporated through C34 §14 ("Reuse CASE-1") and Stage-2 §E. Preserved by CASE-1 CORR1 §5. |
| **PHYSICAL / SCHEMA FACT** | Hashes; record values; registry parse results; the view-schema `abstention` group and its mandatoryWhen list; matrix rows; witness/trace availability (0/0). |
| **PRIOR AGENT CLAIM** | IV1 conclusions, countermodels and counts, used as finding specifications, not as an oracle. Census "Option A for supportClass", known only from an agent report; IV1 did not recover the Owner text. **CORR1 does not use Option A as authority for any rule.** |
| **INFERENCE** | Every SEP rule (classified in §21). |
| **NOT DETERMINABLE** | Original intent behind C34 §6's disjunction and CASE-1 §13's overlap. Primary text of census Option A. Neither is relied on. |

The coder view schema carries its own historical status string ("AUTHOR CORRECTION CANDIDATE — NOT INDEPENDENTLY VERIFIED — NOT OWNER-ACCEPTED"). It was later bound to the repository as a pilot execution dependency (commit `2567223`). CORR1 relies on it only as the physical carrier of an existing recorded coder declaration. The methodological authority for the abstention itself is §G-7, §D l.997, §H-7 and §C (Class A).

---

## 4. THE SEMANTIC DEFECT (unchanged diagnosis; condensed)

supportClass fuses three questions:

1. **Evaluability:** can the edge-to-TT relation be read lawfully at all?
2. **Bearing:** does the entailed content point toward this TT, uniquely or not?
3. **Establishment:** through CASE-1's word "instantiates", is the mechanism established? Stage-2 §F.3 already computes this separately and never reads supportClass.

How the defect shows up:

- **The source rows overlap.** CASE-1 §13 defines NON-DISCRIMINATING as including "no authorized mapping" and NOT DETERMINABLE as "does not instantiate any usable discriminator".
- **No selector anywhere.** C34 §6 (l.218–219) and §7.5 (l.290) offer the overlapping pair with no selector, and CASE-1 §22 arrow 2 repeats the two-value failure consequence.
- **Coders worked blind, and nobody checked.** Pilot coders received class names only. The field is outside the measured surface R-01..R-13, so its divergences were never measured.

The parent's §3.3 evidence (seven items) is unchanged and not repeated here.

---

## 5. PRESERVED CORE (Owner task §3)

Preserved without change:

- **Architecture C.** Two axes and three successor fields on the §I record, recorded per (edge × consuming TT), the H-8 grain.
- **`bearingEvaluability`** ∈ {EVALUABLE, INDETERMINATE} (null when not applicable).
- **`bearingIndeterminacyReasons`** ⊆ {SOURCE_CONTENT_INACCESSIBLE, MECHANISM_READING_AMBIGUOUS, COMPONENT_NOT_ASSESSABLE, TARGET_BINDING_UNRESOLVED}, ordered by gate, non-empty iff INDETERMINATE.
- **`supportBearing`** ∈ {DIRECT_SUPPORT, DIRECT_CONTRADICTION, SHARED_NON_UNIQUE, NON_DISCRIMINATING}; null iff not EVALUABLE.
- **Legacy NOT_DETERMINABLE** stays outside the successor bearing vocabulary.
- **CASE-1 text** is physically unchanged; Stage-2 historical artifacts are immutable.
- **No dual write** of `supportClass` and `supportBearing`.

The options A/B/C minimality comparison of the parent §5 is unchanged; C stays selected. CORR1 adds companion inputs (§6.5–§6.6) and admission rules (§6.7) needed by F01, F02 and F04. These are bounded local refinements, not a redesign.

---

## 6. SUCCESSOR FIELD CONTRACT

### 6.1 Record fields (unchanged from parent)

| Field | Value space | Meaning |
|---|---|---|
| `bearingEvaluability` | `EVALUABLE` · `INDETERMINATE` · `null` | Whether the target-relative bearing of this edge can be lawfully assessed (§7). |
| `bearingIndeterminacyReasons` | ordered non-empty array · `null` | Every failing evaluability gate, in gate order (§8). |
| `supportBearing` | `DIRECT_SUPPORT` · `DIRECT_CONTRADICTION` · `SHARED_NON_UNIQUE` · `NON_DISCRIMINATING` · `null` | Directional / discriminating bearing of the entailed content relative to the consuming TT (§9). |

### 6.2 Grain (unchanged)

Per (edge, consuming TT). Legacy multi-TT rows are split by SEP-MIG-8.

### 6.3 Invariants [CORR1 where marked]

- **SEP-I-1** `bearingEvaluability = null` ⟺ `relevanceState ≠ ANALYTICAL_MAPPED` or the TT is not in `treeTargetIds[]`. In that case all three fields are null.
- **SEP-I-2** `bearingIndeterminacyReasons ≠ null` ⟺ INDETERMINATE. The array is non-empty, duplicate-free, ordered EV-1 → EV-4 and equal to the failing-gate set.
- **SEP-I-3** `supportBearing ≠ null` ⟺ EVALUABLE.
- **SEP-I-4** A successor record carries no `supportClass` key.
- **SEP-I-5** [CORR1 — Class C, conditional on SEP-DE4] `evidenceForm = DE-4` ∧ EVALUABLE ⇒ `NON_DISCRIMINATING`, while the C34 §6 exception is NOT AVAILABLE for the TT.
- **SEP-I-6** `DIRECT_CONTRADICTION` ⇒ `relation ∈ {NEGATES_LEAF, COUNTER_M}`. If NEGATES_LEAF, also `absenceEvidenceState = COMPETENT_AFFIRMATIVE_ABSENCE`.
- **SEP-I-7** [CORR1] `DIRECT_SUPPORT` or `SHARED_NON_UNIQUE` ⇒ `relation = SUPPORTS_LEAF` ∧ `componentSupply` non-empty ∧ T(r) complete with record verdict DIRECTIONAL.
- **SEP-I-8** [CORR1] `DIRECT_SUPPORT` ⇒ W(f) closed ∧ uniqueness basis ∈ {U-0, U-1}. `SHARED_NON_UNIQUE` ⇒ W(f) closed ∧ uniqueness basis ∈ {U-2, U-3}. The basis is recorded in T(r) (§6.6).
- **SEP-I-9** No successor field, `abstention` code, W(f) or T(r) is read by §F.3 or §F.5. targetState, leaf values and sufficiencyExpressionResult are computed exactly as today.
- **SEP-I-10** [CORR1] `bearingEvaluability` and its reasons are a function of (`sourceQualityState`, `ambiguity`, `abstention`, `mechanismPropositionIds`, `treeTargetIds`, bound registry) **only**. `edgeState` is not an argument.
- **SEP-I-11** [CORR1] A successor artifact that contains a held record (§6.7) is invalid and may not be materialized.

### 6.4 [CORR1] Use of the existing `abstention` declaration (F01)

**Existing input (PHYSICAL / SCHEMA FACT).** The frozen coder view schema defines a view-schema-only output field `abstention`. It is "an explicit coder statement that the required determination cannot lawfully be made from the available records, with the governing reason". It is mandatory under §G-7, §G-8, §H-7 and §G-1. The field-source matrix row (fields[46]) records it as CODER_JUDGMENT, not a §I field. Physical occurrence: every one of the 122 byte-deduplicated mapped historical records carries the key, as `null` (120) or `{"declared": false, "governingReason": null}` (2).

**Successor refinement (Class C).** On successor records, `abstention` carries zero or more declarations. Each declaration has:

- `code`, from the closed list below;
- `mechanismPropositionId` and `componentId`, where the code is component-level;
- `rationale` (text) and the supplying `factIds`.

| Code family | Meaning | Evaluability effect |
|---|---|---|
| `NACR-k` (one code per SEP-NACR clause) | The registry-declared trigger of clause k holds for the named component on this record's evidence (method-declared non-assessability). | EV-3 fails → COMPONENT_NOT_ASSESSABLE |
| `NACR-k:CONDITION_NOT_MET` | For an NACR-domain record: the clause trigger does not hold; the component is ordinarily missing (or supplied). | none |
| `SRC-INACCESSIBLE` (§G-1 entry of the mandatoryWhen list) | The source content is not inspectable for the proposition. | none by itself; must coincide with `sourceQualityState = CONTENT_INACCESSIBLE`, which fails EV-1 (SEP-AV-3) |
| `EST-CHAR` (§K), `EST-PLAN` (§E-P P-D5), `EST-SILENCE` (§J-3) | An establishment-side determination cannot be made. | none (SEP-FW-20) |

Any other declaration is an inadmissible abstention and holds the record (SEP-AV-3). That covers §G-8 inner-state claims on an edge, and §H-7 "component undocumentable" claims on a component that has no NACR clause.

**SEP-NACR — Non-Assessability Clause Registry (Class C rule over a Class B extraction).**

- **Definition.** A requiredComponent may be method-declared non-assessable only if its own §D registry row declares a mandatory-abstention / NOT_DETERMINABLE clause for that component.
- **Current list (mechanically extracted from §D).** Exactly one clause:
  - NACR-1 — M-RES-ASYMMETRIC-RETENTION c3.
  - Trigger: contribution and return channels identified, channels heterogeneous, and no LAWFUL comparison basis. A lawful basis is either (a) the participation system's own records valuing both sides in one common unit, or (b) a competent record that itself performs and states or arithmetically entails the comparison.
  - Authority: §D l.997; restated at TT-SFPSFJ-RES l.766, §C D-07 dispatch l.900, §G-7 l.1206 and §F.3 l.1121–1122.
- **Additions.** A new clause requires the §M registry route, exactly as E-R8 incompatibility pairs do. A coder never declares one ad hoc.

**Why this is not edgeState renamed.**

| Property | `edgeState` | NACR declaration |
|---|---|---|
| Grain | edge, one of seven values | component, naming the clause and the component |
| Value set | open H-7 precedence for mixed cases (OD-2) | closed, registry-keyed |
| Coexistence | single value | coexists with PARTIAL, NOT_DETERMINABLE or any other edgeState |
| What it carries | an establishment/coding summary consumed by §F.3 | only a non-assessability declaration, never consumed by §F.3 |
| Omission | undetectable in the mixed case | detectable on NACR-domain records (SEP-AV-3 requires an explicit clause disposition) |

**Precedence (component partition, per record).** Each requiredComponent c of the record's M is in exactly one of three states. Check them in this order; the first that applies wins:

1. **SUPPLIED:** c ∈ componentSupply.
2. **NON_ASSESSABLE:** an `NACR-k` declaration names c and the registry clause k is on c.
3. **MISSING:** every other c. It may also appear in missingComponents.

A NON_ASSESSABLE component may also remain listed in `missingComponents`. That keeps the §F.3 inputs unchanged.

### 6.5 [CORR1] Companion input: `selectionCensusWitness` W(f) (F02)

**What it records.** One witness per (coder output, fact f with ≥1 ANALYTICAL_MAPPED record). It records the H-2.2 duty that already exists ("census the entire frozen §D registry", l.1214), which today is not recorded anywhere (§18).

| Element | Content |
|---|---|
| identity | factId, side, caseId, factualPackageIdentity, contractIdentity / registry SHA-256, vocabularyVersion, coderIdentity |
| entries | one per registry M (74): `disposition ∈ {SELECTED, NOT_SELECTABLE}`; for SELECTED, the entailed componentIds |

**Closure (mechanical; all four must hold).**

- **W-1 coverage.** The entries are exactly the 74 M ids of the bound registry, each once.
- **W-2 identity.** contract, vocabulary, coder output and factual package equal those of f's records.
- **W-3 materialization.**
  - For every SELECTED M, there is a record r with f ∈ factIds, M ∈ mechanismPropositionIds and relation SUPPORTS_LEAF, whose treeTargetIds cover every registry-consuming TT of M. E-R7 competitors are included; their records are AMBIGUOUS.
  - For every NOT_SELECTABLE M, no SUPPORTS_LEAF record of f names M.
- **W-4 consistency.**
  - Every `CO_ENTAILS` disposition in any T(r) of f names an M that W(f) marks SELECTED.
  - Every componentSupply entry of f's records is consistent with the witness entry for its M.

**Boundary disclosed.** Closure proves the denominator was enumerated and materialized. It does not prove that each disposition is correct. Each SELECTED / NOT_SELECTABLE disposition is an H-2.2 entailment judgment like any other coding judgment, open to dual coding and IV. The guard removes silent absence: an alternative can now be excluded only by an explicit, auditable NOT_SELECTABLE assertion.

### 6.6 [CORR1] Companion input: `directionalityTrace` T(r) (F04)

One trace per record that reaches SEP-B-3 (§9.4). That is every uncapped SUPPORTS_LEAF record, and every COUNTER_M record under SEP-B-2(ii). It is keyed by `edgeId` + `treeTargetId` and stored as a companion record, not on the §I record. The trace has five parts; a record's trace is **complete** when T-1..T-4 hold.

- **T-1 universe.** The exact list Cmp⁺(r) = Cmp(M) ∪ Sel_other(f), with the registry identity. It is mechanically checkable against the published Cmp(M) table and W(f).
- **T-2 component entries.** For each supplied component c:
  - its basis (supplying factIds and the recorded entailmentBasis);
  - the MD-2 result (`TRIGGERED` with the explicitNonMeaning clause quoted, or `NOT_TRIGGERED`);
  - MD-3 dispositions.
- **T-3 verdict rules.**
  - A component is `DISTINGUISHING` iff MD-2 is NOT_TRIGGERED and every M′ ∈ Cmp⁺(r) carries `NO_CO_ENTAILMENT`.
  - A component is `NON_DISTINGUISHING` iff MD-2 is TRIGGERED, or at least one M′ carries `CO_ENTAILS c′` or `UNRESOLVED`. One witness suffices.
- **T-4 record verdict.**
  - `DIRECTIONAL` iff at least one component is DISTINGUISHING.
  - `NON_DIRECTIONAL` iff every supplied component is NON_DISTINGUISHING with a recorded witness.
  - Otherwise the trace is incomplete.
- **T-5 provenance.**
  - judgment flags per step and coderIdentity;
  - a mechanically derived `uniqueness` section with the basis U-0/U-1/U-2/U-3/U-X, the alternative list and each alternative's status.

### 6.7 [CORR1] Admission rules and holds (SEP-AV)

A hold is not a field value. A held record is not materializable. A successor artifact with any held record is invalid (SEP-I-11). In migration, a hold routes the record to RECOMPUTE / RE-ADJUDICATION, and the hold code is kept in the SEP-MIG-0 ledger.

| Rule | Condition | Hold code | Route |
|---|---|---|---|
| SEP-AV-1 | `edgeState = NOT_DETERMINABLE`, with no `sourceQualityState = CONTENT_INACCESSIBLE` and no `NACR-k` declaration | HOLD-ND | correction (unexplained NOT_DETERMINABLE) |
| SEP-AV-2 | `edgeState = AMBIGUOUS` while the ambiguity record has no unresolved competing M-ids, or the reverse | HOLD-AMB | correction (E-R7 record mismatch) |
| SEP-AV-3 | any of: an inadmissible abstention code; an NACR-domain record whose clause component is not supplied and that carries no explicit `NACR-k` or `NACR-k:CONDITION_NOT_MET` disposition; `SRC-INACCESSIBLE` without `sourceQualityState = CONTENT_INACCESSIBLE` | HOLD-NA | §L-4 DEFINITION_AMBIGUITY / §M registry route, or correction |
| SEP-AV-4 | the record needs SEP-B-3 and T(r) is absent, or fails T-1 or T-4 | HOLD-T | complete the trace |
| SEP-AV-5 | the record is DIRECTIONAL SUPPORTS_LEAF and W(f) fails W-1..W-4, or any alternative (§9.5) is held | HOLD-U | complete the census / materialization |

edgeState appears in AV-1 and AV-2 only as a consistency check. It never determines an evaluability outcome (SEP-I-10).

---

## 7. AXIS 1 — EVIDENTIAL BEARING EVALUABILITY (F01)

**Definition (unchanged).** The relation is EVALUABLE when every input needed to read the edge's entailed content against the consuming TT is lawfully available. It is INDETERMINATE when a recorded and admitted input inability prevents that reading. Evaluability never depends on what the bearing would turn out to be.

### 7.1 Gates [CORR1 where marked]

- **SEP-EV-0 Applicability.** `relevanceState = ANALYTICAL_MAPPED` and the TT ∈ `treeTargetIds[]`. Otherwise all three fields are null.
  - Upstream failures produce no edge: H-1 SEALED_FACT_MEMBERSHIP_FAILURE, NON_ANALYTICAL and UNMAPPED_OBSERVATION.
- **SEP-EV-1 SOURCE_CONTENT_INACCESSIBLE.** Fails iff `sourceQualityState = CONTENT_INACCESSIBLE`.
  - [Predicate A: §E sourceQualityState row; C34 §13.2 / §16.]
- **SEP-EV-2 MECHANISM_READING_AMBIGUOUS** [CORR1: keyed to the ambiguity record]. Fails iff the record's `ambiguity` names at least one competing M-id and its resolution state is not RESOLVED.
  - This is §F.5 E-R7: the fact fits registry-declared incompatible Ms (E-R8) and the text does not resolve which applies.
  - [Predicate A: E-R7, E-R8, H-4.]
  - edgeState AMBIGUOUS must agree with this; a mismatch is SEP-AV-2.
- **SEP-EV-3 COMPONENT_NOT_ASSESSABLE** [CORR1: keyed to the abstention declaration]. Fails iff the record carries an `NACR-k` declaration naming a component of the record's M that carries clause k and is not in componentSupply.
  - [Predicate A: §G-7; §D l.997; §F.3 l.1121–1122; view-schema `abstention` group. Restriction to SEP-NACR: C.]
- **SEP-EV-4 TARGET_BINDING_UNRESOLVED** (unchanged). Fails iff the registry route binding the edge's M to the consuming TT is not executable:
  - the TT verdict is not EXACT; or
  - its docStatus is not DOCUMENTARY_COMPLETE_CANDIDATE; or
  - the TT's mechExpr does not consume the M; or
  - an open §C.0 C-3 DISCRIMINATOR_SURFACE_INCONSISTENT condition lies on the connecting D route.
  - [Predicates A: §A.5, §A.6, §C.0.] A record-side binding error is a correction item, not INDETERMINATE.

### 7.2 Closure rule [CORR1]

**SEP-EV-C.** Two cases:

- an **admissible** record (it passes SEP-AV-1..AV-3) is EVALUABLE iff EV-1..EV-4 all pass;
- an **inadmissible** record is held and has no successor evaluability value.

### 7.3 H-7 invariance (the property IV1-F01 required)

**Claim.** For any record, EV-1..EV-4 and the admission result are invariant under the choice between `edgeState = PARTIAL` and `edgeState = NOT_DETERMINABLE` for the mixed case: some components supplied, and one component method-declared non-assessable.

**Proof.** EV-1..EV-4 read only `sourceQualityState`, `ambiguity`, `abstention`, M, TT and the registry (SEP-I-10). In the mixed case the record carries an `NACR-k` declaration whichever edgeState encoding is used, because SEP-AV-3 requires the explicit clause disposition on NACR-domain records. Under the NOT_DETERMINABLE encoding, SEP-AV-1 is satisfied by that declaration; under the PARTIAL encoding, SEP-AV-1 does not apply. Both encodings are therefore admissible and give the same INDETERMINATE result. If the coder omits the declaration, both encodings are held (HOLD-NA); neither becomes EVALUABLE. ∎

H-7 itself is **not** resolved globally. It remains an edgeState question (OD-2) that no longer affects this contract.

### 7.4 The four required F01 proofs (Owner task §5)

| # | Construction | Inputs | Result |
|---|---|---|---|
| 1 | ordinary PARTIAL, assessable missing component | M-RES-CAPABILITY-ADVANTAGE; c1 supplied; [c2,c3,c4] missing; `abstention = null`; the M carries no NACR clause, so no explicit disposition is required; source accessible; no ambiguity; route executable | admissible; EV-1..4 pass → **EVALUABLE** |
| 2 | PARTIAL plus a method-declared non-assessable component | M-RES-ASYMMETRIC-RETENTION; c1, c2 supplied; `abstention = {NACR-1, c3}`; edgeState PARTIAL (or NOT_DETERMINABLE) | admissible; EV-3 fails → **INDETERMINATE** [COMPONENT_NOT_ASSESSABLE]; bearing null |
| 2′ | as #2 with the declaration omitted | NACR-domain record, c3 unsupplied, `abstention = null` | **HOLD-NA** (SEP-AV-3). Never EVALUABLE. |
| 3 | SUPPORTED, full edge | every component supplied; `abstention = null`; source COMPETENT; no ambiguity; route executable | **EVALUABLE**. No gate can fail by accident: none reads edgeState, completeness or content. |
| 4 | source inaccessible | `sourceQualityState = CONTENT_INACCESSIBLE` (with or without `SRC-INACCESSIBLE`) | EV-1 fails → **INDETERMINATE** [SOURCE_CONTENT_INACCESSIBLE]; bearing null |

### 7.5 Completeness of the gate set (why the closure is a complete candidate)

A Python scan over methodology l.1–1300 found every place the controlling methodology recognizes an inability to determine something at edge level (terms: NOT_DETERMINABLE, abstention, undocumentable, UNOBS, notDeterminable, AMBIGUOUS). Each route maps as follows:

| Authority route (location) | Kind | Successor treatment |
|---|---|---|
| §E edgeState NOT_DETERMINABLE "source inaccessible" (l.1031); §C notDeterminableCondition (l.796); view-schema G-1 entry | input inability | EV-1 via sourceQualityState. A `SRC-INACCESSIBLE` declaration must coincide with it (AV-3). |
| §E edgeState NOT_DETERMINABLE "component undocumentable" (l.1031); §H-7 (l.1220); §C notDeterminableCondition | input inability, component-level | EV-3 if registered (NACR); otherwise HOLD-NA (AV-3) → §L-4 / §M |
| §D M-RES-ASYMMETRIC-RETENTION c3 (l.997, 766, 900); §G-7 (l.1206); §F.3 (l.1121) | input inability, registered | EV-3 [NACR-1] |
| §F.5 E-R7 AMBIGUOUS (l.1192); §C ambiguityCondition (l.796); H-7 AMBIGUOUS branch | input inability (reading) | EV-2 |
| §A.5 / §A.6 / §C.0 registry route | input inability (target side) | EV-4 |
| §G-8 UNOBS (l.1207; TT map entries l.205–788) | TT-level; mechExpr NONE; no edge | not reachable. An edge-level G-8 claim is HOLD-NA. |
| planCurrentState NOT_DETERMINABLE (§E-P P-D5, l.1081–1105) | establishment gate | no EV effect; non-meaning "intent ≠ implementation" (SEP-FW-6) |
| characteristicityState NOT_DETERMINABLE (§K, l.1240–1265) | establishment gate | no EV effect; "EXCEPTIONAL ≠ ABSENT; EPISODE_ONLY ≠ counter" (SEP-FW-20) |
| targetState TARGET_NOT_DETERMINABLE; notDeterminable leaves (§F.3, l.1148–1152) | derived target state | no feedback into per-edge EV (SEP-FW-4) |
| §J-3 DOCUMENTARY_SILENCE → GAP (l.1231) | no edge for silence | not reachable |
| scope / time / join / competence states (§E, §F.4, §G) | establishment gates | no EV effect (parent §7.2 non-meaning table, unchanged; SEP-FW-10, FW-18) |

Every recognized input inability lands in EV-1..EV-4 or in a hold. Every establishment-side indeterminacy has an authority non-meaning that keeps it out of evaluability. No route remains in which an input inability can silently pass all four gates.

The closure is **relative to SEP-NACR**. That is deliberate: method-declared component non-assessability is a registry property, and adding one goes through §M. The rule creates no generic UNKNOWN bucket.

### 7.6 Treatment of every condition in the Owner's original list (updated rows only)

| Condition | Successor treatment |
|---|---|
| method-declared non-assessable component | INDETERMINATE [COMPONENT_NOT_ASSESSABLE] via an `NACR-k` declaration, **independent of edgeState** (was: edgeState NOT_DETERMINABLE) |
| ambiguous fact meaning, registry-incompatible | INDETERMINATE [MECHANISM_READING_AMBIGUOUS] via the ambiguity record (was: edgeState AMBIGUOUS) |
| "component undocumentable" claimed for a component without an NACR clause | HOLD-NA; §L-4 DEFINITION_AMBIGUITY / §M registry route. Never silently EVALUABLE and never a generic INDETERMINATE. |
| insufficient authority to determine the bearing relation | B-3 disposition UNRESOLVED → non-distinguishing (burden rule, §9.4). A rule gap that prevents running B-3 at all is HOLD-T plus §L-4. |

All other rows of the parent §7.3 are unchanged: provenance and identity are upstream; scope, time and join stay EVALUABLE; a registry route failure is EV-4.

---

## 8. REASON TAXONOMY

Unchanged: four reasons, in gate order. CORR1 changes only the key of two of them.

| Reason | Gate | Keyed to |
|---|---|---|
| `SOURCE_CONTENT_INACCESSIBLE` | EV-1 | `sourceQualityState = CONTENT_INACCESSIBLE` |
| `MECHANISM_READING_AMBIGUOUS` | EV-2 | unresolved `ambiguity` record (competing M-ids) [CORR1] |
| `COMPONENT_NOT_ASSESSABLE` | EV-3 | `abstention` declaration with an `NACR-k` code [CORR1] |
| `TARGET_BINDING_UNRESOLVED` | EV-4 | registry route state |

The parent's dispositions of the Owner's candidate names are unchanged. That includes the rejection of OTHER_LAWFUL_REASON and AUTHORITY_UNDERSPECIFIED as generic buckets.

---

## 9. AXIS 2 — TARGET-RELATIVE SUPPORT BEARING

### 9.1 Basis (unchanged)

Bearing is computed over the edge's entailed content E(r): the supplied components of the selected M (a leaf of the consuming TT's mechExpr, or the counter M for a counter edge). Missing and non-assessable components contribute nothing. No hidden completion is allowed (C34 §7.4). Bearing is not establishment.

### 9.2 Procedure (ordered; first rule that fires decides; admissible EVALUABLE records only)

- **SEP-B-1a — DE-4 cap** [CORR1: **Class C**, conditional on Owner decision surface 3]. If `evidenceForm = DE-4` and the C34 §6 constitutive exception is NOT AVAILABLE for the TT → `NON_DISCRIMINATING`. See SEP-DE4 (§13).
- **SEP-B-1b — Prohibited-criterion cap** (Class A). If the edge's only basis is a criterion listed in the TT row's `prohib` → `NON_DISCRIMINATING`. [§F.3 l.1157.]
- **SEP-B-2 — Counter** [CORR1: Class C, built on Class A predicates]. If `relation ∈ {NEGATES_LEAF, COUNTER_M}`:
  - → `DIRECT_CONTRADICTION` iff:
    - (i) `NEGATES_LEAF` with `absenceEvidenceState = COMPETENT_AFFIRMATIVE_ABSENCE` at matched scope/time for a leaf M of the TT [A: §F.2(i), §J-2]; or
    - (ii) `COUNTER_M`, where the edge's M is a registry-listed incompatible counter of a leaf M of the TT, deciding the same organizational question at matched scope/time [A: §F.2(ii), E-R8, the alt/counter cell], **and** the counter content is DIRECTIONAL under SEP-B-3 applied to the counter M [C].
  - → otherwise `NON_DISCRIMINATING`. A NEGATES_LEAF record without competent affirmative absence is also routed to correction (J-2/J-6).
  - **Class C content.** A bearing `DIRECT_CONTRADICTION` may be recorded for directional counter content even where the counter M is not fully established, so the §F.3 `leafNeg(M)` condition (the counter M leafTrue) is not met. This is the counter analogue of direction-only DIRECT_SUPPORT (decision surface 2b). DIRECT_CONTRADICTION never by itself makes a leaf FALSE or CONFLICTED; only §F.3/§F.5 do that.
- **SEP-B-3 — Directionality** [CORR1: operationalized; Class C, §9.4]. Applies when `relation = SUPPORTS_LEAF` (and to counter content under B-2(ii)) → DIRECTIONAL, or NON_DIRECTIONAL → `NON_DISCRIMINATING`.
- **SEP-B-4 / SEP-U — Uniqueness** [CORR1: completeness-gated; Class C, §9.5]. DIRECTIONAL SUPPORTS_LEAF records only → `DIRECT_SUPPORT`, `SHARED_NON_UNIQUE`, or HOLD-U.

### 9.3 Completeness and mutual exclusivity

For an admissible EVALUABLE record, B-1a → B-1b → B-2 → B-3 → B-4 is an ordered decision list. Each step ends in exactly one value or one named hold:

- B-1 → ND;
- B-2 → CONTRA, ND, or HOLD-T;
- B-3 → ND, proceed to B-4, or HOLD-T;
- B-4 → DIRECT, SHARED, or HOLD-U.

The four values remain the complete evaluated-bearing vocabulary. A hold is a pipeline state, not a fifth value.

### 9.4 [CORR1] SEP-B-3 — directionality, operationalized (F04)

**B3-1 Comparator universe (finite; mechanical).**

- **Registry part.** Cmp(M) = { M′ ≠ M : Env(M′) ≠ Env(M) ∧ ( Dset(M′) ∩ Dset(M) ≠ ∅ ∨ M′ is named in M's alt/counter cell or M in M′'s ) }.
  - Dset is the §D row D field, the authoritative binding under C-1. The alt/counter cell carries the registry-declared same-question competitors, including the E-R8 pairs, which sit in different D families (M-ADJ-TEST-RESULT on D-02; M-AUTH-TOPDOWN-EXPLICIT on D-04).
  - Env is the Environment of the TTs whose mechExpr consumes the M (single-valued for 74/74 Ms).
  - The full Cmp(M) table for all 74 Ms is published in the impact census (`registryFacts.b3ComparatorUniverse.table`).
- **Record part.** Cmp⁺(r) = Cmp(M) ∪ Sel_other(f), where Sel_other(f) is the set of Ms of other Environments marked SELECTED in W(f). This catches co-entailment across D families for the fact at hand.

Why the universe is the D family plus declared competitors, and not "the same subquestion":

- **No subquestion equivalence is used anywhere.** One D can contain several dispatch subquestions (§C l.825–900), so the universe deliberately over-includes every M sharing any D route. A comparator answering a different subquestion simply yields `NO_CO_ENTAILMENT` when the content entails none of its components.
- **Over-inclusion is fail-closed.** Every extra comparator can only make a component non-distinguishing, never distinguishing.
- **Under-inclusion across D families is covered by Sel_other(f).** For 10 Ms the registry places no other-Environment mechanism on their D question (Cmp(M) = ∅; listed in the census). For them, MD-3 runs over Sel_other(f) only, and MD-2 still applies.

**B3-2 Component correspondence (co-entailment; never by ID).** Component IDs are local to their M (§I l.1225). For record r, component c of M corresponds to component c′ of M′ iff the recorded basis b(c) — the certified content that entails c — also entails c′ when read under M′'s preciseMeaning. The H-3 / C34 §7.3 standard applies: entailment, not resemblance, and no hidden completion. A correspondence is recorded as (M.c, M′.c′, basis). Nothing assumes c1 ↔ c1.

**B3-3 Material-difference test.** A comparator M′ ∈ Cmp⁺(r) is a materially different mechanism *for direction* because its consuming Environment differs from M's. Same-Environment mechanisms are excluded, because they cannot change the direction. For each supplied component c:

- **MD-1 Entailment.** c ∈ componentSupply, entailed by b(c) under M's preciseMeaning. This is the existing H-3 coder judgment, recorded in componentSupply / entailmentBasis.
- **MD-2 Bounded negative test.** If b(c)'s content falls under a clause of M's `explicitNonMeaning`, c is NON_DISTINGUISHING; the clause is quoted. explicitNonMeaning is a **sufficient negative check only**. Its silence never establishes distinguishing content, because it is not an exhaustive ontology (SEP-FW-23).
- **MD-3 Co-entailment test.** For every M′ ∈ Cmp⁺(r), record one disposition:
  - `NO_CO_ENTAILMENT`: b(c) entails no requiredComponent of M′;
  - `CO_ENTAILS c′`: b(c) entails c′;
  - `UNRESOLVED`: the coder cannot lawfully decide.
- **Evidence that suffices.** The certified fact content plus the registry texts of M and M′ (preciseMeaning, requiredComponents, explicitNonMeaning). Nothing else: no external knowledge, no resemblance, no completion.
- **Verdicts.** c is DISTINGUISHING iff MD-2 is NOT_TRIGGERED and every MD-3 disposition is `NO_CO_ENTAILMENT`. The record is DIRECTIONAL iff at least one supplied component is DISTINGUISHING.

**B3-4 Trace.** T(r), as specified in §6.6. It is mandatory for every record that reaches B-3 and sufficient for an independent coder to reproduce or contest each disposition.

**B3-5 Judgment boundary (disclosed, not disguised).**

| Step | Kind |
|---|---|
| Cmp(M) enumeration; Cmp⁺(r) assembly; disposition completeness; verdict aggregation; W-4 cross-check | **mechanical** |
| MD-1 (existing H-3 entailment); MD-2 (whether the content falls under a quoted clause); MD-3 (H-3 entailment against M′) | **human semantic judgment**, recorded with rationale. Permitted by CASE-1 §23 governed judgment and C34 §7.3–§7.5. |

No step of B-3 is presented as mechanical inference from component supply, from registry Environment binding, or from explicitNonMeaning silence.

**B3-6 Fail-closed rules.**

- An `UNRESOLVED` disposition makes the component NON_DISTINGUISHING (burden: directionality must be established by entailment).
- A record whose trace is incomplete is **HOLD-T**, never DIRECTIONAL. Incomplete means some component has neither a full NO_CO_ENTAILMENT set nor a non-distinguishing witness, or T-1 fails. This also covers a universe that cannot be enumerated (registry identity mismatch, M not in the registry).
- In migration, a legacy record with no trace → RECOMPUTE / RE-ADJUDICATION.
- DIRECT_SUPPORT is never emitted merely because one mechanism is fully supplied.

**B3-7 Deleted shortcuts.** The parent's "mechanical sufficient condition for DIRECTIONAL" (SUPPORTED ∧ componentSupply covers every requiredComponent) is **deleted**. A fully supplied M still needs a DISTINGUISHING component (SEP-FW-22). The parent's "mechanical sufficient condition for NON-DIRECTIONAL" is retained only as MD-2 and **reclassified as judgment**, because deciding that content "is" capex existence is a semantic judgment.

### 9.5 [CORR1] SEP-U — uniqueness with a proven denominator (F02)

**Inputs.** Record r (fact f, TT of Environment X), DIRECTIONAL and SUPPORTS_LEAF; W(f); and the S4/S6 outcomes of the alternatives.

**Alternatives.** Alt(r) = all SUPPORTS_LEAF records r′ of f in the same coder output with M′ SELECTED in W(f) and Env(M′) ≠ X. E-R7 AMBIGUOUS competitors are included. The status of each alternative's Environment is taken over its records:

- DIRECTIONAL, if any record of that M′ is EVALUABLE, uncapped and DIRECTIONAL;
- otherwise INDETERMINATE, if any record is INDETERMINATE;
- otherwise HELD, if any record is held;
- otherwise NON_DIRECTIONAL (capped or non-directional).

Counter-relation records are not alternatives; the counter M's own SUPPORTS_LEAF record is.

**Rules (ordered).**

| ID | Condition | Result | Recorded basis |
|---|---|---|---|
| **SEP-U-X** | W(f) fails W-1..W-4, or any alternative is HELD | **HOLD-U: no unique classification**; never DIRECT_SUPPORT | `INCOMPLETE_ENUMERATION` |
| **SEP-U-2** | at least one alternative is DIRECTIONAL | `SHARED_NON_UNIQUE` | `PROVEN_DIRECTIONAL_ALTERNATIVE` (lists them) |
| **SEP-U-3** | no alternative is DIRECTIONAL and at least one is INDETERMINATE | `SHARED_NON_UNIQUE` | `UNRESOLVED_ALTERNATIVE` (lists them) |
| **SEP-U-0** | Alt(r) = ∅ (zero lawful alternatives) | `DIRECT_SUPPORT` | `ZERO_ALTERNATIVES` |
| **SEP-U-1** | every alternative is NON_DIRECTIONAL (one lawful directional target: X) | `DIRECT_SUPPORT` | `SOLE_DIRECTIONAL_TARGET` |

**Authority.** The principle is Class A. CASE-1 §14 (l.176–179): a combination "may jointly become discriminating only if [it] uniquely separates one Environment from all applicable current-authority alternatives … The exclusion reasoning must be inspectable. Otherwise: FAIL CLOSED." C34 §7.5 adds "supports multiple options → SHARED", and H-2.2 sets the full-registry census duty. The witness, the closure checks, the rule table and the UNRESOLVED basis are Class C.

**Why U-3 gives SHARED and not a hold.** An INDETERMINATE alternative is a genuine evidence limit, not a correctable defect. A hold would be permanent. SHARED_NON_UNIQUE never separates downstream (CASE-1 §14–§15; O-1(g)), so emitting it for an unresolved alternative over-approximates the non-uniqueness set and can never create a false separation. The basis code keeps "proven" and "unresolved" non-uniqueness apart for any consumer.

**Why U-X is a hold and not SHARED.** Incomplete enumeration is a correctable violation of the H-2.2 duty. Mapping it to a plausible value would reward truncated output, which is the IV1-F02 defect.

**Forced-failure model (Owner task §6).** Same fact content, same registry; f entails directional content of M_X (Environment X) and M_Y (Environment Y).

| Variant | Result for the X record |
|---|---|
| Complete sibling set: W(f) closed, both records present, both DIRECTIONAL | U-2 → **SHARED_NON_UNIQUE** |
| Delete the Y record, W(f) unchanged (M_Y SELECTED) | W-3 fails → **HOLD-U** (not DIRECT) |
| Delete W(f), or break W-1/W-2 | **HOLD-U** (not DIRECT) |
| Y record present but its trace incomplete | the alternative is HELD → **HOLD-U** (not DIRECT) |
| Recode M_Y as NOT_SELECTABLE in W(f) and delete its record | a substantive, explicit and auditable entailment assertion, contestable by dual coding and IV. It is no longer silent absence (disclosed boundary, §6.5). |

**74 single-Environment Ms are not used as proof of single entailment.** Multi-M entailment (E-R6, H-4) is enumerated by W(f). The 74/74 fact only makes Env(M) single-valued.

### 9.6 Class definitions (updated facets only; all other facets as in the parent §9.4)

#### DIRECT_SUPPORT

- **Positive rule:** EVALUABLE ∧ admissible ∧ not capped ∧ `relation = SUPPORTS_LEAF` ∧ B-3 DIRECTIONAL (complete T(r)) ∧ SEP-U-0 or SEP-U-1 on a closed W(f).
- **Exclusion rule:**
  - DE-4 without the exception (under SEP-DE4);
  - PR-only basis;
  - a counter relation;
  - NON_DIRECTIONAL content;
  - a DIRECTIONAL or INDETERMINATE alternative of another Environment (→ SHARED);
  - an incomplete enumeration (→ HOLD-U);
  - any EV failure (→ null).
- **Nearest competing class:** SHARED_NON_UNIQUE, separated mechanically by SEP-U. Secondarily NON_DISCRIMINATING, separated by B-3 judgment recorded in T(r).
- **Required evidence relation:** at least one supplied component of a leaf M of the TT is DISTINGUISHING (MD-1..MD-3), and every other-Environment alternative of the fact is enumerated and resolved non-directional.
- **Effect of incomplete supply:** allowed. On PARTIAL/OPEN edges it asserts direction and proven uniqueness, not establishment (SD-2; Class C; decision surface 2).

#### SHARED_NON_UNIQUE

- **Positive rule:** EVALUABLE ∧ admissible ∧ not capped ∧ SUPPORTS_LEAF ∧ B-3 DIRECTIONAL ∧ SEP-U-2 or SEP-U-3 on a closed W(f).
- **Exclusion rule:**
  - mere compatibility or co-entailed generic content (→ ND via MD-3);
  - incomplete enumeration (→ HOLD-U);
  - multiple TTs of the same Environment;
  - incompleteness alone. PARTIAL is not SHARED; this supersedes the legacy SHARED-as-PARTIAL practice.
- **Relation to alternatives:** non-separating. The narrowing set {X} ∪ (directional alternatives) ∪ (unresolved alternatives) is a superset of the Environments to which the fact's content may point. It is lawful because W(f) is closed.

#### NON_DISCRIMINATING

- **Positive rule:** EVALUABLE ∧ admissible ∧ any one of:
  - B-1a (under SEP-DE4);
  - B-1b;
  - B-2 counter relation without lawful directional counter content;
  - B-3 NON_DIRECTIONAL with a complete witness for every supplied component.
- **Nearest competing class:** INDETERMINATE, separated mechanically by EV-1..EV-4 and the admission rules. It is never decided by judgment and never by edgeState.

#### DIRECT_CONTRADICTION

As in the parent, with SEP-B-2's split classification (§9.2).

---

## 10. CASE-1 RECONCILIATION AND SUPERSESSION DECLARATIONS (Stage-2 successor records only; CASE-1 and C34 texts unchanged)

All five declarations are **Class C**. Each is a proposed successor reading of the Stage-2 import, not a claim that CASE-1 or C34 compels it.

- **SEP-SD-1 — NOT DETERMINABLE partition** (unchanged substance). The value is removed from the bearing vocabulary.
  - Input inability → INDETERMINATE plus reasons. The cause is now keyed per §7.
  - Evaluable non-instantiation → NON_DISCRIMINATING, through a cap or a witnessed NON_DIRECTIONAL B-3 verdict.
  - The value remains readable on legacy records.
- **SEP-SD-2 — DIRECT SUPPORT = direction plus proven uniqueness, not establishment** [CORR1: Class C stated explicitly; Owner decision surface 2]. Neither CASE-1's "instantiates" nor C34 §§7.3–7.6 compels this decomposition.
  - **Reconstruction of legacy "instantiation".** Predecessor "instantiates an authorized discriminator of E" is recovered **only** as `supportBearing = DIRECT_SUPPORT` on record r for a TT of E through leaf M, **together with** a qualified establishment witness. The witness is an edge set S with leafTrue(M) under §F.3 such that:
    1. it is the same M/leaf;
    2. it has the same organizationalObjectRef and relationInstanceId as r's distinguishing basis;
    3. the claimed scope is bridged;
    4. the T0 temporal state is satisfied;
    5. S includes the fact(s) supplying r's DISTINGUISHING component, so the distinguishing content is part of what is established;
    6. it does not rely on an ANY_OF sibling;
    7. at determination time, CASE-1 §18 A–H hold.
  - Bearing alone never reconstructs instantiation.
- **SEP-SD-3 — SHARED / NON-UNIQUE** [CORR1]. SHARED means directional for X on a closed denominator but not proven unique, either because a directional alternative of another Environment is proven (U-2) or because an alternative is unresolved (U-3). It is the successor reading of CASE-1's "may narrow a set" and C34 §7.5's "supports multiple options".
- **SEP-SD-4 — C34 §6 DE-4 default** [CORR1: Class C; Owner decision surface 3]. The proposed successor reads the disjunction "`NON-DISCRIMINATING` or `NOT DETERMINABLE`" through evaluability: an EVALUABLE DE-4 record → ND; an INDETERMINATE one → null bearing with reasons.
  - C34 §6 establishes only the predecessor ceiling, the non-authority clause (l.221) and the NOT AVAILABLE exception. It does not supply this selector.
  - Census "Option A" is not used as authority for it.
- **SEP-SD-5 — NON-DISCRIMINATING mapping** (unchanged; Class C, with A components):
  - "no authorized mapping" → axes null (no edge);
  - "excluded option" → B-1b (A, §F.3);
  - "external-factor", "abstain", "no-such-event" → non-directional content (B-3).

The reconciliation table of the parent §10.3 is unchanged, except that its DE-4 and §7.5 rows now point to SEP-DE4 (Class C) and SEP-U.

---

## 11. ENVIRONMENT-OUTCOME PRESERVATION AND O-1 (A01)

**ENVIRONMENT_OUTCOME_PRESERVATION = NOT_YET_PROVEN.**

**What is a present fact.** No current Stage-2 equation reads supportClass or any successor field. §F.3 / §F.5 do not read them (Final Regression 1 records `outputUse = false`; SEP-I-9). This candidate therefore changes no current computation and assigns no Environment.

**What is not proven.** That a future Environment-determination consumer (HEDC, not authored) produces the same determinations under the successor fields as it would under any predecessor reading. The parent's statements "SD-1, SD-4, SD-5 are outcome-neutral" and "recomputation of DE-4 + DIRECT records to ND is outcome-neutral" are **withdrawn as proofs**. They remain plausibility arguments only.

**O-1 — minimum future-consumer obligation (Class C; nothing is authored here).** A future HEDC may read the successor fields only under all of:

- **O-1(a)** Bearing never establishes. No leaf, target or Environment state is derived from `supportBearing` alone.
- **O-1(b)** A DIRECT_SUPPORT or SHARED_NON_UNIQUE record may contribute to separation only when coupled to a **qualified establishing witness** that refers to the same:
  - M/leaf;
  - organizational object (organizationalObjectRef / relationInstanceId);
  - claimed scope (bridged);
  - time (T0 state);
  - lawful relation instance (§F.4.1).

  The witness's establishing edge set must include the fact(s) supplying the record's DISTINGUISHING component (SD-2 reconstruction, conditions 1–7).
- **O-1(c)** A completed ANY_OF sibling never establishes another, partial branch's distinguishing content.
- **O-1(d)** DIRECT_CONTRADICTION may contribute only with the corresponding lawful negative or counter establishment:
  - NEG(M) by COMPETENT_AFFIRMATIVE_ABSENCE (J-2), or the counter M leafTrue (§F.3 leafNeg);
  - on the actual incompatible question, at matched scope/time;
  - with needed-leaf precedence preserved (E-R9/E-R10).
- **O-1(e)** srcDiv, PRES-lane non-consumability, actual-alternative exclusion, contradiction review (C34 §7.7) and CASE-1 §18 A–H are preserved.
- **O-1(f)** INDETERMINATE and held records are non-establishing, non-separating and non-contradicting.
- **O-1(g)** SHARED_NON_UNIQUE never separates, whatever its basis.
- **O-1(h)** Legacy supportClass may be read only through the SEP-MIG adapter.
- **O-1(i)** Partial directional bearing alone is non-sufficient for Environment determination.

This act defines no Environment resolution.

---

## 12. EVALUATION ORDER — STATE MACHINE [CORR1]

```text
S0  INPUT    record r at (edge × consuming TT); bound registry R (TT/M/D rows, E-R8,
             PR rows, C-3 status, SEP-NACR, Cmp table); coder output K; W(f); T(r);
             r.abstention.
S1  APPLY    SEP-EV-0. Not applicable → emit (null, null, null); STOP.
S2  ADMIT-A  SEP-AV-1..AV-3 (record-level consistency: edgeState vs cause / ambiguity;
             abstention codes; NACR disposition). Fail → HOLD (ND/AMB/NA); STOP.
S3  GATES    F := [g ∈ EV-1..EV-4 | g fails]. Reads ONLY sourceQualityState, ambiguity,
             abstention, M, TT, R. Reads no edgeState, no bearing output, no W(f), no T(r).
S4  INDET    F ≠ ∅ → emit (INDETERMINATE, F, null); STOP.
S5  EVAL     bearingEvaluability := EVALUABLE; reasons := null.
S6  PASS-1   B-1a → ND | B-1b → ND | B-2 → CONTRA / ND / HOLD-T
             | B-3 → DIRECTIONAL / ND / HOLD-T.
             Reads S5, r.evidenceForm, r.relation, r.absenceEvidenceState,
             r.componentSupply, T(r), R, and W(f) (for Sel_other(f) only).
S7  PASS-2   DIRECTIONAL SUPPORTS_LEAF records only: SEP-AV-5 / SEP-U over W(f) and the
             S4/S6 outcomes of Alt(r) → DIRECT / SHARED / HOLD-U.
S8  OUTPUT   (bearingEvaluability, bearingIndeterminacyReasons, supportBearing); the
             uniqueness basis is written into T(r).
             §F.3/§F.5 run unchanged and read none of this (SEP-I-9). Consumers are
             bound by O-1.
```

**Non-circularity.** The dependency graph is S2 → S3 → S6 → S7. W(f), T(r) and `abstention` are coder-produced **inputs**: none is derived from a bearing output.

- S3 reads inputs only.
- S6 reads S5 and inputs.
- S7 reads S6 outcomes of *other* records plus W(f).
- The cross-checks W-4 ↔ T-1 compare two inputs and feed no gate.

There is no S7 → S6 or S6 → S3 edge, and no bearing → evaluability edge. IV1 CM-ORDER-1 is preserved.

**Determinism map.**

| Step | Kind |
|---|---|
| S1–S5 | mechanical, given recorded inputs. The `NACR-k` declaration itself is a recorded coder judgment under a registry clause. |
| B-1a | mechanical (rule Class C) |
| B-1b | existing PR-basis judgment (A) |
| B-2 | mechanical on relation, absence and registry, plus B-3 on counter content |
| B-3 | traced human judgment (MD-1..MD-3) with mechanical aggregation and completeness checks |
| S7 | mechanical, given W(f) and alternatives' outcomes |

---

## 13. SEP-DE4 — DE-4 SUCCESSOR POLICY [CORR1: Class C — NEW_SUCCESSOR_METHODOLOGY_PROPOSAL]

### 13.1 Predecessor authority (Class A; unchanged by this act)

- **Ceiling.** C34 §6 DE-4 default "`NON-DISCRIMINATING` or `NOT DETERMINABLE`" (l.218–219), with no selector.
- **Non-authority.** "DE-4 cannot become behavioral authority merely because it resembles an Environment description" (l.221). C34 §7.3 forbids `central board → NT/STJ`.
- **Constitutive exception.** Structure unchanged and status NOT AVAILABLE (C34 §6 l.205; Stage-2 §A.8 l.191), version-bound to `questionnaires.json` `b8b36cc2…`.
- **Establishment.** §E: "DE-4 cannot establish an OP mechanism; it may establish a PRES object or FORMAL_ONLY".

### 13.2 Proposed successor policy (Class C)

> **SEP-DE4.** For an admissible Section-I record at (edge × consuming TT) grain with `evidenceForm = DE-4`:
>
> **(1)** `bearingEvaluability` is determined by SEP-EV-0..EV-4 exactly as for any record. DE-4 is never an evaluability reason and never by itself produces INDETERMINATE.
>
> **(2)** INDETERMINATE → `supportBearing = null`, with reasons.
>
> **(3)** EVALUABLE → `supportBearing = NON_DISCRIMINATING`, unless the C34 §6 constitutive-rule exception is AVAILABLE for the consuming TT. AVAILABLE requires all four elements of the §6 mandatory instance test:
>    1. an exact current anchor named;
>    2. its load-bearing mechanism shown to be constitutive/formal;
>    3. direct entailment by the formal fact without added behavioral implementation;
>    4. independent verification of the anchor's constitutive status before load-bearing use.
>
> **(4)** The cap binds in every direction. Absent the exception, a DE-4 record carries no DIRECT_SUPPORT, SHARED_NON_UNIQUE or DIRECT_CONTRADICTION.
>
> **(5)** The cap concerns the bearing axis only. It sets or alters no edgeState, formalOperativeState, planCurrentState, characteristicityState, leaf value, sufficiencyExpressionResult or targetState. It is neither implied by nor implies FORMAL_ONLY or PLAN.
>
> **(6)** Under the cap, a DE-4 record needs no T(r) and no W(f): B-3 and SEP-U are not reached.

### 13.3 Why this is C, not B (IV1-F03 accepted)

Once Architecture C separates direction from establishment, a second coherent successor policy exists: DE-4 content keeps a computed directional bearing while remaining categorically non-establishing through §F.3 (FO-OP, the DE-4 establishment clause) and O-1. C34 §6 does not decide between the cap and that policy. Choosing the cap is a normative act for the Owner (decision surface 3).

**Constitutive-exception status:** preserved, NOT AVAILABLE.

**PRES-target boundary (OD-1, DEFERRED):** under the cap, DE-4 records on FO-PRES targets are also ND. Current incidence: 0.

---

## 14. NOT_DETERMINABLE / LEGACY MIGRATION [CORR1]

### 14.1 Determinations (unchanged)

- NOT_DETERMINABLE ceases to be a bearing class.
- Its input-inability share becomes INDETERMINATE with a mandatory reason.
- It is migrated mechanically only where the record itself proves the cause.

### 14.2 Migration rules (projection only; never a write into a legacy artifact)

| ID | Legacy condition | Successor projection | Kind | Class |
|---|---|---|---|---|
| SEP-MIG-0 | any | No legacy artifact is rewritten. Projections exist only in a new, separately authorized successor artifact, with a per-record ledger holding: legacy value and provenance, successor triple, rule ID, hold code if any, inputs read, registry and contract identity. | rule | C |
| SEP-MIG-1 | `relevanceState ≠ ANALYTICAL_MAPPED` | (null, null, null) | MECHANICAL | C |
| SEP-MIG-2 [CORR1] | any ANALYTICAL_MAPPED record | EV recomputed from the record's own states: see the EV-3 bullets below this table. Admission defects → RECOMPUTE. | MECHANICAL where stated | C |
| SEP-MIG-3 | legacy NOT_DETERMINABLE ∧ ≥1 EV gate fails mechanically | (INDETERMINATE, failing gates, null) | MECHANICAL (cause proven by the record) | C |
| SEP-MIG-4 [CORR1] | legacy NOT_DETERMINABLE ∧ EVALUABLE | Bearing by S6–S7. MECHANICAL only if B-1a fires (conditional on SEP-DE4) or B-2 fails mechanically on recorded counter states. Otherwise RECOMPUTE / RE-ADJUDICATION; DIRECT or SHARED additionally need T(r) and W(f). The legacy label is never carried. | mixed | C |
| ~~SEP-MIG-5~~ | ~~legacy ND ∧ EVALUABLE → ND~~ | **DELETED** (IV1-F05) | — | — |
| SEP-MIG-5A [CORR1] | legacy ND ∧ EVALUABLE ∧ a successor cap fires on recorded states | (EVALUABLE, null, NON_DISCRIMINATING), legacy value retained in the ledger. The cap is B-1a, conditional on SEP-DE4, or B-1b only where the PR basis is recorded (no legacy field records it). | MECHANICAL (conditional) | C |
| SEP-MIG-5B [CORR1] | legacy ND ∧ EVALUABLE ∧ successor nondirectionality independently established from bound inputs | (EVALUABLE, null, NON_DISCRIMINATING). Two ways to establish it: a B-2 counter record that mechanically fails lawful-counter conditions (e.g. NEGATES_LEAF without COMPETENT_AFFIRMATIVE_ABSENCE), or a complete successor T(r) with a NON_DIRECTIONAL verdict. | MECHANICAL | C |
| SEP-MIG-5C [CORR1] | legacy ND ∧ EVALUABLE ∧ neither 5A nor 5B | **RECOMPUTE / FIELD-LOCAL RE-ADJUDICATION**. Label agreement is insufficient. | judgment | C |
| SEP-MIG-6a | legacy DIRECT / SHARED / CONTRA ∧ EVALUABLE ∧ cap fires | (EVALUABLE, null, NON_DISCRIMINATING); value change | MECHANICAL (conditional on SEP-DE4 for B-1a) | C |
| ~~SEP-MIG-6b~~ | ~~mechanical carry of DIRECT / SHARED / CONTRA~~ | **DELETED** (inherited the deleted B-3 shortcut and the B-4 completeness defect) | — | — |
| SEP-MIG-6c | legacy DIRECT / SHARED / CONTRA ∧ EVALUABLE ∧ no cap | **RECOMPUTE / RE-ADJUDICATION** (needs T(r), and W(f) for DIRECT/SHARED) | judgment | C |
| SEP-MIG-7 | any other legacy label ∧ ≥1 EV gate fails | (INDETERMINATE, failing gates, null); legacy label in the ledger only | MECHANICAL | C |
| SEP-MIG-8 | legacy multi-TT row | split per TT; then MIG-1..7 per copy | MECHANICAL | C |

How SEP-MIG-2 recomputes EV-3 from a legacy record:

- **No NACR clause on the M:** EV-3 is a mechanical PASS when the legacy `abstention` is null, `declared:false`, or declares only an establishment-side reason.
- **NACR clause on the M, clause component unsupplied:** EV-3 is mechanical only if the legacy declaration cites §G-7 or the clause. Otherwise RECOMPUTE.
- **EV-1, EV-2, EV-4:** mechanical from recorded states and the registry.

### 14.3 Counts (fresh census; physical facts; byte-deduplicated where stated)

**Controlling effective view `a1fcae68…`.** 6 SECTION_I_RECORD rows (lines 111–116) plus 110 execution cells, 4 of which mirror supportClass. Legacy NOT_DETERMINABLE: **0**.

EV: **6/6 EVALUABLE mechanically.**

- Every `abstention` is null.
- No M carries an NACR clause.
- No ambiguity record names competing M-ids.
- Every TT is EXACT, DOCUMENTARY_COMPLETE_CANDIDATE and consumes its M.
- 0 admission defects.

| Record | evidenceForm | Legacy | CORR1 candidate projection | Rule | Kind |
|---|---|---|---|---|---|
| A-EXEC1:F-B-0025 × TT-STPSTJ-RS | DE-4 | DIRECT_SUPPORT | **NON_DISCRIMINATING** | B-1a / MIG-6a | mechanical, conditional on SEP-DE4; value change |
| A-EXEC1:F0024 × TT-STPSTJ-RS | DE-4 | DIRECT_SUPPORT | **NON_DISCRIMINATING** | B-1a / MIG-6a | mechanical, conditional; value change |
| A-RERUN1-CORR1:F-E-0182 × TT-STPSTJ-ESS | DE-4 | NON_DISCRIMINATING | NON_DISCRIMINATING | B-1a / **MIG-5A** (was MIG-5) | mechanical, conditional; preserved |
| A-RERUN1-CORR1:F-E-0182 × TT-STPSTJ-PW | DE-4 | NON_DISCRIMINATING | NON_DISCRIMINATING | B-1a / **MIG-5A** (was MIG-5) | mechanical, conditional; preserved |
| A-E023 × TT-NTSTJ-RS | DE-4 | DIRECT_SUPPORT | **NON_DISCRIMINATING** | B-1a / MIG-6a | mechanical, conditional; value change |
| A-E001 × TT-STJSTP-PW | DE-1 | DIRECT_SUPPORT | not assigned | MIG-6c | **RE-ADJUDICATION** (not adjudicated here) |

Totals: **5 mechanical** (3 value changes, 2 preserved) and **1 re-adjudication**. The count delta against the parent is **0**. The rule-basis delta is two rows, MIG-5 → MIG-5A, and all five mechanical rows are now conditional on SEP-DE4. Under SEP-DE4 option B, all 6 records require recomputation: no T(r) or W(f) exists.

**A-E001 (§17).**

- Physical inconsistency preserved: `edgeState = SUPPORTED`, `missingComponents = []`, but componentSupply holds only c1 of M-ENFORCE-SANCTION {c1, c2}.
- B-1b is not recorded. B-3 needs a trace and B-4 needs a witness; neither exists.
- **A_E001_REQUIRES_READJUDICATION = YES.**

**Historical lineage.** Fresh walk: 2078 JSON/JSONL files, 377 supportClass-bearing record objects. That is 145 mapped path-level and 122 byte-deduplicated mapped records; IV/audit quotations and homonyms are excluded.

EV under CORR1:

- 0 gate failures; 0 admission defects.
- 0 records on an NACR-domain M; 0 legacy edgeState NOT_DETERMINABLE or AMBIGUOUS.
- `abstention`: 120 null, 2 `declared:false`.

Witness and trace availability: 0 facts with a full-registry selection census; 0 records with a directionality trace.

| Legacy (mapped, byte-dedup) | DE-4 | non-DE-4 | CORR1 routing |
|---|---:|---:|---|
| NON_DISCRIMINATING | 47 | **6** | DE-4 → MIG-5A (conditional); non-DE-4 → **MIG-5C RECOMPUTE / RE-ADJUDICATION** |
| DIRECT_SUPPORT | 16 | 21 | DE-4 → MIG-6a (conditional); non-DE-4 → MIG-6c |
| SHARED_NON_UNIQUE | 5 | 18 | DE-4 → MIG-6a (conditional); non-DE-4 → MIG-6c |
| NOT_DETERMINABLE | 0 | 9 | MIG-4 → RECOMPUTE / RE-ADJUDICATION |
| DIRECT_CONTRADICTION | 0 | 0 | — |
| **Total 122** | **68** mechanical-conditional | **54** recompute | |

**Legacy NOT_DETERMINABLE** (unchanged counts):

- **5** distinct identities: A-E001, A-E003, A-E019, A-E020, A-E023;
- **9** byte-deduplicated occurrences in **3** distinct byte artifacts (`f3994235…` ×5, `200790d5…` ×2, `6b8a37ea…` ×2);
- **11** path-level occurrences on **4** paths.

Mechanically migratable: **0**. Re-adjudication applies on re-activation only. A-E003, A-E019 and A-E020 were collapsed to UNMAPPED by B1 (adoption ledger L-168, L-078); their successor axes would be null.

**Delta versus the parent census (F05 recomputation).**

- **6** mapped non-DE-4 legacy ND occurrences. Under the parent's MIG-5 they were mechanical; under CORR1 they are **RECOMPUTE / RE-ADJUDICATION**. The occurrences:
  - `2aed2bc7…` RD-01 rerun A, DE-1: F-E-0182 × M-RECOGNISED-COMMAND-ORDER × ESS / PW;
  - `bad9ea8b…` rerun-CORR1 A, DE-3: C-B04 × M-PARTICIPATION-ARCHITECTURE-CONTROL × CTRL / DOC, and C-B04 × M-RECOGNISED-COMMAND-ORDER × ESS / PW.
  - None is in the controlling view.
- **7** non-DE-4 full-supply legacy DIRECT_SUPPORT occurrences, all in the C-B04 × M-ENFORCE-SANCTION lineage across 7 byte artifacts. They met the deleted MIG-6b shortcut and now route to MIG-6c.
- Historical consumer entries newly flagged RE-ADJUDICATION_REQUIRED (on re-activation): HD-02, HD-04, HD-09, HD-12, HD-14, HD-15, HD-16, HD-17. All stay immutable (census JSON).

HISTORICAL_DATA_MUTATION_REQUIRED = **NO**.

---

## 15. BACKWARD COMPATIBILITY

- **SEP-BC-1 Legacy read semantics** (unchanged). Records carrying `supportClass` are read under the predecessor §E import and their own contract identity.
- **SEP-BC-2 Successor write semantics** [CORR1]. Successor records write the three SEP fields, an `abstention` value under §6.4's codes and, where required, companion W(f) and T(r). They never write `supportClass`.
- **SEP-BC-3 Deprecation** (unchanged). `supportClass` is deprecated for writing. `NOT_DETERMINABLE` is deprecated as a bearing value only.
- **SEP-BC-4 Nullability** (unchanged; the parent's current-lineage nullability facts stand). Every current-lineage file walked carries the `abstention` key.
- **SEP-BC-5 New surfaces** [CORR1, replaces the parent BC-5]:
  - exactly three new record fields;
  - a closed code list for the existing `abstention` field;
  - two companion artifacts, W(f) per fact and T(r) per (edge × TT).
  - No score, weight or rationale field is added to the §I record.
- **SEP-BC-6 Byte preservation** (unchanged). The adapter is read-only. Historical data mutation required: NO.
- **SEP-BC-7 Predecessor intact** [CORR1: wider insertion list]. Adoption would use a new successor text that preserves `cb08b51e…` and inserts or replaces:
  - the §E supportClass row and the H-8 sentence;
  - the §I field list and the §F.3 PR-* wording;
  - a FW-3 addendum;
  - the SEP-NACR / SEP-AV / SEP-U / W / T sections.

  The controlling view `a1fcae68…` stays controlling until a separately authorized successor view is verified and accepted.
- **SEP-BC-8 Mixed-version guard** (unchanged). No consumer combines `supportClass` and `supportBearing` without SEP-MIG.

---

## 16. A-E023 — WORKED EXAMPLE (validation only; not a rule source) [CORR1]

**Fixed accepted inputs (Owner).** factId F-M-0205; M-RES-CAPABILITY-ADVANTAGE; TT-NTSTJ-RS; planCurrentState PLAN; evidenceForm DE-4; formalOperativeState FORMAL_ONLY; edgeState PARTIAL; missingComponents [c2, c3, c4]; sufficiencyExpressionResult OPEN.

**Certified content.** Sealed coder input: a planned $2.5 billion expansion of a jointly owned petrochemical complex, "to be completed in 2000".

### 16.1 Admission and evaluability

| Step | Input read | Result |
|---|---|---|
| EV-0 | ANALYTICAL_MAPPED; TT-NTSTJ-RS ∈ treeTargetIds | applicable |
| AV-1 | edgeState PARTIAL (fixed); not NOT_DETERMINABLE | n/a |
| AV-2 | edgeState not AMBIGUOUS; no competing M-ids | consistent |
| AV-3 | `abstention = null`; M-RES-CAPABILITY-ADVANTAGE carries no NACR clause, so no explicit disposition is required | admissible |
| EV-1 | sourceQualityState COMPETENT (controlling view); the lineage also records COMPETENT_SELF_DESCRIPTION_UNCORROBORATED | pass (neither is CONTENT_INACCESSIBLE) |
| EV-2 | no competing M-ids | pass |
| EV-3 | no NACR declaration; [c2, c3, c4] are ordinary missing components of an M with no registry abstention clause | pass |
| EV-4 | TT-NTSTJ-RS: EXACT, DOCUMENTARY_COMPLETE_CANDIDATE; mechExpr `ALL_OF(M-RES-CAPABILITY-ADVANTAGE, M-CAPABILITY-YIELDS-CONTROL)` consumes the M; D-07 consistent | pass |

```text
bearingEvaluability          = EVALUABLE
bearingIndeterminacyReasons  = null
```

### 16.2 Bearing

- **B-1a (Class C, SEP-DE4).** evidenceForm DE-4; the constitutive exception is NOT AVAILABLE (§A.8 l.191; C34 §6 l.205; no anchor named or verified) → **NON_DISCRIMINATING**. B-3 and SEP-U are not reached, so no T(r) or W(f) is needed.
- **Corroboration (non-decisive; human judgment; would need a trace in a live successor coding).** E(r) = {c1 "resources"}, with basis "planned $2.5B expansion".
  - MD-2: the content falls under the explicitNonMeaning "Not capex existence" (§D l.944) → TRIGGERED (judgment).
  - MD-3: the basis also entails c1 "resources" of M-RES-STAKE-UNPROVEN (NT/STP) and M-RES-EXPRESSIVE-EXPENDITURE (NF/SFP), both in Cmp(M-RES-CAPABILITY-ADVANTAGE) → CO_ENTAILS (judgment).
  - Either witness makes c1 NON_DISTINGUISHING, so a traced B-3 would likely be NON_DIRECTIONAL. The parent called this "mechanical"; CORR1 corrects that to judgment.

```text
supportBearing = NON_DISCRIMINATING
  — candidate successor projection, conditional on Owner acceptance of SEP-DE4.
    Not a controlling physical value. A-E023 is not changed physically.
```

### 16.3 Robustness [CORR1]

- **All three DE-4 variants give the same projection**, because B-1a reads only evidenceForm, once EV and admission pass:
  - the stale physical row in `a1fcae68…` (SUPPORTED / [] / componentSupply {c1});
  - the fixed inputs (PARTIAL / [c2, c3, c4] / OPEN);
  - the five-RC lane A row (PARTIAL / [c3, c4]).
- PLAN and FORMAL_ONLY are inputs to no bearing rule (SEP-FW-5/6).
- **The superseded non-DE-4 pre-overlay variants would require recomputation** under CORR1: pilot A and reconciliation A (DE-1), and the Execution-1 base (DE-2). B-3 needs a trace and SEP-U needs a witness; neither exists.
- **Under SEP-DE4 option B**, the projection is not mechanical; the corroboration above indicates ND, but only through recorded judgment.

### 16.4 Nearest alternatives rejected

| Alternative | Rejected because |
|---|---|
| INDETERMINATE | No gate fails and the record is admissible. Decided mechanically; missing components are not an EV cause (SEP-FW-3/7). |
| DIRECT_SUPPORT | Capped (B-1a). Independently, no DISTINGUISHING component is plausible (16.2), and SEP-U was never reached. |
| SHARED_NON_UNIQUE | Capped. Also requires a closed W(f) and a DIRECTIONAL record. |
| DIRECT_CONTRADICTION | Capped; relation SUPPORTS_LEAF; no competent affirmative absence. |

Under the predecessor vocabulary, IV1's H-8 finding stands: ND and NOT_DETERMINABLE both survive, and neither is uniquely selected. This projection is not a retroactive selection between them.

---

## 17. A-E001 — NOT ADJUDICATED

Routing: **SEP-MIG-6c → RE-ADJUDICATION_REQUIRED.** CORR1 found no contradiction in that routing. It supplies three further reasons why no mechanical path exists:

- (a) the physical record is internally inconsistent (§14.3);
- (b) there is no directionalityTrace;
- (c) there is no selectionCensusWitness for C-B04.

No bearing value is assigned.

---

## 18. ADVERSARIAL TESTS (Owner task §17 A–J; IV1 countermodels; extras)

All fact IDs are synthetic (`SYN-*`). M, TT, Cmp and E-R8 semantics are the registry's. No historical fact is recoded.

| # | Construction | Expected | Derivation (CORR1 rules) | Result |
|---|---|---|---|---|
| **A** | SYN-A, DE-1: "In 1997 the company committed $400 million of capital expenditure across its operations." M-RES-CAPABILITY-ADVANTAGE; c1 supplied; PARTIAL [c2,c3,c4]; `abstention = null` | EVALUABLE | Admissible (no NACR clause on the M); EV-1..4 pass. Bearing: B-3, MD-2 TRIGGERED ("Not capex existence") → NON_DIRECTIONAL with a witness → ND. | **PASS** (EVALUABLE / ND) |
| **B** | SYN-B: "Members contributed on average ten volunteer hours weekly; members received access to events and merchandise." M-RES-ASYMMETRIC-RETENTION; c1, c2 supplied; heterogeneous channels, no common unit, no competent comparison → `abstention = {NACR-1, c3}`; edgeState PARTIAL | INDETERMINATE | EV-3 fails [COMPONENT_NOT_ASSESSABLE]; bearing null. Same result with edgeState NOT_DETERMINABLE (§7.3). With the declaration omitted → HOLD-NA. **This is IV1 CM-EV-1.** | **PASS** |
| **C** | SYN-C, DE-1: "In the 1995 brake-supplier dispute, engineering road-tested both designs; the design the test favoured was adopted although the VP had backed the other." M-ADJ-TEST-RESULT (NT/STP); c1–c4 supplied. W(f) closed: SELECTED = {M-ADJ-TEST-RESULT, M-EMPIRICAL-TEST-ITERATE} (both NT/STP); 72 NOT_SELECTABLE. | eligible for DIRECT_SUPPORT | Cmp⁺(r) = {ARGUMENT-QUALITY (NF/NT), TOPDOWN (STJ/STP), INTERPRETIVE-CONTROL, MEANING-GOVERNED-COMPLIANCE, PARTICIPATION-ARCHITECTURE-CONTROL} (Sel_other = ∅). T(r): c1 "contested issue" CO_ENTAILS ARGUMENT-QUALITY c2 → NON_DIST; c4 "rank not decisive" CO_ENTAILS ARGUMENT-QUALITY c4 → NON_DIST; c3 "decision followed the test result" NO_CO_ENTAILMENT ×5, with rationale ("an empirical test is not argument under shared rules of argument"; "no rank-decision record") → DISTINGUISHING → DIRECTIONAL. Alt(r) = ∅ → **U-0 → DIRECT_SUPPORT**. Note: direction comes from c3, not from full supply. | **PASS** |
| **D** | Same as C, but W(f) absent, or M-ADJ-ARGUMENT-QUALITY dispositioned SELECTED with no materialized record | NOT DIRECT_SUPPORT | W-1/W-3 fails → SEP-U-X → **HOLD-U**. The record is not materializable. | **PASS** |
| **E** | SYN-E: "The firm moved R&D funds toward the projects whose prototypes passed field tests and cut the failed ones; the founding family kept the accumulated capital inside the family holding network." X = M-RES-REALLOC-BY-RESULT (NT/STP): c2, c3 supplied. Y = M-RES-NETWORK-PRESERVATION (SFJ/SFP): c1–c3 supplied. W(f) closed, both SELECTED and materialized. | SHARED_NON_UNIQUE | Each trace: the distinguishing component of one M has NO_CO_ENTAILMENT against the other (distinct content bases) → both DIRECTIONAL. Each record's Alt holds the other, DIRECTIONAL → **U-2 → SHARED_NON_UNIQUE** on both, basis PROVEN_DIRECTIONAL_ALTERNATIVE. Delete the Y record → HOLD-U for X (**IV1 CM-DIR-1** prevented). | **PASS** |
| **F** | DE-4 records: four uncapped possibilities (DIRECT / CONTRA / SHARED / ND), all EVALUABLE, exception NOT AVAILABLE | NON_DISCRIMINATING | B-1a (Class C) → ND in all four branches (**IV1 CM-DE4-1**); INDETERMINATE DE-4 → null. | **PASS** (conditional on surface 3) |
| **G** | Legacy ND, DE-1, PARTIAL, EVALUABLE, no cap; under the successor, B-3 could be DIRECTIONAL and W(f) closed (**IV1 CM-MIG-1**) | RECOMPUTE / RE-ADJUDICATE | MIG-5 deleted; neither 5A nor 5B applies → **MIG-5C**. Physical incidence: 6 occurrences (§14.3). | **PASS** |
| **H** | Legacy ND, DE-4, EVALUABLE (the F-E-0182 rows) | mechanical ND | **MIG-5A** (B-1a cap on recorded evidenceForm) → ND, legacy value in the ledger. Conditional on SEP-DE4. | **PASS** |
| **I** | SYN-F: sourceQualityState CONTENT_INACCESSIBLE (C34 §13.2 IDENTITY_ONLY) | INDETERMINATE + null | EV-1 fails → (INDETERMINATE, [SOURCE_CONTENT_INACCESSIBLE], null). Variant: `SRC-INACCESSIBLE` declared but sourceQualityState COMPETENT → HOLD-NA. Variant F′: fact absent from the sealed manifest → no edge → all null. | **PASS** |
| **J** | SYN-C2: only the distinguishing component c3 of M-ADJ-TEST-RESULT supplied; carriers missing; scope UNRESOLVED_FAIL_CLOSED; W(f) closed; no alternatives | no Environment establishment | Bearing DIRECT_SUPPORT (U-0); leaf OPEN (E-R4); targetState NOT_ESTABLISHED_WITHIN_BOUND. O-1(a)/(b)/(i): no establishment, separation or Environment contribution from bearing alone. A completed ANY_OF sibling cannot establish c3's content (O-1(c)). | **PASS** |
| K | Structural: an M_X fully supplied (SUPPORTED); every supplied component's basis CO_ENTAILS a component of some M′ ∈ Cmp(M_X) of another Environment | ND, not DIRECT | No DISTINGUISHING component → NON_DIRECTIONAL → ND. The deleted full-supply shortcut would have given DIRECTIONAL (SEP-FW-22). | **PASS** |
| L | SYN-L: X record M-EMPIRICAL-TEST-ITERATE (NT/STP), DIRECTIONAL. The same fact is E-R7 AMBIGUOUS between M-ADJ-TEST-RESULT (NT/STP) and M-AUTH-TOPDOWN-EXPLICIT (STJ/STP); W(f) closed | not DIRECT | Alt(X) = {TOPDOWN record: INDETERMINATE (EV-2)}; the TEST-RESULT competitor is same-Environment → **U-3 → SHARED_NON_UNIQUE**, basis UNRESOLVED_ALTERNATIVE. | **PASS** |
| M | A coder declares M-ENFORCE-SANCTION c2 "undocumentable" (H-7 generic) | not EVALUABLE, not generic INDETERMINATE | No NACR clause on c2 → inadmissible code → **HOLD-NA** → §L-4 / §M. | **PASS** |
| N | The same mixed case encoded twice (B with edgeState PARTIAL vs NOT_DETERMINABLE) | identical EV | §7.3 invariance. | **PASS** |
| O | A DIRECTIONAL record whose sibling's trace is incomplete | not DIRECT | The alternative is HELD → U-X → HOLD-U. | **PASS** |
| P | Order check (**IV1 CM-ORDER-1**) | no back-edge | §12 graph S2 → S3 → S6 → S7; W/T/abstention are inputs. | **PASS** |

All required tests (A–J) behave as specified. No test needs an Environment computation.

---

## 19. IMPACT CENSUS — SUMMARY (full detail in `…_CORR1_IMPACT_CENSUS.json`)

| Required item | CORR1 value |
|---|---|
| controlling Section-I record count | 6 (plus 110 execution cells; 4 mirror supportClass) |
| current legacy NOT_DETERMINABLE (controlling) | 0 |
| successor mechanical projection count (controlling) | 5, conditional on SEP-DE4 (option B: 0) |
| successor re-adjudication count (controlling) | 1 (A-E001) (option B: 6 recompute) |
| value-change count (controlling) | 3 (F-B-0025, F0024, A-E023: DIRECT → ND), conditional |
| historical distinct legacy NOT_DETERMINABLE identities | 5 |
| byte-deduplicated historical NOT_DETERMINABLE occurrences | 9 (3 byte artifacts; 11 path-level; 4 paths) |
| historical mapped records (byte-dedup) | 122: 68 mechanical-conditional, 54 recompute |
| delta vs parent | controlling counts 0; rule basis MIG-5 → MIG-5A on 2 rows; +6 legacy ND and +7 legacy DIRECT move from (former) mechanical to recompute; 8 historical consumer entries gain RE-ADJUDICATION_REQUIRED (on re-activation) |
| schema impact | SCHEMA_CHANGE_REQUIRED (coder view schema `0cb5a6b5…`): three successor fields; closed `abstention` codes; companion W(f) and T(r) |
| field-source-matrix impact | SCHEMA_CHANGE_REQUIRED (`1fb84aed…`): supportClass deprecated for successor writing; rows for the three fields (EV MECHANICAL; reasons MECHANICAL; bearing MIXED); refined `abstention`; W and T rows |
| validator impact | DOWNSTREAM_CONSUMER_CHANGE_REQUIRED for any future successor validator: EV function (SEP-I-10); NACR codes; SEP-AV holds; W-1..W-4; T-1..T-5; SEP-U derivation; no dual write. Historical validators NO_CHANGE. |
| assembly impact | DATA_MIGRATION_REQUIRED (future, new artifact only): a successor view needs zero held records and a SEP-MIG-0 ledger |
| HEDC downstream obligation | DOWNSTREAM_CONSUMER_CHANGE_REQUIRED / DEFERRED: O-1(a)–(i); outcome preservation NOT_YET_PROVEN |
| report-product impact | NO_CHANGE (no consumer) |
| Mode-D boundary | NO_CHANGE. ADVISORY: the slice-1 guard (`src/server/_level1ModeDSlice1.ts` l.998–999) and its validator are literal on `"supportClass"`; they do not cover successor names, `abstention`, W or T. Future activation boundary; no edit authorized. |

**Consumer safety (Owner task §16).**

- **Terms searched:** supportClass, NOT_DETERMINABLE, bearingEvaluability, bearingIndeterminacyReasons, supportBearing, nonAssessab*, registryCensus, directionalityTrace, SEP-DE4, SEP-EV, abstention, governingReason, CASE-1 support semantics and C34 §6. They were searched over the repository (WORKBENCH, Downloads, docs, src, scripts, api) and the sibling workbench.
- **No new live consumer.** Successor names occur only in the parent and IV1 packages.
- **Homonyms, not consumers:**
  - `registryCensus` in the Final Regression 1 artifacts means registry inventory counts. CORR1 therefore names its witness `selectionCensusWitness`.
  - `abstentionReason` in `src/agent/*` and the questionnaire "abstention" in `src/generated/newlogic/scoringAndTriage.json` are agent and questionnaire semantics.
- **Parent consumer hashes:** 63 re-verified, all matching; 4 parent entries carry no hash (non-file surfaces).

---

## 20. FUTURE OWNER DECISION FRAME (prepared, not asked; to be issued only after a fresh IV)

These are the only irreducible Class-C choices identified. Source-correctable defects are not bundled in. One dependency level applies: surface 1 is the parent, and 2 and 3 are its children. Ask 2 and 3 only if 1 is accepted.

### Surface 1 — Architecture C successor semantics (parent decision)

- **DECISION:** accept or reject the Architecture C package as the Stage-2 successor for supportClass. The package comprises:
  - the two axes and three fields;
  - SD-1 / SD-3 / SD-5;
  - the EV gates keyed to the abstention declaration and SEP-NACR (SEP-AV);
  - B-3 with comparator universe, co-entailment and trace;
  - SEP-U with the selectionCensusWitness;
  - the MIG rules;
  - O-1.
- **WHY THIS REQUIRES THE OWNER:** C34 §14 and Stage-2 §E import the five CASE-1 classes. Replacing that import is a methodology change (AGENTS.md §3) that no accepted authority decides.
- **OPTIONS:**
  - **A:** accept.
  - **B:** reject and keep the predecessor supportClass. A-E023 then stays NOT_UNIQUELY_ESTABLISHED under H-8.
- **RECOMMENDATION:** A.
- **WHY:** it removes a token whose two predecessor meanings cannot be separated by value. It makes evaluability mechanical and independent of edgeState, makes uniqueness fail-closed against truncation, and puts every bearing judgment in an inspectable trace. The field has no live consumer yet, so the cost is lowest now.
- **CONSEQUENCE:**
  - If A, the next act is a successor methodology text plus schema and field-source-matrix successors (separately authorized). There is a real coding cost: one W(f) of 74 dispositions per analytical fact, and one T(r) of up to |Cmp⁺(r)| dispositions per component examined, for uncapped records.
  - If B, nothing changes, and the A-E023 residual pair stays unresolved.
- **REVERSIBILITY:** high before materialization. After a successor view exists, reverting needs the MIG ledger, which is retained by design.

### Surface 2 — direction-only bearing on incomplete content (child of 1)

- **DECISION:**
  - **2a** allow `DIRECT_SUPPORT` (and `SHARED_NON_UNIQUE`) on PARTIAL/OPEN edges as direction plus proven uniqueness, not establishment (SD-2);
  - **2b** allow the counter analogue: `DIRECT_CONTRADICTION` for directional counter content without full counter establishment (B-2 Class C content).
- **WHY THIS REQUIRES THE OWNER:** CASE-1 "instantiates" and C34 §§7.3–7.6 do not compel the decomposition (IV1 §7).
- **OPTIONS:**
  - **A:** allow, under O-1.
  - **B:** require establishment for DIRECT / SHARED / CONTRA. PARTIAL directional content then becomes ND, losing the distinguishing information.
- **RECOMMENDATION:** A.
- **WHY:** establishment is already computed separately and exactly by §F.3. Bearing that waits for establishment would duplicate §F.3 and erase the distinction between "points nowhere" and "points to X but incomplete", which a later HEDC needs for inspectable exclusion reasoning (CASE-1 §14). O-1 keeps the bearing non-sufficient.
- **CONSEQUENCE:** if A, HEDC must implement the O-1(b) witness coupling. If B, B-3/SEP-U apply only to fully established leaves, and traces shrink.
- **REVERSIBILITY:** recomputable from recorded inputs and traces.

### Surface 3 — DE-4 successor ceiling (child of 1)

- **DECISION:** adopt SEP-DE4 (§13.2) or a direction-preserving DE-4 policy.
- **WHY THIS REQUIRES THE OWNER:** C34 §6 supplies the predecessor ceiling and non-authority clause but no selector for a direction-only bearing (IV1-F03). Both successor policies are compatible with C34.
- **OPTIONS:**
  - **A:** SEP-DE4: EVALUABLE DE-4 → ND in every direction while the exception is NOT AVAILABLE.
  - **B:** direction-preserving: DE-4 bearing computed by B-2..B-4 like any record, with non-authority enforced only through establishment (§F.3) and O-1.
- **RECOMMENDATION:** A.
- **WHY:** both members of C34 §6's default are non-discriminating-type outcomes. §7.3 forbids structure-resemblance inferences (`central board → NT/STJ`). A DE-4 directional bearing would invite exactly that reading. A also resolves the observed DE-4 inconsistency (ADV-3), and DE-4 records then need no trace and no witness.
- **CONSEQUENCE:**
  - If A, the 5 controlling-view DE-4 projections are mechanical (3 value changes), as are 68 historical DE-4 projections.
  - If B, all DE-4 records require traces and witnesses; the controlling view needs 6 recomputations.
- **REVERSIBILITY:** B can be adopted later by recomputation, at the cost of producing traces for DE-4 records.

No other irreducible choice was found. The subsidiary design choices inside surface 1 each have a fail-closed or non-circularity justification and are not separate Owner questions:

- the NACR closure (§7.5);
- U-3 SHARED versus a permanent hold (§9.5);
- the comparator universe boundary (§9.4).

---

## 21. LOAD-BEARING RULE CLASSIFICATION (A = EXISTING_AUTHORITY_RESTATEMENT · B = NECESSARY_DERIVATION · C = NEW_SUCCESSOR_METHODOLOGY_PROPOSAL · D = UNSUPPORTED)

| Rule | Class | Basis / note |
|---|---|---|
| Architecture C (two axes, three fields, grain, version boundary) | **C** | explicit new contract |
| SEP-EV-0 applicability | **C** | A predicates: relevanceState, H-1 |
| SEP-EV-1 | **C** | A predicate: §E sourceQualityState CONTENT_INACCESSIBLE; mapping to the axis is new |
| SEP-EV-2 [CORR1] | **C** | A predicate: E-R7/E-R8 ambiguity record; keyed to the record, not edgeState |
| SEP-EV-3 [CORR1] | **C** | A predicates: §G-7, §D l.997, §F.3 l.1121, view-schema abstention; restriction to SEP-NACR is new |
| SEP-EV-4 | **C** | A predicates: §A.5, §A.6, §C.0 |
| SEP-NACR [CORR1] | **C** | its current content (NACR-1 only) is a mechanical extraction from §D, i.e. B as data; the rule that only registry clauses produce EV-3 is C |
| SEP-AV-1..AV-5 [CORR1] | **C** | admission / hold discipline |
| SEP-EV-C closure [CORR1] | **C** | completeness argument §7.5 over enumerated A routes; no longer universal-by-assertion |
| SEP-B-1a [CORR1] | **C** | was A in the parent; successor DE-4 ceiling, Owner surface 3 |
| SEP-B-1b | **A** | §F.3 PR rule (l.1157) |
| SEP-B-2 [CORR1] | **C** | A predicates: §F.2, §J-2, E-R8; C: partial directional counter bearing distinct from leafNeg |
| SEP-B-3 [CORR1] | **C** | A discipline: C34 §7.3–§7.5, H-3, explicitNonMeaning text; C: Cmp⁺, co-entailment, MD-1..MD-3, trace, burden. Full-supply shortcut deleted. |
| SEP-B-4 / SEP-U [CORR1] | **C** | A principle: CASE-1 §14 (unique separation from all applicable alternatives; inspectable; fail closed), C34 §7.5, H-2.2 census duty; C: witness, closure, U-rules, UNRESOLVED basis |
| SEP-W (W-1..W-4) [CORR1] | **C** | records the existing H-2.2 duty (A) as a verifiable witness (C) |
| SEP-T (T-1..T-5) [CORR1] | **C** | new trace contract |
| SEP-SD-1 | **C** | Stage-2-only NOT DETERMINABLE partition |
| SEP-SD-2 | **C** | direction-only DIRECT_SUPPORT (Owner surface 2) |
| SEP-SD-3 [CORR1] | **C** | was B/C in the parent; SHARED on a closed denominator incl. UNRESOLVED basis |
| SEP-SD-4 [CORR1] | **C** | EV-conditioned reading of the C34 §6 disjunction (Owner surface 3) |
| SEP-SD-5 | **C** | with A components (PR rule; no-mapping stop) |
| SEP-DE4 [CORR1] | **C** | was B in the parent; IV1-F03 accepted |
| O-1 [CORR1] | **C** | strengthened future-consumer obligation; not an outcome proof |
| SEP-MIG-0..4 | **C** | projection / ledger discipline; MIG-4 tightened |
| SEP-MIG-5 (parent) | **DELETED** | IV1 class D; removed |
| SEP-MIG-5A / 5B / 5C [CORR1] | **C** | cap-based / independently established / recompute |
| SEP-MIG-6a | **C** | cap-based recomputation, conditional on SEP-DE4 |
| SEP-MIG-6b (parent) | **DELETED** | IV1 class D; removed |
| SEP-MIG-6c, 7, 8 | **C** | recompute; EV-failure projection; per-TT split |
| SEP-I-1..I-11 | **C** | typed invariants (I-5 conditional on SEP-DE4) |
| SEP-FW-1..FW-26 | **C** | several restate A non-meanings (§E, J-6, FW-3/FW-4) |
| SEP-BC-1..BC-8 | **C** | version and adapter proposals |

**Mechanical derivations used as data, not rules (B):**

- 62 / 40 / 74, with 0 multi-Environment Ms;
- the NACR clause list;
- the Cmp(M) table;
- the A-E023 and controlling-view projections, which are applications.

**LOAD_BEARING_CLASS_D_RULES = 0.** IV1's three D items (SEP-EV-C, SEP-B-3, SEP-B-4) are rebuilt as C with explicit closure, operational and completeness contracts. Its two D migrations (MIG-5, MIG-6b) are deleted. No C rule is presented as A or B because it is compatible with existing authority.

---

## 22. CROSS-STATE FIREWALL [CORR1 additions]

The parent SEP-FW-1..FW-18 are retained, with one change: **SEP-FW-15** loses its exception. edgeState NOT_DETERMINABLE no longer implies EV-3; it is only an admission-consistency input (SEP-AV-1).

Added:

| ID | Non-implication | Ground |
|---|---|---|
| SEP-FW-19 | any `edgeState` value ⇏ any evaluability outcome | SEP-I-10 |
| SEP-FW-20 | `abstention` with an establishment-side code (EST-CHAR / EST-PLAN / EST-SILENCE) ⇏ INDETERMINATE | §E non-meanings; §K; §E-P; §J-3 |
| SEP-FW-21 | absence of a sibling record ⇏ uniqueness | only W(f) closure plus explicit NOT_SELECTABLE dispositions (SEP-U) |
| SEP-FW-22 | full component supply / SUPPORTED ⇏ DIRECTIONAL | B3-7 |
| SEP-FW-23 | explicitNonMeaning silence ⇏ DISTINGUISHING | MD-2 is a bounded negative test only |
| SEP-FW-24 | legacy label agreement ⇏ successor value | MIG-5 / MIG-6b deleted |
| SEP-FW-25 | HOLD ⇏ any bearing value; ⇏ INDETERMINATE | §6.7 |
| SEP-FW-26 | SHARED_NON_UNIQUE (UNRESOLVED_ALTERNATIVE) ⇏ the alternative's direction is established | §9.5 |

Implications defined by this candidate (complete list):

- SEP-EV-1..EV-4 failure conditions ⇒ INDETERMINATE.
- SEP-AV-1..AV-5 conditions ⇒ HOLD.
- SEP-DE4 (conditional) and SEP-B-1b ⇒ ND.
- SEP-B-2 / SEP-B-3 / SEP-U as specified.
- SEP-I-1..I-11.

Nothing else is implied.

---

## 23. ENVIRONMENT-MATH PRESERVATION GATE

Root Definitional/E9 unchanged → Stage-2 measures inputs only → no Environment assignment before a frozen determination contract → ECS only after two lawful Environment determinations.

This candidate defines measurement-field semantics only. It makes no Environment assignment, candidate or ranking. It involves no U-7, OM-1, MD-2 Φ, D2-10, HEDC, RULE FREEZE, 905 / 18-side replay, Pair, ECS or friction. O-1 constrains a future act and authors none.

---

## 24. LIMITATIONS AND OPEN DEPENDENCIES (none blocks IV)

- **OD-1 PRES-target DE-4 bearing.** DEFERRED. It interacts with surface 3. Incidence 0.
- **OD-2 H-7 precedence.** Still unresolved for edgeState itself, but **no longer load-bearing here** (§7.3). A separate edgeState act may settle it.
- **OD-3 Measured surface.** DEFERRED. A future pilot schema should measure agreement on `supportBearing`, on MD-3 dispositions and on W(f) dispositions.
- **OD-4 HEDC contract.** O-1 is the minimum. The full consumer contract belongs to the future HEDC act.
- **OD-5 Coding cost.**
  - W(f): 74 dispositions per analytical fact.
  - T(r): up to |Cmp⁺(r)| dispositions per DISTINGUISHING component, and one witness per NON_DISTINGUISHING component.
  - Records capped by SEP-DE4 need neither. The cost is disclosed in surface 1.
- **OD-6 Witness correctness.** W-1..W-4 prove enumeration and materialization, not the correctness of each disposition (§6.5).
- **OD-7 Comparator boundary.** Cmp(M) over-inclusion is fail-closed. Under-inclusion across D families is covered by Sel_other(f), not by the registry. 10 Ms have Cmp(M) = ∅.
- **OD-8 Abstention field status.** The view-schema `abstention` field is a pilot execution surface (git-bound), not a §I field. The successor text would need to adopt it into §I or keep it view-schema-only with the §6.4 codes.
- **Residual human judgment** (disclosed, not disguised): MD-1..MD-3, NACR clause application, and W(f) dispositions.
- **NOT DETERMINABLE:** drafters' intent behind C34 §6 and CASE-1 §13; primary text of census Option A. Neither is relied on.

---

## 25. VALIDATION PERFORMED AND PRESERVATION

**Performed:**

- SHA-256 and byte checks on every cited input, including the five parent/IV1 identities (§3.1).
- In-memory re-read of the CASE-1 archive members, checksum-matched against the archive manifest.
- Mechanical registry parse: 62 / 40 / 74 / 8 PRES / 0 multi-Environment; NACR extraction; Cmp(M) for all 74 Ms.
- A fresh walk of 2078 JSON/JSONL files with per-record CORR1 projection, byte-deduplication and the parent-rule counterfactual.
- Re-verification of the parent consumer hashes (63/63 match).
- Searches for successor and homonym terms.
- Execution-cell inspection of the controlling view.
- A synthetic adversarial table (§18).
- Read-only Git with `GIT_OPTIONAL_LOCKS=0`.

**Not performed:**

- no build, runtime, network, regression harness, builder or validator execution;
- no recoding, adjudication or materialization;
- no CORR2, no Final Regression and no Git mutation.

**Preservation.**

- Before writing, 1368 files were hashed: tracked files, WORKBENCH/DOWNLOADS, docs/reference, docs/governance, docs/contracts, Downloads, Git metadata and the sibling `03_SOURCE_ARTIFACTS`. HEAD was `2567223…` on `main`, with 700 `-uall` porcelain entries, all untracked, and no tracked or staged diff.
- The post-write comparison and the exact three-file delta are recorded in the manifest.
- Scratch, outside the repository and not authority: `/private/tmp/mv_sc_eval_sep1_corr1_scratch/`.

---

## 26. TERMINAL STATE

```text
STAGE2_SUPPORTCLASS_EVALUABILITY_SEMANTIC_SEPARATION_1_CORR1_READY_FOR_IV
ownerAccepted          = false
independentlyVerified  = false
controlling            = false
implemented            = false
requiredNext           = fresh independent IV by a non-Claude eligible verifier
```

Ready-for-IV gate (Owner task §22): every condition is met.

- **F01 closed.** EV recognition does not depend on edgeState.
- **F02 closed.** Uniqueness cannot be inferred from absent sibling records.
- **F03 corrected.** SEP-DE4, B-1a and SD-4 are Class C.
- **F04 bounded.** The B-3 universe and trace are operationally bounded.
- **F05 removed.** The universal MIG-5 carry is gone.
- **0 load-bearing D rules.**
- **No historical bytes changed.**
- **A-E001 unadjudicated.**
- **No implementation.**
- **Environment math untouched.**

STOP AFTER THE THREE-FILE CORR1 PACKAGE. Do not begin IV. Do not implement. Do not ask for Owner acceptance yet.
