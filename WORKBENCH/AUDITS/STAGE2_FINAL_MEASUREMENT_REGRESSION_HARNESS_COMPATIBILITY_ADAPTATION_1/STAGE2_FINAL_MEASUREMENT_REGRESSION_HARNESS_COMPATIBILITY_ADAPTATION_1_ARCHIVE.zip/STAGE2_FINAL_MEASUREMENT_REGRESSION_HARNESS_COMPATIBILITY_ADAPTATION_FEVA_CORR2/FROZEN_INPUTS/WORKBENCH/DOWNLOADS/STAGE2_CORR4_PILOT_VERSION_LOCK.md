# STAGE2_CORR4_PILOT_VERSION_LOCK.md

**Act:** `POST-10-CALIBRATION-STAGE2-TREE-BOUND-DISCRIMINATOR-AND-MECHANISM-MEASUREMENT-CONTRACT-1.PILOT-VERSION-LOCK-1.CORR4`

**Role:** PILOT-VERSION LOCK EXECUTOR (not methodology author, not independent auditor, not Owner, not pilot coder, not Environment determiner, not Git agent)

**Date:** 2026-09-26

**Terminal state:** `PILOT_VERSION_LOCK_READY`

**Statement of effect:** This document freezes the deterministic execution package of the bounded outcome-hidden pilot required by CORR4 §L. It does **not** run the pilot, does **not** stratify, select or code any real fact, and does **not** assign any Environment.

---

## 1. WHAT THIS LOCK IS

A PILOT VERSION LOCK is not a final contract freeze (CORR4 §L, first line). It freezes:

- the exact Owner-accepted contract version the pilot runs under;
- the exact Stage-1 factual substrate it draws from, down to physical field locators;
- the exact permitted input view of each coder role;
- the exact deterministic selection rules;
- the exact quota and target arithmetic;
- the exact coverage-gap and disagreement reporting rules;
- the exact isolation boundary between the four coder roles.

Nothing in this act altered CORR4. Nothing in this act created a proxy. Nothing in this act created a hidden preclassification.

---

## 2. OWNER-ACCEPTED EXECUTABLE CONTRACT

| Item | Value |
| --- | --- |
| File | `WORKBENCH/DOWNLOADS/STAGE2_SEMANTIC_SUCCESSOR_CANDIDATE_CORR4.md` |
| SHA-256 | `2de49862fb0d63c5f1cd1745531199137e73b7b37abceecef6e735d497d38bb0` |
| Bytes | `250512` |
| Newlines | `1484` |
| Identity check this act | **EXACT MATCH** (recomputed from physical bytes) |
| Divergent same-name copies | 0 (`/private/tmp/mv_stage2_corr4_zai/…CORR4.md` recomputed — identical SHA) |

The header of the immutable candidate file still carries the pre-acceptance author state `CORR4_CANDIDATE_READY_FOR_IV5`. That is preserved artifact text, not the current status. The current status is Owner acceptance, established by the Owner task authorising this lock.

## 3. INDEPENDENT VERIFICATION OF THE LOCKED VERSION

| Item | Value |
| --- | --- |
| File | `WORKBENCH/DOWNLOADS/STAGE2_SEMANTIC_SUCCESSOR_CORR4_IV5_REPORT.md` |
| SHA-256 | `2aa5362e3b8d4f63bf4774819cb5f33e3c6d7fd41e9a4696e1a0b21ef89d7b37` |
| Bytes | `21447` |
| Verdict as read from the file | `PASS` / `BLOCKING = 0` / `MAJOR = 0` / `MINOR = 1` |
| Expected verdict | `PASS` / `0` / `0` / `1` |
| Match | **EXACT** |
| Auditor | Codex (designated Astra), fresh independent auditor; did not author CORR4 |

The single MINOR finding (IV5-MIN-01) concerns an imprecise inclusive section range in the *author's own reporting text* (§E–§L versus the correct §E–§K). IV5 states it alters no execution rule, sample construction, coder view, target state or reproducibility. It is a reporting defect in an author artifact, not a defect in the locked contract. No CORR4 repair is required and none was performed.

Manifest cross-check: `STAGE2_SEMANTIC_SUCCESSOR_CORR4_IV5_MANIFEST.sha256` declares exactly the report, the repro text and the repro script, and does not hash itself.

## 4. OWNER ACCEPTANCE AND PILOT AUTHORIZATION

- **Owner acceptance:** the Owner has explicitly accepted the exact contract at §2 identity, together with IV5 `PASS 0/0/1`.
- **Owner pilot authorization:** the bounded outcome-hidden pilot is authorized to begin automatically upon `PILOT_VERSION_LOCK_READY`. No separate Owner decision is interposed between READY and pilot execution.
- **Scope of that authorization:** it authorizes the pilot *under the frozen package of this lock only*. It does not authorize a different sample, a wider sample, an Environment determination, a 905-fact binding, or a final freeze.
- **Executor stopping point:** this executor stops at READY. It does not launch coder sessions (§12).

## 5. STAGE-1 POPULATION IDENTITY

Resolved independently from physical bytes by `STAGE2_CORR4_PILOT_STAGE1_SOURCE_MAP_BUILD.py`:

```text
STAGE1_CASES  = 9
STAGE1_SIDES  = 18
STAGE1_FACTS  = 905
STAGE1_POPULATION_IDENTITY = 9 / 18 / 905 EXACT
DUPLICATE_IDENTITY_TUPLES  = 0
```

Per-case: 43 + 35 + 38 + 50 + 86 + 428 + 61 + 51 + 113 = **905**. Two sides per case × 9 = **18**.

No identifier value was normalized. No outcome material was read. No fact text was printed, semantically coded or used to select anything.

## 6. STAGE-1 PHYSICAL LOCATOR MAP

Schema is **not** uniform across packages. The logical reads resolve to different physical keys per package; this is a locator resolution, not a semantic proxy.

| # | caseSlug | Facts | Sides | `factId` | `sideId` | `factText` | `caseId` |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | daimler-chrysler | 43 | 2 | `factId` | `side` | `proposition` | package-level `caseId` |
| 2 | deutsche-bankers-trust | 35 | 2 | `fact_id` | `side` | `atomic_proposition` | record-level `case_id` |
| 3 | pfizer-megamergers | 38 | 2 | `fact_id` | `side` | `atomic_proposition` | record-level `case_id` |
| 4 | aol-time-warner | 50 | 2 | `fact_id` | `side` | `atomic_proposition` | record-level `case_id` |
| 5 | aecom-urs | 86 | 2 | `fact_id` | `side` | `proposition` | package-level `case_id` |
| 6 | exxon-mobil | 428 | 2 | `fact_id` | `side` | `proposition` | package-level `case_id` |
| 7 | jpmorgan-bank-one | 61 | 2 | `fact_id` | `side` | `proposition` | package-level `case_id` |
| 8 | google-android | 51 | 2 | `fact_id` | `side` | `proposition` | package-level `case_id` |
| 9 | amazon-whole-foods | 113 | 2 | `fact_id` | `side` | `proposition` | package-level `case_id` |

Exact absolute record-file paths and per-file SHA-256 / byte size are in `STAGE2_CORR4_PILOT_STAGE1_SOURCE_MAP.json`.

**Case-id values are exact and heterogeneous.** `daimler-chrysler` carries the package-level value `CASE-3.5`; the other eight carry their slug. These values feed the canonical hash verbatim. They were deliberately **not** harmonised — harmonising them would be normalization, which CORR4 §L:1038 forbids.

**Two packages live outside the repository root.** Packages 2–9 sit under the sibling directory `MergeVue-M&A WORKBENCH/02_CASE_RESEARCH/…`. That directory is candidate material, never authority (AGENTS.md §5.4). It is used here only as the physical location of sealed Stage-1 records, which is what it is. This act wrote nothing there.

Substrate authority:

| Authority | SHA-256 |
| --- | --- |
| `docs/governance/historical-corpus/MERGEVUE_STAGE1_FACTUAL_AUTHORITY_SUCCESSOR_BINDING_AND_CLOSURE_2026-09-25.md` | `be9593a767edfa1d61787458db3de1c7034d49ac60b65fe0ce8e11402fe70237` (sidecar verified) |
| `docs/governance/historical-corpus/MERGEVUE_POST_10_CALIBRATION_9_CASE_CORPUS_FREEZE_2026-09-25.md` | `da9b9de2ab9c49cf98100c008eb980225cf8595b2873cc4eb6eb6d8e9733cbd6` (sidecar verified) |

The Stage-1 factual authority binding explicitly records `9/9 cases present`, `18/18 sides present`, `905/905 admitted facts reviewed`. This lock neither re-audits the facts nor reopens the defect census; it resolves the population identity that the accepted authority already binds.

## 7. OPTION-A EXECUTION RULE (CORR4 §L:1031)

The pre-sampling stratifier input is **exactly**:

- `factId`, `caseId`, `sideId`, `factText` from the sealed Stage-1 fact records; and
- the 13 D rows' **neutral observational domain questions** only.

The following are **not** supplied, **not** inferred and **not** proxied at this stage:

```text
evidenceForm        — Stage-2 coding state, assigned by CORR4 §H-6 downstream of sampling
planCurrentState    — Stage-2 coding state, assigned by CORR4 §H-6 downstream of sampling
planCurrent         — alias of the above
DE-4 / PLAN / CONDITIONAL / ELIGIBILITY_ONLY — values of those downstream states
```

Independently confirmed this act: a recursive key census over all nine parsed record documents, at any depth, finds

```text
evidenceForm_key_occurrences     = 0   (all 9 packages)
planCurrentState_key_occurrences = 0   (all 9 packages)
```

So the exclusion is not a convention the pilot chooses to honour against a tempting field; there is no such field in the substrate to tempt it. The exclusion is structural.

**No proxy.** The Stage-1 keys `formal_or_operative`, `announced_or_effective`, `state_at_t0`, `support_status` and `temporal_status` exist in some packages. None of them is the §E vocabulary, none is present in all nine packages, and mapping any of them onto `evidenceForm` or `planCurrentState` would be a newly invented vocabulary — i.e. a methodology act this executor has no authority to perform. They are listed in the stratifier schema as an explicit prohibition.

**No Stage-1 schema mutation** was performed or is permitted.

## 8. THE 13 NEUTRAL D QUESTIONS

Artifact: `STAGE2_CORR4_PILOT_NEUTRAL_D_QUESTIONS.json`
SHA-256: `bf673a3f86f56697966a9cdf62fd5d67a720b934db76176312c6e66da3fbe7fb` (2279 bytes)

- 13 entries, `D-01` … `D-13`, canonical order.
- Entry shape is exactly `{ "d", "neutralObservationalDomain" }`.
- Source: the `neutralObservationalDomain` column of the CORR4 §C D-registry table, copied verbatim.
- Withheld by construction: `neutralName`, `treeConsumers`, `authorityAnchors`, and every dispatch-table row.

Independent reproduction: the file this act produced is **byte-identical** (same SHA-256) to the neutral-D artifact produced earlier by the PILOT-VERSION-LOCK-1 conflict act. Two independent extractions from two different contract revisions agree exactly, which is consistent with IV5's finding that §C is byte-identical between CORR3 and CORR4.

```text
NEUTRAL_D_COUNT      = 13
M_ID_LEAKAGE         = 0
TT_ID_LEAKAGE        = 0
DISPATCH_LEAKAGE     = 0
ENVIRONMENT_LEAKAGE  = 0
NEUTRAL_NAME_LEAKAGE = 0
```

## 9. THE FOUR ROLE SLOTS

Exactly four future roles are defined. **No session is appointed by this act.**

| Slot | Sees | Produces |
| --- | --- | --- |
| `STRATIFIER_A` | §10 permitted view only | per-(fact, D) `eligible ∈ {YES, NO}` |
| `STRATIFIER_B` | §10 permitted view only | per-(fact, D) `eligible ∈ {YES, NO}` |
| `ANALYTICAL_CODER_A` | selected fact records + CORR4 text | CORR4 §I traceability record |
| `ANALYTICAL_CODER_B` | selected fact records + CORR4 text | CORR4 §I traceability record |

Isolation invariants:

1. `STRATIFIER_A` and `STRATIFIER_B` never see each other's marks. Selection happens only after both mark sets are frozen.
2. No adjudication occurs before sample construction. There is no majority rule and no orchestrator override.
3. Analytical coders never see stratification marks, the sample D label, the stratifier identity, or each other's results before freeze.
4. The analytical coder's `discriminatorIds[]` and `treeTargetIds[]` are derived by the coder from the CORR4 §C dispatch routing for the M it selected by `preciseMeaning`. They are **not** the sample's D label and are **not** stratification leakage.
5. Dual coding must not be omitted (CORR4 §M).

## 10. FROZEN VIEW SCHEMAS

| Artifact | SHA-256 | Bytes |
| --- | --- | --- |
| `STAGE2_CORR4_PILOT_STRATIFIER_VIEW_SCHEMA.json` | `1cc135a338c40a73882d5e21cd7cbdf1493809aeeedc775ef40ec53a60c31849` | 8259 |
| `STAGE2_CORR4_PILOT_ANALYTICAL_CODER_VIEW_SCHEMA.json` | `91d59155c238f0450998ea1eb8632c2e0cc533821d47dba70fd90172532c8912` | 12213 |
| `STAGE2_CORR4_PILOT_RESULT_SCHEMA.json` | `816f26cc616af20d9f9f54640acb426cbddd7698c1cf1a08c494e5e11674c12c` | 8850 |

The stratifier view permits exactly six input fields and permits exactly two output mark families (per-(fact, D) eligibility, and the derived fact-level NON_ANALYTICAL mark). It forbids confidence scores, M selection, TT state and Environment state. The analytical coder view carries the full CORR4 §I field set and forbids every stratification artifact.

## 11. DETERMINISTIC SELECTION RULES

Engine: `STAGE2_CORR4_PILOT_SELECTION_ENGINE.py`
SHA-256: `43d01469c7ac1da6315277498a8a60b44ec161e02e3e3fbefe5c8727f1c7def9` (21707 bytes)

The engine consumes exactly three inputs: the frozen Stage-1 identity/field-locator map, `STRATIFIER_A` marks, `STRATIFIER_B` marks. **No methodology semantics are embedded**: the engine never reads, tokenises, scores or interprets fact text, and cannot select an M, a TT, a D route or an Environment.

**Canonical hash (CORR4 §L:1038).**

```text
h(fact) = SHA-256( UTF-8( caseId + "|" + sideId + "|" + factId ) )
```

No trimming, no case folding, no normalization, no alternate separator. Components are the exact physical field values. Ordering is ascending by the lowercase hexadecimal digest. Case-sensitivity and whitespace-sensitivity of the preimage are covered by self-test G.

**Eligibility (CORR4 §L:1034).** A fact is eligible for `D-n` iff `STRATIFIER_A = YES` **and** `STRATIFIER_B = YES`. Intersection only.

**D-stratified selection (CORR4 §L:1036–1039).** For each D in canonical order `D-01 … D-13`:

1. take the intersection-eligible facts for that D;
2. remove facts already selected in an earlier D stratum (no reuse);
3. sort ascending by canonical hash;
4. take the first fact; then take the first subsequent fact lying on a **different side**;
5. if no different side exists, take the single fact and record `ONE_SIDE_ONLY`;
6. if the stratum is empty, record `EMPTY_STRATUM`. No cross-D backfill.

Multi-D eligibility is recorded for every intersection-eligible fact even when the fact is selected only once.

**NON_ANALYTICAL sample (CORR4 §L:1040).** Up to 6 facts, lowest canonical hash first. Shortfall is reported; no replacement fact is invented.

Operational definition, retained from CORR4 and unchanged by Owner Option A:

```text
NON_ANALYTICAL(fact, coder S) := S recorded eligible = NO for all 13 D rows
pool := facts for which BOTH coders satisfy the above   (same BOTH-discipline as §L:1034)
```

Authority for this operational form: CORR4 §L:1040 read against §L:1033, with the form established by the accepted PILOT-VERSION-LOCK-1 conflict act (`STAGE2_CORR3_PILOT_LOCK_CONFLICT_REPORT.md`: *"NON_ANALYTICAL sample = 6 — YES — derivable as all-13-NO; no extra field needed"*). Owner Option A changed only §L's permitted-input list, the removed formal/plan quota, the coverage paths and the target size; it did not alter this rule.

The engine proves the derived mark is *disjoint* from D eligibility: a fact marked all-NO by both coders can never be intersection-eligible for any D, so §L's clause excluding separately-sampled NON_ANALYTICAL facts from D eligibility is a proven non-binding invariant rather than an operational filter.

Scope note, stated so that it cannot be over-read: this is a **D-domain** non-analyticity on the observational face. It is **not** the CORR4 §E `relevanceState = NON_ANALYTICAL`, which §H-2 assigns to the analytical coder downstream of sampling. The pilot must never report the derived control mark as a §E relevance determination.

**Maximum target.**

```text
MAX_PILOT_TARGET = 13 × 2 + 6 = 32
```

Never 36. There is no formal/plan pre-hoc sample and no hidden four-fact replacement; both were removed by Owner Option A.

## 12. WHAT THIS EXECUTOR DID NOT DO

```text
SELECTED_PILOT_FACTS           = 0
STRATIFICATION_MARKS_CREATED   = 0
ANALYTICAL_CODING_ROWS_CREATED = 0
ENVIRONMENTS_ASSIGNED          = 0
```

The engine's default mode is a dry run over **synthetic fixtures**. Invoked without `--facts/--marks-a/--marks-b` it refuses:

```text
REFUSED: no real stratification marks exist at lock time.
```

`STRATIFIER_A`, `STRATIFIER_B`, `ANALYTICAL_CODER_A` and `ANALYTICAL_CODER_B` are role **slots**, not appointments. This executor did not open a coder session and did not select a real fact.

## 13. POST-CODING COVERAGE RULE (CORR4 §L:1041)

Coverage is **not** guaranteed pre-hoc and is reported only **after** analytical coding. The coverage report must contain exactly four entries:

| pathId | state |
| --- | --- |
| COV-01 | `evidenceForm = DE-4` |
| COV-02 | `planCurrentState = PLAN` |
| COV-03 | `planCurrentState = CONDITIONAL` |
| COV-04 | `planCurrentState = ELIGIBILITY_ONLY` |

Each entry is reported as exactly one of `EXERCISED` or `COVERAGE_PATH_GAP`.

`COVERAGE_PATH_GAP` means **only** that the bounded pilot did not exercise that execution path. It does **not** mean absent from the corpus, unsupported, false, counterevidence, or not characteristic. A gap triggers **no** sample expansion, **no** imputation, **no** pre-classification, **no** proxy, **no** Stage-1 metadata mapping and **no** backfill. Any later targeted coverage extension requires a separately authorized act. The bounded pilot remains the fixed up-to-32 sample.

## 14. MEASUREMENT AND DISAGREEMENT (CORR4 §L-3, §L-4)

**Measured:** stratification agreement · M selection agreement · D agreement · component satisfaction · join / relationInstance binding · scope · time · characteristicity · formal/operative · plan/current · edgeState · UNMAPPED · abstention.

**Not measured:** Environment agreement · prediction accuracy · outcomes · ECS · success · failure.

**Disagreement taxonomy — exactly four categories, no fifth:**

```text
CODER_ERROR
DEFINITION_AMBIGUITY
MISSING_M           → schema review
GRAMMAR_GAP         → schema review
```

Coders may not create `M-NEW`. `MISSING_M` and `GRAMMAR_GAP` route to a later, separately authorized schema-review / correction act. Disagreement-driven repair is a versioned correction/re-IV path, never opportunistic tuning to selected corpus facts.

## 15. OUTCOME FIREWALL

```text
OUTCOME_LEAKAGE                        = 0
ENVIRONMENT_MATERIAL_USED              = NO
PREDICTION_SEALS_OPENED                = NO
POST_T0_RECONSTRUCTIONS_USED           = NO
HISTORICAL_ENVIRONMENT_ASSIGNMENTS_USED = NO
FACT_TEXT_SEMANTICALLY_CODED           = NO
905_FACT_BINDING_EXECUTED              = NO
FINAL_FREEZE_EXECUTED                  = NO
```

Stage-1 JSON/JSONL was machine-parsed only for keys, locators, types, counts, exact identity tuples and record-file hashes. Fact-text values were tested only as non-empty strings and were never printed or interpreted. No Environment determination was made, and none is implied by this lock.

## 16. GIT BOUNDARY

| Item | Value |
| --- | --- |
| Branch | `main` |
| Expected HEAD | `92236dc1341c3f85565514c60029af388bc51422` |
| Observed HEAD | `92236dc1341c3f85565514c60029af388bc51422` |
| Git mutation commands used | none — no `add`, `commit`, `push`, `restore`, `checkout`, `reset`, `clean` |
| Staged entries created | 0 |
| Files attributable to this act | the 10 lock artifacts in `WORKBENCH/DOWNLOADS/` only |
| Pre-existing untracked material | retained, unmodified |

Committing is not part of this act. Git closure requires separate authorization.

## 17. ARTIFACT MANIFEST AND VALIDATION

| # | Artifact | SHA-256 | Bytes |
| --- | --- | --- | --- |
| 1 | `STAGE2_CORR4_PILOT_VERSION_LOCK.md` | *(self — not hashed by itself)* | — |
| 2 | `STAGE2_CORR4_PILOT_NEUTRAL_D_QUESTIONS.json` | `bf673a3f86f56697966a9cdf62fd5d67a720b934db76176312c6e66da3fbe7fb` | 2279 |
| 3 | `STAGE2_CORR4_PILOT_STRATIFIER_VIEW_SCHEMA.json` | `1cc135a338c40a73882d5e21cd7cbdf1493809aeeedc775ef40ec53a60c31849` | 8259 |
| 4 | `STAGE2_CORR4_PILOT_ANALYTICAL_CODER_VIEW_SCHEMA.json` | `91d59155c238f0450998ea1eb8632c2e0cc533821d47dba70fd90172532c8912` | 12213 |
| 5 | `STAGE2_CORR4_PILOT_RESULT_SCHEMA.json` | `816f26cc616af20d9f9f54640acb426cbddd7698c1cf1a08c494e5e11674c12c` | 8850 |
| 6 | `STAGE2_CORR4_PILOT_STAGE1_SOURCE_MAP.json` | `665aac81c2e0127d08f0406186891959255391cb99ec34611a972209565f4a7f` | 17490 |
| 7 | `STAGE2_CORR4_PILOT_SELECTION_ENGINE.py` | `43d01469c7ac1da6315277498a8a60b44ec161e02e3e3fbefe5c8727f1c7def9` | 21707 |
| 8 | `STAGE2_CORR4_PILOT_LOCK_VALIDATE.py` | *(prerequisite of the validation report)* | — |
| 9 | `STAGE2_CORR4_PILOT_LOCK_VALIDATION_REPORT.txt` | *(validator output)* | — |
| 10 | `STAGE2_CORR4_PILOT_VERSION_LOCK_MANIFEST.sha256` | *(hashes 1–9 only; does not hash itself)* | — |

All ten artifacts are finalized first in `/private/tmp/mv_stage2_corr4_pilot_lock/` and then copied **byte-identically** into `REPO_ROOT/WORKBENCH/DOWNLOADS/`.

Two scratch-only derivation scripts were also written during this act and are **not** part of the deliverable set, because the authorized output list enumerates ten artifacts and this act adds nothing beyond it:

- `STAGE2_CORR4_PILOT_STAGE1_SOURCE_MAP_BUILD.py` — builds artifact 6 from physical Stage-1 bytes;
- `STAGE2_CORR4_PILOT_NEUTRAL_D_EXTRACT.py` — extracts artifact 2 from the CORR4 §C table.

They remain in scratch as provenance for how artifacts 2 and 6 were produced. Their output is fully re-derived by the validator (`V-07`, `V-08`, `V-16`), so the deliverable set does not depend on trusting them.

**Finalization ordering is non-circular.** The manifest hashes files 1–9 only and does not hash itself; file 9 is the validation report, which therefore cannot assert its own manifest verdict. The manifest is built after the report, and validated by a separate post-manifest step that writes nothing. `SCRATCH_TO_WORKBENCH_BYTE_IDENTITY` and `MANIFEST_VALIDATION` are established by that post-copy step, not asserted inside the hashed set.

## 18. TERMINAL STATE

```text
PILOT_VERSION_LOCK_READY
```

Ready rule satisfied: the exact Owner-accepted CORR4 is locked; the exact IV5 `PASS 0/0/1` is verified; the Stage-1 `9/18/905` population is physically resolved with per-package locators; the stratifier view uses only lawful inputs; no proxy or preclassification exists; the 13 neutral D questions are frozen; selection is deterministic; the maximum target is 32; the analytical coder view is frozen; coverage-gap reporting is frozen; the four coder-role slots are defined; the outputs validate; no real fact was stratified, selected or coded; no outcome material was used; Git was not mutated.

**Consequence.** Because the Owner has already authorized the bounded outcome-hidden pilot subject to this gate, `PILOT_VERSION_LOCK_READY` means the pilot may proceed immediately to `STRATIFIER_A` and `STRATIFIER_B` without a further Owner authorization.

**Executor stopping point.** This executor stops here. It does not launch coder sessions and does not select real facts. The next act — opening the two stratifier roles against the §10 view — belongs to the pilot run, not to this lock.
