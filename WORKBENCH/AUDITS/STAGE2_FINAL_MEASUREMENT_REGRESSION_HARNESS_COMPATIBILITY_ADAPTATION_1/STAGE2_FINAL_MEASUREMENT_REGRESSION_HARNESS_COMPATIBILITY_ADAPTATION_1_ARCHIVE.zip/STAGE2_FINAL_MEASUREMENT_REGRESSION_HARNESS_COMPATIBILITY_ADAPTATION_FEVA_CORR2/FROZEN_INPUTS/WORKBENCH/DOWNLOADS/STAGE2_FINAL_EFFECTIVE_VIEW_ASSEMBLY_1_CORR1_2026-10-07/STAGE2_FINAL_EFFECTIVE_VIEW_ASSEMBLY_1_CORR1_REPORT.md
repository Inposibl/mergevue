# STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1.CORR1 — Implementation Report

**ROLE AND AUTHORIZATION.** CODER (Z-Ai, GLM-5.3 Flash), Owner act `STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1.CORR1`, 2026-10-07, correcting the `STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1.IV1` FAIL verdict (Codex, 2026-10-07). Stopping point: CORR1 implementation + self-validation only; CORR1.IV1 not started (Codex is the designated independent auditor in a separate act).

**BASELINE.** Repository `/Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)`, branch `main`, HEAD `3d7b7779903cc04a43929a9e8f6f2b371d9be377` (== expected `3d7b777…`). Tracked dirty 0, staged 0, before and after. Failed v1 candidate package `WORKBENCH/DOWNLOADS/STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1_2026-10-07/` re-hashed before and after: all five members byte-identical to the IV1-pinned identities (RECORDS `ea0de2f0…`), preserved unchanged as IV1 evidence. Immutable predecessor `a1fcae68…` (104,310 bytes, 116 records) re-hashed unchanged. Control Tree v2.1 (digest `360bafa2…` = sidecar) has no node for this 2026-10 act (the tree predates the Stage-2 pilot chain); its Stage-2 status was not used as current state — the binding commits `fcbcf86…` (F0024), `3d7b777…` (A-E001), `9b1545e…` (CORR10) and the Owner task are the controlling authorization. Blocking parent: `STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1.IV1` FAIL. Downstream consumer: the final Stage-2 measurement regression (still blocked pending IV + Owner acceptance).

## 1. Findings disposition (exact)

| Finding | Disposition |
|---|---|
| F01 CRITICAL/BLOCKING — dual `supportClass=DIRECT_SUPPORT` + `supportBearing=NON_DISCRIMINATING` on line 115 violates SEP-I-4/SEP-BC-2 | **FIXED.** `supportClass` REMOVED from the migrated A-E001 successor record (SEP-I-4, CORR1 `02505e92…` §6.3; key also on the builder's own forbidden-output list). Legacy classification DIRECT_SUPPORT + full provenance preserved in `STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_MIGRATION_LEDGER.json`. Predecessor untouched. |
| F02 MAJOR — `projectionClass`, `legacySupportClass` are ledger metadata, not record fields | **FIXED.** Both removed from the record and placed in the migration ledger together with the migration-scoped `migrationRuleId`, `successorTriple`, `holdCode`. Schema authority verified before materializing: SEP-BC-2 (successor records write the three SEP fields + abstention + companion W/T where required), SEP-BC-5 (exactly three new record fields). `prOnlyBasis` stays on the record: it is the machinery input consumed by the closed CORR10 builder (`b1b_cap_fires`), it is the accepted bearing decision's `recordedPrOnlyBasisForMaterialization`, IV1-F0024 PASSed it, and without it the as-frozen replay returns HOLD-T which would invalidate the successor artifact under SEP-I-11. No new schema invented. |
| F03 MINOR — absent vs null conflated in delta | **FIXED.** Every old/new value is `{"presence": "ABSENT"}` or `{"presence": "PRESENT", "value": …}`; `bearingIndeterminacyReasons` is PRESENT with explicit JSON null (EVALUABLE), `holdCode` is not on the record at all (ledger). Legend in the delta artifact. |
| F04 MINOR — outputs not all pinned | **FIXED.** The manifest pins RECORDS, DELTA, MIGRATION_LEDGER, BUILD, REPORT with exact SHA-256 + bytes. `manifestSelfHashPolicy` documented in the manifest and here: the manifest does not self-hash; it is the package's externally anchored member (hash the file post-write). No circular self-hash. |

Resilience items: type-exact structural diff (bool vs int and int vs float compare unequal — `exact_eq`); persisted successor values gate-compared against the accepted computed machinery results (and the final record replays through `evaluate` to the accepted outcome); negative controls exercise the REAL paths — resolver, precondition apply, `ProductionPackageAuthority.certify()` (stale identity / wrong side / tampered assertion rejected; other-fact query binds its own text only), as-frozen HOLD-T discrimination, altered-successor-result rejection, scope-promotion rejection, dual-write and ledger-key-on-record rejection; publication is all-bytes-constructed-then-per-file `tmp + fsync + os.replace` with post-write re-read verification (remaining limitation: atomic per file, not as a six-file set).

## 2. Output identities (package `WORKBENCH/DOWNLOADS/STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_2026-10-07`)

| Artifact | SHA-256 | Bytes |
|---|---|---|
| `STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_RECORDS.jsonl` | `3603c3169d7bdd67763ac0d2468d08cbb508d23dfeece4f7b396900b11dc68ec` | 104704 |
| `STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_DELTA_PROVENANCE.json` | `5b0428500f08754e65ad9db2dbaa02feaab280407f4b5a41628d983743f3a61c` | 9092 |
| `STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_MIGRATION_LEDGER.json` | `2d1f23d873821fd45259a51e54fef7b3088e94bcd99a79c864e82ded32e15c05` | 5169 |
| `STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_BUILD.py` | `c3b31e1ed76b7047314bdba75799d2601b45f43e81a03de0f464857a68c8eb98` | 72873 |
| `STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_REPORT.md` | this file (pinned by the manifest) | — |
| `STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_MANIFEST.json` | written last; does not self-hash (see manifestSelfHashPolicy) | — |

## 3. A-E001 successor record (line 115) — exact state

Changed existing fields (accepted scope decision `b3900383…`, Owner-frozen partition): `scopeBridgeState` NOT_REQUIRED→UNRESOLVED_FAIL_CLOSED; `missingComponents` []→["c2"]; `edgeState` SUPPORTED→PARTIAL; `sufficiencyExpressionResult` TRUE→OPEN. Removed: `supportClass` (→ ledger). Added (exactly four keys, appended in fixed order): `prOnlyBasis` (verbatim accepted bearing decision `e7624316…` block), `bearingEvaluability` "EVALUABLE", `bearingIndeterminacyReasons` null, `supportBearing` "NON_DISCRIMINATING". Preserved: certified fact content (c1 SUPPLIED), observedScope unit, claimedScope enterprise, organizationalObjectRef, characteristicity, temporal continuity, sufficiencyExpression, evidenceForm DE-1, factualPackageIdentity, sourceRefs, discriminatorIds, treeTargetIds, coderIdentity/vocabulary/contract identity.

Migration ledger entry (bound to computed machinery values, not literals): legacySupportClass `DIRECT_SUPPORT`; migrationRuleId `SEP-MIG-6a`; projectionClass `MECHANICAL_VALUE_CHANGE`; successorTriple `["EVALUABLE", null, "NON_DISCRIMINATING"]`; holdCode `null`; machinery input prOnlyBasis; superseded as-frozen state HELD/HOLD-T/SEP-MIG-6c.

## 4. Machinery + certification evidence

Registry `cb08b51e…` (74 M rows / 62 TT rows). Adjudicated evaluation (pre-record + accepted basis) and final-record replay both EXACT-match the accepted decision: admission ADMITTED, holdCode null, partition {c1 SUPPLIED, c2 ORDINARY_MISSING_ASSESSABLE}, capFired B-1b, bearingEvaluability EVALUABLE, supportBearing NON_DISCRIMINATING; SEP-MIG-6a / MECHANICAL_VALUE_CHANGE. B-1a not fired (DE-1); B-3 not used; no T(r), no W(f). F0024 edge projection before/after the identity patch canonically identical (cap B-1a SEP-DE4; recorded only, not materialized).

F0024 certification actually executed through the accepted CORR10 `ProductionPackageAuthority.certify()`: subject F0024/aol-time-warner/AOL, authority `FROZEN_STAGE1_SOURCE_MAP:665aac81c2e0127d08f0406186891959255391cb99ec34611a972209565f4a7f`, certified package digest `88b20920…`, proposition sha256 `c8086e32eca9af12c5b53b3b6aa97a415333da12d8b027072e4e36d8bd660567`. PI-3 sidecar `84ab83d2…` line 9 == patch correctedValue; live package 61,728 bytes (AOL 25 / TIME_WARNER 25); source map `665aac81…`.

## 5. Diff geometry (type-exact; absent ≠ null)

Exactly 2 changed lines (112, 115); 114 byte-verbatim; 13 diff paths total — line 112: 4 terminal leaves (four identity subfields); line 115: 15 terminal leaves (4 changed + 1 removal + 4 additions with the prOnlyBasis container expanded to its 7 members). Serialization `json.dumps(ensure_ascii=True, separators=(", ", ": "))`, LF, one trailing newline, pure ASCII; order independence PASS.

## 6. Negative controls (all fired; real paths)

| NC1_oldValuePreconditionRejected | FIRED (rejected as required) |
| NC2a_selectorRejectsZeroMatches | FIRED (rejected as required) |
| NC2b_selectorRejectsMultipleMatches | FIRED (rejected as required) |
| NC3a_staleIdentityRejectedByCertify | FIRED (rejected as required) |
| NC3b_wrongSideRejectedByCertify | FIRED (rejected as required) |
| NC3c_tamperedAssertionRejectedByCertify | FIRED (rejected as required) |
| NC3d_otherFactBindsOwnTextOnly | FIRED (rejected as required) |
| NC4_asFrozenHoldTReproduced | FIRED (rejected as required) |
| NC5_alteredSuccessorResultRejected | FIRED (rejected as required) |
| NC6_scopePromotionRejected | FIRED (rejected as required) |
| NC7a_dualWriteRejected | FIRED (rejected as required) |
| NC7b_ledgerKeyOnRecordRejected | FIRED (rejected as required) |

## 7. Deviations / limitations

1. The three establishment fields (`edgeState`, `sufficiencyExpressionResult`, `missingComponents`) and `scopeBridgeState` remain as in the v1 candidate — IV1-verified as supported by the accepted scope decision; unchanged here.
2. `prOnlyBasis` on the successor record is this act's documented schema-conformance judgment (machinery input requirement + SEP-I-11 artifact validity + IV1 allowance); if the Owner prefers it ledger-side too, that is a one-key change with a consequential evaluate() replay gate update.
3. Publication atomicity is per file (disclosed).
4. This is a CANDIDATE: NOT independently verified, NOT Owner-accepted, NOT Git-closed, no final measurement regression. NO_UPWARD_PROMOTION holds; NON_DISCRIMINATING is not negative evidence, not enterprise evidence, not an Environment classification; c2 not re-adjudicated; no methodology change; no Environment math; no Git mutation.

**STATUS: COMPLETE** (bounded CORR1 implementation + self-validation). **STOP.** CORR1.IV1 (Codex) is the next, separately authorized act.
