# STAGE2_SUPPORTCLASS_EVALUABILITY_SEMANTIC_SEPARATION_1.CORR2.CORR1.CORR1.CORR1.CORR1 — METHODOLOGY CANDIDATE (REPORTING-CONSISTENCY CORRECTION)

- **Act:** MERGEVUE — STAGE-2 CORR4 PILOT — SUPPORTCLASS / EVALUABILITY SEMANTIC SEPARATION-1.CORR2.CORR1.CORR1.CORR1.CORR1 (reporting-consistency micro-correction of CORR2.CORR1.CORR1.CORR1 `0d8cfe22…`)
- **Actor:** Claude Opus 5.5
- **Role:** METHODOLOGY AUTHOR (assigned by the Owner for this act only)
- **Mode:** reporting-consistency micro-correction only. No new methodology, no positive-control change, no Owner-decision change, no implementation, no data mutation, no Git. Read-only except the three CORR2.CORR1.CORR1.CORR1.CORR1 outputs.
- **Date:** 2026-10-05
- **Repository root:** `/Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)`
- **Branch / HEAD:** `main` / `2567223087d99b40bdfd174eed32566be7080e44`. Read-only Git inspection only (`GIT_OPTIONAL_LOCKS=0`).
- **Package status:** AUTHOR CANDIDATE ONLY. `ownerAccepted = false`, `independentlyVerified = false`, `controlling = false`, `implemented = false`.
- **Owner methodology decisions:** all four accepted (Owner Decision Ledger, §14). They are controlling inputs to this candidate.
- **Next step:** a fresh, independent IV by a non-Claude eligible verifier. Its job is to verify that this candidate correctly implements the four Owner-accepted methodology choices.

**Relation to CORR2.CORR1.CORR1.CORR1.** This text is CORR2.CORR1.CORR1.CORR1 (`0d8cfe22…`, 105005 B) with exactly two reporting corrections (§0D): the §2 authorship sentence and §17. §8, the positive control, is byte-identical. No methodology rule, proof, Owner decision, count, projection, witness, comparator or trace changes. The paragraphs below are retained unchanged.

**Relation to CORR2.CORR1.CORR1.** This text is CORR2.CORR1.CORR1 (`08bcf3bd…`, 91211 B) with exactly one correction. It closes the sole BLOCKING finding of the fresh independent IV, CORR2-CORR1-CORR1-IV1-F01: the author's synthetic positive control was incomplete. §8 is rebuilt under the unchanged contract; §0C lists every change. No methodology rule, proof, Owner decision, real-data count, projection, component-domain row, W/T/B-3 rule, migration rule or Environment boundary changes. The paragraphs below are retained unchanged.

**Relation to CORR2.CORR1.** This text is CORR2.CORR1 (`e7448feb…`, 87843 B) with exactly three consistency corrections, listed in §0B. No methodology rule, proof, Owner decision, projection, component row, positive control, migration rule, W/T rule or Environment boundary changes. The paragraph below describes how CORR2.CORR1 relates to CORR2 and is retained unchanged.

**Relation to CORR2.** This text is CORR2 (`5776b6d3…`, 82942 B) with one governance correction. CORR2 still presented Surfaces 1–3 as open future Owner decisions. The Owner has since accepted all three remaining recommendations, after accepting U-3. CORR2.CORR1 binds those decisions and updates every dependent status statement. **No rule, proof, signature, partition, witness, trace, migration rule, count or positive control changes.** §0A lists every changed location.

**Two statuses that must never be merged:**

| Status | Value |
|---|---|
| Owner acceptance of the four methodology choices (Architecture C; direction-only bearing on incomplete content; conservative DE-4 ceiling; U-3 proven sharing only) | **ACCEPTED — controlling Owner inputs** |
| Owner acceptance of this candidate *package* as the physical successor contract | **NOT ACCEPTED.** `ownerAccepted = false`, `independentlyVerified = false`, `controlling = false`, `implemented = false` until a fresh independent IV and a later package acceptance and binding. |

**Status-reading clause for text incorporated by reference.** Several sections of CORR1 (`02505e92…`) and CORR2 are incorporated here by reference, and they carry the wording that was current when written. That includes "conditional on Owner acceptance of SEP-DE4", "Owner decision surface 1/2/2b/3", "option A / option B" for these choices, and "under SEP-DE4 option B". Read every such phrase through the Owner Decision Ledger (§14):

- the methodology choice is **Owner-decided (ACCEPTED)**;
- a projection that phrase described as conditional is now a **candidate migration consequence pending independent verification and later authorized materialization**;
- "option B" alternatives are historical decision provenance only, not open options.

The following stay byte-intact and keep their status:

- the controlling Stage-2 methodology `cb08b51e…6c73`;
- CASE-3.4 v1.3 `dae81438…`;
- CASE-1;
- the CORR1, CORR1.IV1 and CORR2 packages;
- every historical artifact.

---

## 0. REQUIRED SUMMARY (Owner task CORR2.CORR1 §13)

```text
PARENT_CORR2_SHA256                      = 5776b6d37168dc25f2a2efd907f5f54b559f083181347273090e2c60c2eec7bb
ARCHITECTURE_C_OWNER_DECISION            = ACCEPTED
PARTIAL_DIRECTION_OWNER_DECISION         = ACCEPTED
DE4_OWNER_DECISION                       = ACCEPTED_CONSERVATIVE_NON_DISCRIMINATING
U3_OWNER_DECISION                        = ACCEPTED_PROVEN_SHARING_ONLY
OPEN_OWNER_METHODOLOGY_SURFACES          = 0
OWNER_DECIDED_METHODOLOGY_SURFACES       = 4
F01_GENERIC_H7_COVERAGE                  = PROVEN_EXHAUSTIVE
EV_INPUT_SIGNATURE                       = EXACT_AND_CLOSED
AUTHOR_POSITIVE_CONTROL                  = PASS
A_E023_EVALUABILITY                      = EVALUABLE
A_E023_CANDIDATE_SUCCESSOR_BEARING       = NON_DISCRIMINATING   (under the accepted DE-4 choice;
                                                                  physical record unchanged)
A_E001_REQUIRES_READJUDICATION           = YES
CONTROLLING_VIEW_MECHANICAL_PROJECTIONS  = 5   (candidate migration consequences; not materialized)
CONTROLLING_VIEW_VALUE_CHANGES           = 3   (candidate; not materialized)
HISTORICAL_DE4_MECHANICAL_PROJECTIONS    = 68  (candidate; not materialized)
HISTORICAL_DATA_MUTATION_REQUIRED        = NO
ENVIRONMENT_OUTCOME_PRESERVATION         = NOT_YET_PROVEN
LOAD_BEARING_CLASS_D_RULES               = 0
PACKAGE_OWNER_ACCEPTED                   = NO
PACKAGE_INDEPENDENTLY_VERIFIED           = NO
PACKAGE_CONTROLLING                      = NO
PACKAGE_IMPLEMENTED                      = NO
READY_FOR_INDEPENDENT_IV                 = YES
```

Retained technical results from CORR2, unchanged:

- NACR_EXPLICIT_CLAUSE_COUNT = 1;
- GENERIC_H7_ROUTE_EXISTS_OUTSIDE_NACR = NO;
- EVALUABILITY_GATE_SET = COMPLETE_CANDIDATE;
- COMPONENT_PARTITION = SUPPLIED | ORDINARY_MISSING_ASSESSABLE | NON_ASSESSABLE, with AV-6 holding contradictions;
- EDGE_STATE_USED_BY_EVALUABILITY = NO;
- F02 / F04 / F05 architecture preserved = YES;
- DE4_CLASSIFICATION = C and PARTIAL_DIRECT_SUPPORT_CLASSIFICATION = C (derivational class, unchanged by Owner acceptance; see §13).

Terminal state: **`STAGE2_SUPPORTCLASS_EVALUABILITY_SEMANTIC_SEPARATION_1_CORR2_CORR1_CORR1_CORR1_CORR1_READY_FOR_IV`** (this act; §0D)

---

## 0D. CORR2.CORR1.CORR1.CORR1.CORR1 REPORTING-CONSISTENCY LEDGER (this act)

| # | Stale remnant in CORR2.CORR1.CORR1.CORR1 | Correction | Location |
|---|---|---|---|
| A | §2: "Claude authored the parent, CORR1, CORR2, CORR2.CORR1 and this CORR2.CORR1.CORR1." | Now names the exact current chain: "…CORR2.CORR1.CORR1, CORR2.CORR1.CORR1.CORR1 and this reporting correction CORR2.CORR1.CORR1.CORR1.CORR1". Claude remains ineligible to verify independently; the fresh IV must be non-Claude. | §2 |
| B | §17 had been carried byte-identical from CORR2.CORR1. Its heading, the "performed in this act" items, the section-comparison language, the file-count and porcelain baseline, and the scratch path all belonged to an earlier act (CORR2.CORR1). | §17 is rewritten as the validation and preservation ledger of the CORR2.CORR1.CORR1.CORR1 positive-control act. Its physical source is that act's manifest `4b21d905…`. | §17 |

**Identity maintenance (necessary for a successor file; not content corrections):**

- title, Act and Mode lines;
- the new relation paragraph;
- the §0 terminal-state line;
- §0C's heading, now labelled the previous act's ledger;
- the §18 terminal-state block.

In §18, CORR2.CORR1's gate paragraph is labelled as an inherited record; its wording is not changed.

**Byte-identical to the parent:** every section other than the header, §0, §0C (heading only), §0D (new), §2, §17 and §18. That includes §8, recorded in the manifest's section comparison.

**Scope note.** §3 (the CORR2 authority ledger) still says "unchanged in this act", which refers to CORR2. It is retained unchanged as a historical ledger, because this act is bounded to the two remnants above.

```text
PARENT_CANDIDATE_SHA256            = 0d8cfe2279f1f7c76f514cfff18af6f0a25a37d9bd76ade325be38a931f22293
CURRENT_ACT_AUTHORSHIP_TEXT        = CORRECTED
CURRENT_VALIDATION_SECTION         = CORRECTED
CURRENT_FILES_HASHED_BEFORE        = 1386   (the CORR2.CORR1.CORR1.CORR1 act's baseline, per its manifest, as §17 now records;
                                             this reporting act's own baseline is 1389 — see the manifest)
CURRENT_HEAD                       = 2567223087d99b40bdfd174eed32566be7080e44
TRACKED_DIFF                       = EMPTY
STAGED_DIFF                        = EMPTY
POSITIVE_CONTROL_CHANGED           = NO
AUTHOR_POSITIVE_CONTROL            = PASS
DIRECT_SUPPORT_REACHED             = YES
METHODOLOGY_RULES_CHANGED          = NO
OWNER_DECISIONS_CHANGED            = NO
OPEN_OWNER_METHODOLOGY_SURFACES    = 0
PACKAGE_OWNER_ACCEPTED             = NO
PACKAGE_INDEPENDENTLY_VERIFIED     = NO
PACKAGE_CONTROLLING                = NO
PACKAGE_IMPLEMENTED                = NO
READY_FOR_FRESH_INDEPENDENT_IV     = YES
```

The parent IV remains **FAIL (BLOCKING = 1)** until a fresh non-Claude IV verifies the corrected successor package. The four Owner methodology decisions remain accepted.

---

## 0C. CORR2.CORR1.CORR1.CORR1 POSITIVE-CONTROL CORRECTION LEDGER (previous act; retained)

**Finding closed author-side:** CORR2-CORR1-CORR1-IV1-F01 (BLOCKING; the only finding). The parent IV verdict stays **FAIL**. This author correction does not turn it into a PASS; a fresh non-Claude IV is required.

| Defect (IV) | Correction (derived under the unchanged contract) |
|---|---|
| M-DECISIONS-SEEK-RELATIONAL-SAFETY was marked NOT_SELECTABLE although c1 "documented decision(s)" is entailed by the retain/discard decision (b3). The control applied a trade-off requirement the row does not have, and used missing c2 to block selection. | **SELECTED**: c1 SUPPLIED (b3), c2 MISSING. D-11 dispatch l.831 requires no trade-off for this M. No harmony content is invented, and missing c2 is not negative evidence. |
| Its consuming TT, TT-SFJSFP-REL, was not materialized (W-3), and the M was absent from Cmp⁺(TEST-RESULT), Cmp⁺(ARGUMENT-QUALITY) and the alternatives of X. | The record is materialized. All three trace universes are recomputed. The M is added to Alt(X) and its directionality is derived: **NON_DIRECTIONAL** (its c1 basis co-entails TEST-RESULT c3). |
| The H-2.2 one-component reading was not uniform. | All 74 dispositions are re-derived under one stated reading (§8.1). Each NOT_SELECTABLE carries an M-specific rationale, with registry or dispatch anchors for near cases. |
| ARGUMENT-QUALITY c4 ("title/wealth/tenure/force not the deciding basis") was traced to b4 alone. b4 names rank/status/prior agreement/proposer, not wealth or force. | c4 is bound to **b3+b4**. b3's "solely" is the necessary and sufficient basis, because it excludes every non-result basis. b4 corroborates rank/status ≈ title/tenure and is never relied on alone. The registry component is unchanged. |
| Consequence for X, not a defect fix | TEST-RESULT c3 (basis b3) now co-entails DECISIONS-SEEK c1 and ARGUMENT-QUALITY c4, so it is **NON_DISTINGUISHING**. X's direction rests on **c2 alone** (the road-test clause, no co-entailment with any of the 6 comparators). This is derived, not chosen. |

```text
PARENT_CANDIDATE_SHA256                    = 08bcf3bde0e06cf3eca31e1c6f6bb6673173b1c743cfeb66c60bd13b53369abe
PARENT_IV_VERDICT                          = FAIL
PARENT_IV_BLOCKING                         = 1
CORRECTED_FINDING                          = CORR2-CORR1-CORR1-IV1-F01
POSITIVE_CONTROL_REGISTRY_DISPOSITIONS     = 74
RELATIONAL_SAFETY_M                        = SELECTED
RELATIONAL_SAFETY_C1                       = SUPPLIED
RELATIONAL_SAFETY_C2                       = MISSING
RELATIONAL_SAFETY_CONSUMING_TT             = TT-SFJSFP-REL
POSITIVE_CONTROL_SELECTED_M_COUNT          = 6
POSITIVE_CONTROL_MATERIALIZED_RECORD_COUNT = 7
TEST_RESULT_COMPARATOR_COUNT               = 6
ARGUMENT_QUALITY_C4_BASIS                  = b3+b4 (b3 "determined solely by the measured test result" necessary and sufficient; b4 corroborating; b4 alone insufficient)
W1                                         = PASS
W2                                         = PASS
W3                                         = PASS
W4                                         = PASS
DIRECTIONALITY_TRACE                       = PASS
AUTHOR_POSITIVE_CONTROL                    = PASS
DIRECT_SUPPORT_REACHED                     = YES
METHODOLOGY_RULES_CHANGED                  = NO
OWNER_DECISIONS_CHANGED                    = NO
OPEN_OWNER_METHODOLOGY_SURFACES            = 0
HISTORICAL_DATA_MUTATION_REQUIRED          = NO
ENVIRONMENT_MATH_CHANGED                   = NO
PACKAGE_OWNER_ACCEPTED                     = NO
PACKAGE_INDEPENDENTLY_VERIFIED             = NO
PACKAGE_CONTROLLING                        = NO
PACKAGE_IMPLEMENTED                        = NO
READY_FOR_FRESH_INDEPENDENT_IV             = YES
```

Real-data counts are untouched: Section-I 6; execution cells 110; candidate mechanical projections 5; re-adjudication 1; candidate value changes 3; historical mapped 122; historical DE-4 projections 68; historical recompute 54; supportClass record objects 377; normalized walk 2082.

---

## 0B. CORR2.CORR1.CORR1 MICRO-CORRECTION LEDGER (previous act; retained)

| # | Defect in CORR2.CORR1 | Correction | Location |
|---|---|---|---|
| 1 | §13's U-3 row said "rule text verified by IV". No fresh independent IV of the CORR2 / CORR2.CORR1 rule text has occurred. | Replaced with "Owner decision accepted; rule text pending fresh independent IV". The package was then scanned for any other claim that its current rule text is independently verified: none remains. Every other PASS is a labelled author self-test or derivation check. | §13 |
| 2 | The walk count disagreed: the candidate said 2082, while the census had `walk.filesScanned = 2083` and a note explaining 2082. | Re-ran the same read-only walk (same roots, `.json`/`.jsonl`, same exclusions). The raw walk now finds 2086 files. The 4 extra are this workstream's own outputs since CORR2: the CORR2 census and manifest, and the CORR2.CORR1 census and manifest. Excluding the package's own outputs, as the CORR2 measurement intended, gives exactly **2082**. Those outputs contribute **0** supportClass records, so **377** is unchanged. **Source of 2083:** when the CORR2 census was regenerated after the U-3 addendum, its own first draft was already in the output directory, and the walk counted it. The candidate, `walk.filesScanned` and the census note now all read 2082. | census `walk`; candidate §3 and §12 (already 2082, unchanged) |
| 3 | §2 said "Claude authored the parent, CORR1 and this CORR2", which is stale here. | Now "Claude authored the parent, CORR1, CORR2, CORR2.CORR1 and this CORR2.CORR1.CORR1". The fresh IV must still be non-Claude. | §2 |

```text
PARENT_CANDIDATE_SHA256            = e7448feb3cab1f003a9a12894ca525efb556321ae39049be97a521435232ff57
FALSE_CURRENT_IV_CLAIMS            = 0
U3_RULE_VERIFICATION_STATUS        = PENDING_FRESH_INDEPENDENT_IV
ACT_AUTHORSHIP_TEXT                = CORRECTED
CENSUS_FILES_SCANNED               = 2082
CANDIDATE_WALK_COUNT               = 2082
CENSUS_NOTE_COUNT                  = 2082
SUPPORTCLASS_RECORD_OBJECTS        = 377
OPEN_OWNER_METHODOLOGY_SURFACES    = 0
OWNER_DECIDED_METHODOLOGY_SURFACES = 4
METHODOLOGY_RULES_CHANGED          = NO
HISTORICAL_DATA_MUTATION_REQUIRED  = NO
PACKAGE_OWNER_ACCEPTED             = NO
PACKAGE_INDEPENDENTLY_VERIFIED     = NO
PACKAGE_CONTROLLING                = NO
PACKAGE_IMPLEMENTED                = NO
READY_FOR_INDEPENDENT_IV           = YES
```

The four methodology choices remain Owner-accepted controlling inputs (§14). That is a separate status from the package, which is not verified, accepted, controlling or implemented.

---

## 0A. CORR2.CORR1 CHANGE LEDGER (status binding only)

| Location | CORR2 (stale) | CORR2.CORR1 |
|---|---|---|
| Header / status | U-3 the only Owner input | four Owner-accepted methodology choices; package status unchanged; status-reading clause for incorporated text |
| §0 summary | OWNER_SURFACE_COUNT = 3 open + 1 decided; DE-4 bearing "under option A" | 0 open / 4 Owner-decided; Owner-task §13 fields; package-status fields |
| §1 closure map | "Surface 4 removed from the future frame" | all four choices recorded in the Owner Decision Ledger |
| §2 quality gate | "Surfaces 1–3 remain normative"; "ready for an Owner decision" | no open normative surface; human claim now ends "ready for independent IV" |
| §3 ledger | "UNRESOLVED NORMATIVE: Surfaces 1–3" | none |
| §7 | "does not accept Architecture C itself (Surface 1)" | Architecture C is Owner-accepted; the candidate *package* is not |
| §11 A-E023 | "SEP-DE4 option A (Surface 3, not yet decided)" | the accepted DE-4 choice; candidate projection only; physical row unchanged |
| §12 counts | "SEP-DE4-conditional" | candidate migration consequences pending verification and materialization |
| §13 classification | Owner surfaces referenced | derivational class preserved (C); separate OWNER_DECISION_STATUS column |
| §14 | FUTURE OWNER DECISION FRAME (Surfaces 1–3) | **OWNER DECISION LEDGER** (four ACCEPTED decisions) |
| §17 / §18 | CORR2 validation and terminal state | CORR2.CORR1 validation, preservation and terminal state |

Unchanged:

- §4–§6 (preserved core, F01 proof, EV signature, partition, AV-6);
- §7.1–§7.2 rules;
- §8 positive control;
- §9 tests;
- §10 state machine;
- §15 Environment safety;
- §16 limitations;
- Appendix A.

## 1. CLOSURE MAP

| Item | Defect (CORR1.IV1) | CORR2 correction | Where |
|---|---|---|---|
| CORR1-IV1-F01 (BLOCKING) | It was proved that §D has one explicit abstention clause. It was **not** proved that the generic §C / §E / H-7 route — "a required component of a kind documents cannot establish" — reduces to that clause. Declarations outside NACR were held as a policy restriction. | An exhaustive component-domain proof over all 74 Ms and 219 required components, using four authority-grounded reading premises. **Branch A:** every lawful current-authority instance reduces to NACR-1 (component side) or to EV-1 (source side). A declaration outside NACR is now invalid **as a derived consequence**, not a policy choice. The reduction is version-bound to the registry identity. | §5, Appendix A |
| CORR1-IV1-F02 (MAJOR) | U-3 hid an irreducible methodology choice. | **Resolved by the Owner addendum:** PROVEN-SHARING-ONLY. U-3 routes to `UNIQUENESS_UNRESOLVED` and never to SHARED or DIRECT. SD-3, the invariants, the firewalls, O-1, the tests and the decision frame are updated. | §7 |
| CORR1-IV1-F03 (MAJOR) | SEP-I-10 and S3 declared a read set that omitted `componentSupply`, which EV-3 actually reads; the partition relied on a precedence rule. | One exact, closed EV input signature, stated identically in SEP-I-10 and S3. An explicit component partition. A new admission invariant SEP-AV-6 holds SUPPLIED ∧ NON_ASSESSABLE; the CORR1 precedence rule is deleted. | §6 |
| CORR1-IV1-F04 (MINOR) | The author positive control named ARGUMENT-QUALITY in CO_ENTAILS without SELECTING it, so W-4 failed. | Rebuilt with a full 74-entry witness (CORR2: 5 SELECTED, 6 records, two traces — **superseded by the CORR2.CORR1.CORR1.CORR1 reconstruction in §8: 6 SELECTED, 7 records, three traces; see §0C**). W-1..W-4 and T-1 hold, and the control reaches U-1 DIRECT_SUPPORT. | §8; census `positiveControl` |
| Owner decisions | U-3 decided (proven sharing only); then Architecture C, direction-only bearing on incomplete content and the conservative DE-4 ceiling accepted | All four are recorded as controlling Owner inputs in the Owner Decision Ledger. No methodology choice remains open. | §7, §14 |

Not reopened: Architecture C; the F02 denominator architecture (W-1..W-4); F03 classifications; the F04 B-3 architecture (Cmp⁺, co-entailment, T(r), MD-1..MD-3, HOLD-T); the F05 migration architecture; REG-007; O-1 as a deferred obligation; the Owner's U-3 decision.

---

## 2. ROLE, SCOPE, INDEPENDENCE, QUALITY GATE

**Role.** METHODOLOGY AUTHOR, Owner-assigned for this act. Exactly three new artifacts are authorized in this directory.

**Independence.**

- Claude authored the parent, CORR1, CORR2, CORR2.CORR1, CORR2.CORR1.CORR1, CORR2.CORR1.CORR1.CORR1 and this reporting correction CORR2.CORR1.CORR1.CORR1.CORR1. Correcting one's own candidate after an independent FAIL is authoring, not verification. Claude is therefore ineligible to verify this package independently.
- Codex authored both IVs and authored no part of this text.

The fresh IV of this package must be non-Claude (Codex or Z-Ai, AGENTS.md §10).

**Quality gate.** `skills/mergevue-agent-quality-gate/SKILL.md` (`c80d3aa9…`) was applied in its bounded critical-claim and failure-diagnosis mode only: no retrospective, no workflow artifact. The diagnosis established before authoring:

| Gate element | Established |
|---|---|
| Human claim | "Evaluability is complete and edgeState-independent; uniqueness is fail-closed; the package is ready for independent IV." |
| Exact load-bearing defects | (1) a completeness assertion with no exhaustive proof; (2) a declared read set that differed from the operative predicate; (3) a hidden normative choice (U-3); (4) a self-test that violated its own W-4 |
| Recurring pattern behind the repeated FAILs | Each FAIL found a **claim stated more strongly than its evidence**: universal closure, label equivalence, a derived DE-4 selector, a coverage claim. CORR2 therefore proves each claim exhaustively over the enumerated domain, or narrows it. |
| Source authority | Controlling Stage-2 methodology §A, §C, §D, §E, §F, §G, §H, §J; C34 §5–§7, §13, §16; CASE-1 §13–§14, §22; coder view schema `abstention`; field-source matrix |
| Mechanical vs normative | The 219-component reduction is a derivation (B). The EV signature and partition are specification consistency (C, mechanical). All four normative choices (Architecture C, direction-only incomplete bearing, the DE-4 ceiling, U-3) are now Owner-decided. No open normative surface remains. |
| Owner decisions | All four accepted (§14 ledger). F01 produced **no** new surface (§5.6). Open methodology surfaces: **0**. |
| Smallest correction | The F01 proof plus the derived invalidity rule; the exact signature plus AV-6; the U-3 rewrite to the Owner's decision; the rebuilt control. Nothing else. |

---

## 3. IDENTITY VERIFICATION AND AUTHORITY LEDGER

| Artifact | SHA-256 | Bytes | Result |
|---|---|---:|---|
| CORR1 candidate | `02505e92fd018439f9aba7d4b551fe5542c1be92c7bbb7d4f63994dc1dfa51e9` | 102697 | exact |
| CORR1 impact census | `d36e386d3b90032eca02ee28a32f14ea50b5acbc049bd26cea614f0efaf67b9a` | 142192 | exact |
| CORR1 manifest | `b187288d74172ee36807cd1f3db77ce98de55137139f54769079fc33642847ac` | 20314 | exact |
| CORR1.IV1 report | `723ebb27014efb2f71b5d69b609470ea04cf65322141dae17b19cf4d8e7bc5a2` | 36069 | exact |
| CORR1.IV1 findings | `da0a13abbab57ff614b469cbedf5b678ff621eb901269068cc8e66f46c19abdc` | 122033 | exact |
| CORR1.IV1 manifest | `b8fbc72d8d3d1b194823109d3eb48793e53aa4de0fef270deeff284126564582` | 45850 | exact |

**Evidence ledger (AGENTS.md §14A.2).**

- **READ:**
  - Stage-2 methodology `cb08b51e…`: §A.5–A.8 (l.160–191); TT blocks (l.196–793); §C (l.794–905); §D (l.906–998, all 74 rows); §E (l.1025–1042); §F.1–F.5 (l.1109–1197); §G (l.1199–1208); §H (l.1210–1222); §I; §J (l.1228–1234); ledgers §Q / §U / §W (l.1304–1690).
  - C34 v1.3 `dae81438…`: §5.8 (l.139), §6, §7, §13.2 (l.492), §16 (l.590, 621).
  - CASE-1 members, read in memory from the archive `a64ad01e…`; checksums matched in CORR1 and unchanged in this act.
  - Coder view schema `0cb5a6b5…` (abstention group); field-source matrix `1fb84aed…`.
  - The CORR1 and CORR1.IV1 packages.
- **DERIVED:**
  - 74 Ms and 219 required components;
  - 74/74 Ms consumed only by DOCUMENTARY_COMPLETE_CANDIDATE / EXACT TTs;
  - one explicit abstention clause;
  - the full component-kind classification (Appendix A).
- **INSPECTED:** root / `main` / HEAD `2567223` / 706 `-uall` porcelain entries, all untracked, with no tracked or staged diff, before the act. A census re-walk of 2082 JSON/JSONL files and 377 records.
- **ELIMINATED:**
  - "Does the generic H-7 route exist outside NACR on the frozen registry?" — GATES 1 and 2: decided by the source proof (§5), not asked of the Owner.
  - "U-3 semantics?" — decided by the Owner addendum.
- **UNRESOLVED NORMATIVE:** none. All four methodology choices are Owner-accepted (§14).

---

## 4. PRESERVED FROM CORR1 (incorporated by reference to `02505e92…`)

Unchanged, by CORR1 section:

- §5 preserved core and Architecture C;
- §6.1–§6.2 record fields and grain;
- §6.5 `selectionCensusWitness` (W-1..W-4);
- §6.6 `directionalityTrace` (T-1..T-5);
- SEP-AV-1, AV-2, AV-4, AV-5;
- §7.1 EV-1, EV-2, EV-4;
- §8 reason taxonomy;
- §9.1–§9.4 (B-1a, B-1b, B-2, the B-3 operational definition);
- SEP-U-X / U-0 / U-1 / U-2;
- §10 SD-1, SD-2, SD-4, SD-5;
- §11 O-1(a)–(i);
- §13 SEP-DE4 (Class C);
- §14 migration rules and counts;
- §15 backward compatibility;
- §17 A-E001;
- the SEP-FW-1..FW-25 firewalls;
- the §21 classifications not changed below.

CORR2 replaces, in CORR1:

- §6.3 SEP-I-3, I-8 and I-10;
- §6.4 component partition and precedence;
- §6.7, by adding SEP-AV-6;
- §7.2–§7.5, the closure proof and the EV-3 definition;
- §9.5 SEP-U-3;
- §9.6, the SHARED facets;
- §10 SD-3;
- §12 S3 / S7;
- §18 test C;
- §20 decision frame;
- §21, the rows listed in §13 below;
- SEP-FW-26.

---

## 5. CORR1-IV1-F01 — GENERIC H-7 COVERAGE: EXHAUSTIVE REDUCTION (BRANCH A)

### 5.1 The two routes kept apart

- **Explicit route:** NACR, component-local §D clauses. Exactly **1**: M-RES-ASYMMETRIC-RETENTION c3 (§D l.997).
- **Generic route:**
  - §C notDeterminableCondition (l.796): "required component is of a kind documents cannot establish or source inaccessible";
  - §E edgeState NOT_DETERMINABLE (l.1031): "component undocumentable or source inaccessible";
  - H-7 (l.1220): "component undocumentable → NOT_DETERMINABLE";
  - the view schema's abstention mandatoryWhen entry for H-7.

The question proved here: on the frozen 74-M registry, does any lawful instance of the generic route exist outside NACR-1 and EV-1?

### 5.2 Reading premises (each authority-grounded; none chosen for convenience)

- **P1 — the generic route is kind-level, not case-level.**
  - §C words the condition as a component "**of a kind** documents cannot establish".
  - A case-level reading ("this record set happens not to document c") would make NOT_DETERMINABLE coextensive with ordinary missing evidence. Authority routes that elsewhere:
    - H-3 (l.1216): components not in the fact are missingComponents, and no inference fills them;
    - J-3 (l.1231): silence → GAP;
    - J-6 (l.1234): not found ≠ absent, not established ≠ false;
    - §D l.987: "absent → fail closed (**component missing**)".
  - The source-inaccessible half of the generic route is source-side and already EV-1 (C34 §13.2 l.492 CONTENT_INACCESSIBLE; §16 l.590/621 DOCUMENT_CONTENT_INACCESSIBLE).
  - **Hence:** generic H-7 applies to a component only if that component's *kind* is non-establishable by documents.
- **P2 — every §D component is a documentary kind by registry construction.**
  - §D is titled "OBSERVABLE ORGANIZATIONAL PROPOSITION REGISTRY" (l.906).
  - §A.7(f) (l.179) and §G-8 (l.1207) send genuinely inner-state propositions (authenticity, lived meaning, motive, psychological capacity, genuineness) to `aN→UNOBS` at **TT-atom level**, never into an M.
  - §F.1 (l.1109): each documentary-complete row maps atoms to a "documentary interpretation = the M's preciseMeaning", with row-by-row semantic attestation (§N.2).
  - **Mechanical fact:** all 74 Ms are consumed only by DOCUMENTARY_COMPLETE_CANDIDATE / EXACT TTs; no M is consumed by an UNOBSERVABLE or CONTEXTUAL row.
- **P3 — the registry states its own documentary limits.** Where a component's documentary establishment is constrained, its row states the consequence:
  - only M-RES-ASYMMETRIC-RETENTION c3 declares mandatory abstention (NOT_DETERMINABLE), restated at l.766, l.900, l.1206, l.1121 and in ledger l.1676;
  - every other constrained component declares a **missing / OPEN** consequence:
    - TACTICAL-EXTERNAL-ACQUISITION c3 "absent → fail closed (component missing)" (l.987);
    - NO-EXTERNAL-ARBITER "NOT established by silence; closed-world reading … forbidden" (l.953);
    - SACRED-UNITY "weaker framing → OPEN" (l.1671);
    - ORDER-SUSTAINED-FLEXIBILITY "c2 required; no causal counterfactual is claimed or detected" (l.992, l.1674).
- **P4 — no other current authority declares a non-documentable component kind.**
  - C34 recognizes source inaccessibility (EV-1) and semantic non-expansion. §5.8 (l.139): no added motive, causality or recurrence; that routes to *missing*, not non-assessable.
  - CASE-1 declares no component kind.
  - The view schema's mandatoryWhen list (G-7, G-8, H-7, G-1) adds no component beyond these: G-7 is NACR-1, G-8 is TT-atom-level, H-7 is this generic route, and G-1 is source-side.

### 5.3 Exhaustive component-domain audit (Appendix A; full JSON in the census)

All **219** required components of the 74 Ms were classified, each with five attributes:

- **semantic requirement:** the component text, verbatim;
- **component kind:** 25 kinds;
- **documentary assessability basis:** a legend code bound to authority;
- **explicit NACR clause:** YES / NO;
- **generic H-7 applicability:** YES / NO, with the authority locator and the successor EV treatment.

| Kind (count) | Documentary basis |
|---|---|
| REFERENT (60) | actor / object / resource / domain named by certified content; G-1/G-2/G-6; any C34 §6 form |
| ACT_INSTANCE (28), OUTCOME_STRUCTURE (1) | explicit behavioral record or event sequence; C34 §6 DE-1..DE-3, §8; G-6 |
| RECORD_FRAME (19), RECORD_TREATMENT (1), STATED_PURPOSE (1) | official presentation, framing or statement; G-1, G-4, FO-PRES; never genuineness (G-8) |
| RULE_STRUCTURE (18), RULE_OR_DECISION (1), CONTROL_RELATION (5), STRUCTURE_COINCIDENCE (1) | rule / role / terms / control records; G-2/G-3/G-5; RC1, RD01 interpretations |
| BASIS_CRITERION (16) | deciding / allocation / gating basis stated or necessarily entailed by the record; G-6 "unless the record itself evidences … the deciding basis"; C34 §7.2 |
| TEMPORAL_STANDING (13) | standing / recurring / over-time records; CH-FRAME, K-6, C34 §9, §11 |
| RELATION_LINKAGE (12), FUNCTION_RECORD (2) | documentary relational witness (§F.4.1 L-1..L-6); row-disclosed documentary ceiling; no causality (C34 §5.8) |
| EXCLUSION_NEGATIVE_BASIS (8) | affirmative record of the actual basis excluding the named one; never silence (J-6) |
| PRACTICE_MODE (8) | C34 §8 operative routes |
| FLOW_DESTINATION (6) | transfer / allocation records |
| OUTPUT_RECORD (5), CONDITION_RECORD (1) | recorded output or documented condition; G-6 |
| STATUS_EXCLUSIVITY (4) | competent affirmative record; absent → component missing (l.987) |
| CAPACITY_DEMONSTRATED (3) | the evidence route named in the row (applied instance or competent record of demonstration) |
| GATED_GOOD (2) | open category; any organizational-grant member satisfies; inner-feeling reading excluded by G-8 and §A.7(f) |
| BOUNDED_NEGATIVE_CONTENT (2) | COMPETENT_AFFIRMATIVE_ABSENCE grade (J-2, J-4) |
| SCOPE_TIME_MATCH (1) | C34 §10, §11 fields |
| **CROSS_CHANNEL_COMPARISON (1)** | **M-RES-ASYMMETRIC-RETENTION c3: assessable iff a lawful comparison basis exists; otherwise mandatory abstention = NACR-1** |

**Inner-state-adjacent wording audit.** 43 components carry words such as belief, meaning, desire, loyalty, trust, care, commitment, purpose, faith, understanding, framing, harmony or capability. Every one is phrased as *presented / framed / demonstrated / recorded / evidenced / operative*, or as an open-category organizational grant. Examples:

- M-PRES-ABSOLUTE-BELIEF c2/c3: a presented belief set and claim;
- M-MEMBERSHIP-ACQUIRED c2: "repeated **demonstrated** loyalty AND reliability AND care AND commitment";
- M-SACRED-UNITY-PERSISTENCE-FUNCTION c3: "the record's framing or operative content affirmatively links…". The ledger at l.1494 says the endpoint is "not claimed as certified inner motive".
- M-DECISIONS-SEEK-RELATIONAL-SAFETY c2: "decisions justified by or structured to preserve";
- M-RES-ASYMMETRIC-RETENTION c1/c2: channel *identification*, whose heterogeneity is exactly NACR-1's trigger.

None asks a document to certify an inner state (G-8).

### 5.4 Result

```text
GENERIC_H7_TO_NACR_REDUCTION = PROVEN   (registry identity cb08b51e…)
  component side : the only component whose kind can be non-establishable is
                   M-RES-ASYMMETRIC-RETENTION c3, and only under its own trigger → NACR-1 (EV-3)
  source side    : "source inaccessible" → sourceQualityState CONTENT_INACCESSIBLE (EV-1)
  all 218 other components: documentary kinds; unsupplied → ORDINARY_MISSING_ASSESSABLE
GENERIC_H7_ROUTE_EXISTS_OUTSIDE_NACR = NO
```

### 5.5 Successor consequences (replaces CORR1 §6.4 "inadmissible abstention" wording and §7.5)

- **SEP-NACR-1 (Class B, a derived consequence).** On the frozen registry, a component non-assessability declaration naming any component other than NACR-1's (M-RES-ASYMMETRIC-RETENTION c3) asserts that a documentary kind is non-establishable. That contradicts P2–P4 and the Appendix A row for that component, so the declaration is **invalid**. This is no longer a policy restriction: it is what the source proof entails. Routing an invalid declaration to HOLD-NA is the Class C successor procedure; the hold is correctable through H-3 (the component is ordinarily missing) or through the §M registry route.
- **SEP-NACR-V (Class C, version binding).** The reduction is bound to registry `cb08b51e…`, in the same way C34 §6 binds its constitutive-exception emptiness premise to a corpus version. Any §M registry change that adds or alters a requiredComponent must re-establish the Appendix A reduction for the changed rows; a newly non-documentable kind must receive its own NACR clause. Until that happens, SEP-NACR is not applied to the changed registry: records under the unverified registry identity are HOLD-NA.
- **No new Owner surface.** Branch A is a source derivation. No deliberate exclusion of a lawful route remains, so nothing normative is hidden.

### 5.6 Hard distinctions preserved (Owner task §10)

| Distinction | How CORR2 keeps it |
|---|---|
| ordinary missing ≠ non-assessable | PART = ORDINARY_MISSING_ASSESSABLE unless an admitted NACR declaration exists (§6.2) |
| PARTIAL ≠ INDETERMINATE | edgeState is not in the EV signature (§6.1) |
| source unavailable ≠ component semantically non-assessable | EV-1 (sourceQualityState) vs EV-3 (NACR); separate gates and reasons |
| coder uncertainty ≠ method-declared non-assessability | uncertain entailment → not entailed → ORDINARY_MISSING (H-3). NACR-1 requires its registry trigger, not uncertainty. Bearing uncertainty is MD-3 UNRESOLVED (B-3), not EV. |
| no explicit NACR sentence ≠ proof of assessability | assessability is proved per component by Appendix A, not inferred from the absence of a sentence |
| generic H-7 ≠ free-form abstention | SEP-NACR-1: outside NACR-1 a declaration is invalid by derivation |
| edgeState never controls evaluability | SEP-I-10 (§6.1) |

---

## 6. CORR1-IV1-F03 — EXACT AND CLOSED EV INPUT SIGNATURE; COMPONENT PARTITION

### 6.1 Signatures (stated identically in SEP-I-10 and S3)

```text
EV_INPUT_SIGNATURE (closed) = ⟨
  sourceQualityState,
  ambiguity.{competing M-ids, resolutionState},
  abstention.declarations[{code, mechanismPropositionId, componentId}],
  componentSupply[].componentId   (entries for the record's leaf/counter M),
  mechanismPropositionIds,
  treeTargetIds,
  R = { TT rows: verdict, docStatus, mechExpr; §C.0 C-3 status;
        §D rows: requiredComponents; SEP-NACR clause list; registry identity } ⟩

ADMISSION_INPUT_SIGNATURE   = EV_INPUT_SIGNATURE ∪ ⟨ edgeState ⟩
  edgeState is read ONLY by SEP-AV-1 / AV-2 consistency checks.
  An admission failure yields a HOLD and never an evaluability value.
```

Nothing outside EV_INPUT_SIGNATURE is read by EV-1..EV-4. Nothing in it is a bearing output, W(f) or T(r).

**SEP-I-10 [CORR2].** For an admitted record, (`bearingEvaluability`, `bearingIndeterminacyReasons`) is a function of EV_INPUT_SIGNATURE exactly.

**Invariance.** For two admitted records that differ only in edgeState, the evaluability value is identical. A change of componentSupply alone can change only:

- admission (HOLD-NA under AV-6); or
- the partition between SUPPLIED and ORDINARY_MISSING_ASSESSABLE.

It never changes EV-3, because EV-3 fires only on NON_ASSESSABLE.

### 6.2 Component partition (replaces CORR1 §6.4 precedence)

Defined only for admitted records. For each required component c of the record's M:

| State | Condition | Source |
|---|---|---|
| SUPPLIED | c ∈ componentSupply[].componentId | §I componentSupply (CODER_JUDGMENT, H-3) |
| NON_ASSESSABLE | an admitted `NACR-k` declaration names c, and clause k is on c | view-schema `abstention` (CODER_JUDGMENT applying a registry trigger), SEP-NACR |
| ORDINARY_MISSING_ASSESSABLE | neither | derived |

- **Kind:** mixed. The derivation is mechanical over two coder-judgment inputs.
- **Grain:** per (edge × consuming TT) record. The evidence binding is that record's componentSupply entries, factIds and relationInstanceId.
- **Exactly one state per component.**
- **No precedence rule.** CORR1's "SUPPLIED over NON_ASSESSABLE" precedence is **deleted**. A contradiction is held, not interpreted.
- No further state is needed. Join satisfaction, competence, scope and time are establishment matters that §F.3 owns.
- `missingComponents` is not read; it remains an §F.3 input. A legacy inconsistency between componentSupply and missingComponents (e.g. A-E001) is an establishment-side defect outside EV, routed by migration (CORR1 §14).

**SEP-AV-6 [CORR2] (Class C).** A component that is both in componentSupply **and** named by an `NACR-k` declaration of the same record → **HOLD-NA (contradiction)**. A component cannot be SUPPLIED and NON_ASSESSABLE for the same bound evidence relation.

**SEP-EV-3 [CORR2].** Fails iff ∃ c: PART(r, c) = NON_ASSESSABLE.

### 6.3 Admission rule set (complete)

| Rule | Condition | Hold |
|---|---|---|
| AV-1 (CORR1) | edgeState NOT_DETERMINABLE without an EV-1 cause or an NACR declaration | HOLD-ND |
| AV-2 (CORR1) | edgeState AMBIGUOUS inconsistent with the ambiguity record | HOLD-AMB |
| AV-3 [CORR2 wording] | a declaration that is invalid by SEP-NACR-1; an NACR-domain record whose clause component is not SUPPLIED and that carries no explicit `NACR-1` or `NACR-1:CONDITION_NOT_MET` disposition; `SRC-INACCESSIBLE` without sourceQualityState CONTENT_INACCESSIBLE; a registry identity not covered by SEP-NACR-V | HOLD-NA |
| AV-4, AV-5 (CORR1) | trace incomplete; witness not closed or an alternative held | HOLD-T, HOLD-U |
| **AV-6 [CORR2]** | SUPPLIED ∧ NACR-declared on the same component | HOLD-NA |

Every hold is a correctable defect state: it is not a field value and not materializable (CORR1 SEP-I-11). `UNIQUENESS_UNRESOLVED` (§7) is not a hold.

---

## 7. U-3 — OWNER-DECIDED: PROVEN-SHARING-ONLY (controlling input to CORR2)

**Owner decision (Owner addendum to CORR2, 2026-10-05).**

- `SHARED_NON_UNIQUE` may be emitted only when positive directional bearing to more than one lawful alternative is actually established.
- *Failure to exclude an alternative is not positive evidence for that alternative.*
- The broadened SHARED option is **rejected**.

Architecture C itself is also Owner-accepted (§14, Decision 1). Neither decision accepts this candidate *package*: the package remains subject to a fresh independent IV and a later acceptance and binding.

### 7.1 SEP-U (replaces CORR1 §9.5 rule table; U-X, U-0, U-1, U-2 unchanged)

| ID | Condition (X directional, SUPPORTS_LEAF) | Result |
|---|---|---|
| SEP-U-X | W(f) fails W-1..W-4, or any alternative is HELD | **HOLD-U** (defect; not materializable; never DIRECT) |
| SEP-U-2 | ≥1 alternative of another Environment is DIRECTIONAL | `SHARED_NON_UNIQUE`, basis PROVEN_DIRECTIONAL_ALTERNATIVE. **The only route to SHARED.** |
| **SEP-U-3 [CORR2]** | no alternative DIRECTIONAL; ≥1 alternative INDETERMINATE | **UNIQUENESS_UNRESOLVED** (see below). No SHARED, no DIRECT. |
| SEP-U-0 | Alt(r) = ∅ | `DIRECT_SUPPORT` (ZERO_ALTERNATIVES) |
| SEP-U-1 | all alternatives NON_DIRECTIONAL | `DIRECT_SUPPORT` (SOLE_DIRECTIONAL_TARGET) |

**UNIQUENESS_UNRESOLVED** is the pipeline-level unresolved state the architecture already provides. No new `supportBearing` value is created.

- **Record:** `bearingEvaluability = EVALUABLE`, `bearingIndeterminacyReasons = null`, `supportBearing = null`.
- **Trace:** T(r) retains X's complete DIRECTIONAL trace, and its uniqueness section records basis `UNIQUENESS_UNRESOLVED` and lists the INDETERMINATE alternatives.
- No positive bearing is asserted for the unresolved alternative. No uniqueness is asserted for X.
- **Materializable.** It is a truthful terminal pipeline state, not a defect. Unlike HOLD-U, it does not block a successor view, because no correction can supply the missing alternative evaluation.
- **Recomputed** by S7 whenever an alternative's evaluability or directionality changes. If the alternative becomes NON_DIRECTIONAL the result is U-1; if it becomes DIRECTIONAL, U-2.

### 7.2 Dependent updates

- **SEP-I-3 [CORR2].** `supportBearing ≠ null ⇒ EVALUABLE`. For EVALUABLE records: `supportBearing = null ⟺ UNIQUENESS_UNRESOLVED` (T(r) basis UNIQUENESS_UNRESOLVED). This is the only EVALUABLE-null case, so a consumer distinguishes it from INDETERMINATE by `bearingEvaluability` alone.
- **SEP-I-8 [CORR2].** `DIRECT_SUPPORT` ⇒ W closed ∧ U-0/U-1. `SHARED_NON_UNIQUE` ⇒ W closed ∧ U-2.
- **SEP-SD-3 [CORR2].** SHARED / NON-UNIQUE = **proven** multi-Environment directional bearing on a closed denominator (U-2 only). This is the successor reading of CASE-1 §13's "matches a shared binding" and C34 §7.5's "supports multiple options". Unresolved competitors are never SHARED.
- **SEP-FW-26 [CORR2].**
  - UNIQUENESS_UNRESOLVED ⇏ SHARED_NON_UNIQUE;
  - UNIQUENESS_UNRESOLVED ⇏ DIRECT_SUPPORT;
  - UNIQUENESS_UNRESOLVED ⇏ any direction or bearing for the unresolved alternative;
  - an INDETERMINATE alternative ⇏ positive evidence for that alternative.
- **SEP-FW-27 [CORR2].** A null `supportBearing` on an EVALUABLE record ⇏ NON_DISCRIMINATING.
- **O-1(g) [CORR2].** SHARED_NON_UNIQUE never separates; it carries proven sharing only.
- **O-1(j) [CORR2].** UNIQUENESS_UNRESOLVED is non-establishing and non-separating, and is never presented as shared or unique support. A consumer may report it only as "directional for X; uniqueness unresolved".
- **SHARED class facets (replace CORR1 §9.6 SHARED).**
  - Positive rule: EVALUABLE ∧ admitted ∧ uncapped ∧ SUPPORTS_LEAF ∧ B-3 DIRECTIONAL ∧ SEP-U-2 on a closed W(f).
  - Exclusions: unresolved alternatives only (→ UNIQUENESS_UNRESOLVED); incomplete enumeration (→ HOLD-U); co-entailed generic content (→ ND); PARTIAL alone.
  - Nearest competing state: UNIQUENESS_UNRESOLVED, separated mechanically by whether any alternative is DIRECTIONAL.

---

## 8. CORR2-CORR1-CORR1-IV1-F01 — AUTHOR POSITIVE CONTROL, RECONSTRUCTED (synthetic; not historical coding)

Control SYN-PC2. The full witness, records, traces and mechanical checks are in census `positiveControl`. Rules used: the unchanged H-2.2, H-3, W-1..W-4, T-1..T-5, B-3 MD-1..MD-3 and SEP-U. The CORR2 control (SYN-PC) is superseded.

### 8.1 Text, bases and the uniform selection reading

**Certified text (synthetic, DE-1, competent, accessible; unchanged from CORR2).** "In the 1995 brake-design dispute, two competing designs (A and B) were put through the same physical road test. The design retained was determined solely by the measured test result; the other design was discarded. Neither rank, status, a prior agreement nor the identity of the proposer decided the choice, and no rule of argument was used to select a better-argued position."

| Basis | Content |
|---|---|
| b1 | "In the 1995 brake-design dispute, two competing designs (A and B)" — a contested choice between two competing designs (solutions/concepts) |
| b2 | "[the two designs] were put through the same physical road test" — the test act only |
| b3 | "The design retained was determined solely by the measured test result; the other design was discarded." — a documented retain/discard decision whose sole basis was the measured result (the word "solely" excludes every other deciding basis) |
| b4 | "Neither rank, status, a prior agreement nor the identity of the proposer decided the choice" — explicit exclusion of those four bases |
| b5 | "no rule of argument was used to select a better-argued position" — argument was not the selector |

**Uniform H-2.2 reading (applied identically to all 74 rows; a statement of the existing standard, not a new rule):**

1. A component is entailed iff the text states or necessarily entails *that component's own content*, as the §D component text and its §C dispatch line describe it.
2. The M's other components are never required for selection; they stay MISSING (H-2.2, H-3).
3. A role component requires the referent *in the named role*. For example, the D-03 allocation components require an allocated good and a recipient (l.828).
4. A negated mention does not entail the negated structure: "rank did not decide" does not entail a hierarchy.
5. No hidden completion (C34 §7.4).

### 8.2 W(f): 74 dispositions — 6 SELECTED, 68 NOT_SELECTABLE

| SELECTED M | Env | Entailed (basis) | Missing | Consuming TTs |
|---|---|---|---|---|
| M-ADJ-ARGUMENT-QUALITY | NF/NT | c2 (b1), c4 (b3+b4) | c1, c3 | TT-NFNT-CORE |
| M-ADJ-TEST-RESULT | NT/STP | c1 (b1), c2 (b2), c3 (b3), c4 (b4) | — | TT-NTSTP-ES |
| M-DECISIONS-SEEK-RELATIONAL-SAFETY | SFJ/SFP | c1 (b3) | c2 | TT-SFJSFP-REL |
| M-EMPIRICAL-TEST-ITERATE | NT/STP | c1 (b1), c2 (b2), c3 (b3) | — | TT-NTSTP-ES |
| M-IMMEDIATE-EMPIRICAL-ITERATION | NT/STP | c1 (b1), c3 (b3) | c2, c4 | TT-NTSTP-CORE |
| M-RES-REALLOC-BY-RESULT | NT/STP | c1 (b1+b2) | c2, c3 | TT-NTSTP-ES, TT-NTSTP-RS |

Notes on selected rows:

- **DECISIONS-SEEK-RELATIONAL-SAFETY:** c1 "documented decision(s)" is entailed by b3 (the documented retain/discard decision). D-11 dispatch (l.831) requires no trade-off for this M. c2 (relational-safety/group-harmony preservation operative in the decision basis) is NOT supplied and stays MISSING: no harmony content is invented and the missing component is not turned into a negative fact (H-3; J-6).
- **ARGUMENT-QUALITY:** c4 ("title/wealth/tenure/force not the deciding basis") is entailed by b3: "solely" excludes every basis other than the measured result, including title, wealth, tenure and force. b4 explicitly excludes rank and status (corroborating title/tenure) but names neither wealth nor force, so b4 ALONE does not entail c4 and is never relied on alone. Basis recorded as b3+b4 (b3 necessary and sufficient; b4 corroborating). c1 (shared rules of argument in force) and c3 (better-supported position under those rules) are not entailed; b5 records that argument did not select.

**Near-case NOT_SELECTABLE dispositions.** These are the rows closest to the selection threshold. All 68 rationales are M-specific in the census.

| M | Rationale |
|---|---|
| M-OPEN-CRITICAL-EXCHANGE | c1 "participants" is the participants of an idea exchange (D-05 work mode); the text names a proposer only inside an exclusion (b4) and records no exchange; c2 no exchange of ideas recorded; c3 no criticism by argument (b5 records argument was not the selector). |
| M-INQUIRY-OPERATION | c1 no work unit named; c2 no open-question inquiry as an operating mode; c3 "rational-analytical method applied" read under "inquiry is the operating mode of the core work" (D-05): one physical comparison test is the empirical-test mode the registry assigns to NT/STP Ms, not rational-analytical inquiry. |
| M-STRUCTURED-IMPLEMENTATION | c1 "plan/method" is the plan/method executed as the work through coordinated roles; the road test is an evaluation procedure, not an executed plan; c2/c3 no. |
| M-WORKING-RESULT | c1 a single test is not an iteration sequence; c2 retention by measured result does not state that a functioning outcome was produced. |
| M-ADV-REALISED-RESULT | D-03 allocation: c1 no advancement decision/rule allocating anything to a recipient; c2 "realised result" is the recipient's demonstrable achievement — a measured design-test outcome is not a person's realised result; c3 no. |
| M-PRECEDENCE-CONTINUITY | c1 "documented trade-off": D-11 dispatch (l.831) defines this M's trade-off as continuity-side vs innovation/competition/knowledge-side options (contrast the DECISIONS row: "no trade-off-with-innovation field required"); a test-based choice between two designs is not such a trade-off; c2/c3 no. |
| M-INFORMAL-LOYALTY-AUTHORITY | c1 "decision/status/authority allocation" is a D-03 allocation to a recipient (l.828); the retention decision allocates nothing to anyone; c2–c4 operate within such an allocation and are not entailed. |
| M-ZERO-SUM-PRIMACY-CONTEST | D-06 dispatch (l.844): internal actors competing for position/resources; designs evaluated by a test are neither positions nor resources, and no actor's zero-sum gain/loss is recorded. |
| M-RES-STAKE-UNPROVEN | c1 no resources; c2 "unproven solution" — the text does not state either design was unproven at a point of commitment, and being tested does not necessarily imply unproven (a test can confirm a known design; C34 §7.4 no hidden completion); c3 no commitment. |
| M-HIERARCHY-EFFICIENCY | c1 "hierarchy": b4's negated mention ("rank did not decide") does not entail an organizational hierarchy; c2 no hierarchy function. |
| M-AUTH-TOPDOWN-EXPLICIT | c1 "hierarchy" not entailed by the negated rank mention; c2 no fast top-down decision record (b4 excludes rank as the basis); c3 no consultation. |
| M-NO-EXTERNAL-ARBITER | c1 no redistribution domain; c2 requires an affirmative record of the ENTIRE governing basis of a REDISTRIBUTION — b3/b4 bound one design choice, not a resource flow; c3 scope only. |
| M-RECOGNISED-COMMAND-ORDER | c1 final-decision holder: the decision is attributed to the measured result, and no actor or body holding binding final authority is identified (DR-L2); c2/c3 no. |
| M-PRES-APPLIED-EXPERIMENTATION | presentation object: c2 is the CONTENT OF AN OFFICIAL FRAME (preciseMeaning "Frame asserts experimental/applied style"); performed hands-on testing is operative activity, not presented frame content (§D PRES header; G-4). |
| M-RES-CONCEPTUAL-GENERATION | c1 is generation of new concepts AS RESOURCE RENEWAL; comparing two designs records no resource renewal; c2 no. |
| M-AUTH-TECHNICAL-CREDIBILITY | D-03 allocation: no authority/standing allocated; the design's measured performance is not a person's technical credibility. |

**Materialized records (W-3): 7**, one per SELECTED M × registry-consuming TT:

- `SYN-PC2:M-ADJ-ARGUMENT-QUALITY:TT-NFNT-CORE` (NF/NT; PARTIAL; supplied c2, c4)
- `SYN-PC2:M-ADJ-TEST-RESULT:TT-NTSTP-ES` (NT/STP; SUPPORTED; supplied c1, c2, c3, c4)
- `SYN-PC2:M-DECISIONS-SEEK-RELATIONAL-SAFETY:TT-SFJSFP-REL` (SFJ/SFP; PARTIAL; supplied c1)
- `SYN-PC2:M-EMPIRICAL-TEST-ITERATE:TT-NTSTP-ES` (NT/STP; SUPPORTED; supplied c1, c2, c3)
- `SYN-PC2:M-IMMEDIATE-EMPIRICAL-ITERATION:TT-NTSTP-CORE` (NT/STP; PARTIAL; supplied c1, c3)
- `SYN-PC2:M-RES-REALLOC-BY-RESULT:TT-NTSTP-ES` (NT/STP; PARTIAL; supplied c1)
- `SYN-PC2:M-RES-REALLOC-BY-RESULT:TT-NTSTP-RS` (NT/STP; PARTIAL; supplied c1)

Every record is EVALUABLE and admitted (no NACR clause, no declaration, no AV-6 conflict), with relation SUPPORTS_LEAF. No record exists for any NOT_SELECTABLE M.

### 8.3 Traces

**X = TEST-RESULT × TT-NTSTP-ES.** Cmp⁺ = Cmp(TEST-RESULT) ∪ Sel_other(f) = {ADJ-ARGUMENT-QUALITY, AUTH-TOPDOWN-EXPLICIT, DECISIONS-SEEK-RELATIONAL-SAFETY, INTERPRETIVE-CONTROL, MEANING-GOVERNED-COMPLIANCE, PARTICIPATION-ARCHITECTURE-CONTROL} (**6** comparators; DECISIONS-SEEK enters through Sel_other(f)).

| c | Basis | MD-2 | MD-3 | Verdict |
|---|---|---|---|---|
| c1 | b1 | NOT_TRIGGERED | ADJ-ARGUMENT-QUALITY: CO_ENTAILS c2 (contested issue with competing positions) | NON_DISTINGUISHING |
| c2 | b2 | NOT_TRIGGERED (comparison test; no defect found or fixed) | NO_CO_ENTAILMENT ×6: b2 records a test act only. It carries no argument rule or contested issue, no hierarchy or top-down decision, no belief system or interpretation, no compliance, no participation terms, and no documented decision (the decision is b3). | **DISTINGUISHING** |
| c3 | b3 | NOT_TRIGGERED | DECISIONS-SEEK-RELATIONAL-SAFETY: CO_ENTAILS c1 (documented decision(s)); ADJ-ARGUMENT-QUALITY: CO_ENTAILS c4 ("solely" excludes title/wealth/tenure/force) | NON_DISTINGUISHING |
| c4 | b4 | NOT_TRIGGERED | DECISIONS-SEEK-RELATIONAL-SAFETY: CO_ENTAILS c1 (b4 refers to "the choice", a documented decision); ADJ-ARGUMENT-QUALITY: UNRESOLVED (b4 excludes rank/status but names neither wealth nor force; b4 alone does not lawfully settle c4) | NON_DISTINGUISHING |

Record verdict: **DIRECTIONAL**, resting on c2 alone.

- Direction does not come from full supply.
- c3, which was DISTINGUISHING in the CORR2 control, is now NON_DISTINGUISHING, because the decision content it shares with DECISIONS-SEEK c1 is generic.
- This is a derived consequence of including the correctly selected M, not a choice.

**ARGUMENT-QUALITY × TT-NFNT-CORE.** Universe: 9 Ms (Cmp(ARGUMENT-QUALITY) ∪ Sel_other(f)).

- c2 (b1) CO_ENTAILS TEST-RESULT c1.
- c4 (b3+b4) CO_ENTAILS TEST-RESULT c4.
- **NON_DIRECTIONAL**, with every supplied component witnessed.

**DECISIONS-SEEK-RELATIONAL-SAFETY × TT-SFJSFP-REL.** Universe: 5 Ms (Cmp = ∅ for single-Environment D-11, ∪ Sel_other(f)).

- c1 (b3) CO_ENTAILS TEST-RESULT c3 and EMPIRICAL-TEST-ITERATE c3; MD-2 not engaged.
- **NON_DIRECTIONAL.**
- c2 MISSING: no harmony content invented; not negative evidence.
- Selected, but not directional.

### 8.4 Checks and uniqueness

| Check | Result |
|---|---|
| W-1 coverage | PASS (74 unique dispositions = registry set) |
| W-2 identity | PASS (one synthetic coder output SYN-PC2; registry cb08b51e…) |
| W-3 materialization | PASS (all 6 SELECTED Ms × every consuming TT = 7 records; none for NOT_SELECTABLE) |
| W-4 consistency | PASS (CO_ENTAILS targets {ADJ-ARGUMENT-QUALITY, ADJ-TEST-RESULT, DECISIONS-SEEK-RELATIONAL-SAFETY, EMPIRICAL-TEST-ITERATE} ⊆ SELECTED; componentSupply ≡ witness) |
| T-1 universes | PASS (all three universes equal Cmp(M) ∪ Sel_other(f); every MD-3 key lies inside its universe) |
| T-2..T-4 completeness | PASS |

**Alt(X)**, the other-Environment SUPPORTS_LEAF records of SELECTED Ms:

- ARGUMENT-QUALITY × TT-NFNT-CORE (NF/NT): NON_DIRECTIONAL;
- DECISIONS-SEEK-RELATIONAL-SAFETY × TT-SFJSFP-REL (SFJ/SFP): NON_DIRECTIONAL.

EMPIRICAL-TEST-ITERATE, IMMEDIATE-EMPIRICAL-ITERATION and REALLOC-BY-RESULT are NT/STP, X's own Environment, so they are not alternatives.

→ **U-1 DIRECT_SUPPORT (SOLE_DIRECTIONAL_TARGET)**.

**AUTHOR_POSITIVE_CONTROL = PASS_UNDER_OWN_CONTRACT; DIRECT_SUPPORT_REACHED = YES.**

- **Cross-check, after independent derivation:** the selected set and its components agree with the CORR2.CORR1.CORR1.IV1 report-only reconstruction. That reconstruction was not used as a source.
- Every disposition and MD-3 judgment is this author's, recorded and contestable.
- The control proves reachability, not historical coding or Environment assignment.

---

## 9. ADVERSARIAL TESTS (Owner task §23, §24)

| # | Construction | Expected | CORR2 derivation | Result |
|---|---|---|---|---|
| A | CAPABILITY-ADVANTAGE: c1 supplied; [c2,c3,c4] ordinarily missing; abstention null; PARTIAL | EVALUABLE | Admitted (no NACR clause on the M; no declaration). PART: c1 SUPPLIED, the rest ORDINARY_MISSING_ASSESSABLE. EV-1..4 pass. | PASS |
| B | ASYMMETRIC-RETENTION: c1, c2 supplied; heterogeneous channels; no lawful basis; `{NACR-1, c3}` | INDETERMINATE / COMPONENT_NOT_ASSESSABLE | Admitted. PART(c3) = NON_ASSESSABLE → EV-3 fails; bearing null | PASS |
| C | Generic lawful H-7 non-assessability outside NACR | the exact F01 branch; never silently EVALUABLE | Branch A proved that **no lawful instance exists** on registry `cb08b51e…` (§5.4). Any declaration of one is invalid by SEP-NACR-1 → HOLD-NA, so never EVALUABLE. On a changed registry the case is reached only after SEP-NACR-V re-establishes the reduction and adds a clause; it then behaves as B. | PASS |
| D | Coder asserts "undocumentable" on M-ENFORCE-SANCTION c2, no authority basis | HOLD / invalid | The Appendix A row is a documentary kind (CAPACITY_DEMONSTRATED; §D l.966) → invalid by SEP-NACR-1 → HOLD-NA (AV-3) | PASS |
| E | sourceQualityState CONTENT_INACCESSIBLE | INDETERMINATE | EV-1 → [SOURCE_CONTENT_INACCESSIBLE]; bearing null | PASS |
| F | c3 in componentSupply **and** `{NACR-1, c3}` declared | admission inconsistency | AV-6 → HOLD-NA. No precedence; no competing EV readings. | PASS |
| G | Case B encoded with edgeState PARTIAL vs NOT_DETERMINABLE | identical EV | edgeState ∉ EV_INPUT_SIGNATURE. AV-1 is satisfied in the NOT_DETERMINABLE encoding by the NACR declaration; both encodings are admitted → INDETERMINATE | PASS |
| H | Full supplied/assessable edge, abstention null | no accidental INDETERMINATE | No EV gate reads completeness, content or edgeState → EVALUABLE | PASS |
| U-1 | Complete W; two directional alternatives (X, Y) | proven SHARED | U-2 → SHARED_NON_UNIQUE (PROVEN_DIRECTIONAL_ALTERNATIVE) | PASS |
| U-2 | Delete a materialized SELECTED sibling | W-3 fails | HOLD-U | PASS |
| U-3 | Delete W | HOLD-U | W-1 unavailable → HOLD-U | PASS |
| U-4 | Truncate W (73 entries) | HOLD-U | W-1 fails → HOLD-U | PASS |
| U-5 | Y explicitly NOT_SELECTABLE, records removed | judgment visible | Closure can pass; the exclusion is an explicit, auditable entailment assertion, not silent absence | PASS (boundary disclosed) |
| U-6 | X directional; Y INDETERMINATE (E-R7 AMBIGUOUS); no directional alternative | no SHARED, no DIRECT | **SEP-U-3 → UNIQUENESS_UNRESOLVED** (EVALUABLE, bearing null, X trace retained; basis lists Y) | PASS (Owner-decided semantics) |
| U-7 | U-6, then Y later resolved NON_DIRECTIONAL / DIRECTIONAL | recompute | U-1 DIRECT / U-2 SHARED | PASS |
| PC | Rebuilt positive control (§8) | DIRECT reachable lawfully | W-1..W-4, T-1, U-1 | PASS |

The CORR1 §18 tests not listed here are unchanged and still pass. Test L (unresolved alternative) now gives UNIQUENESS_UNRESOLVED instead of SHARED.

---

## 10. STATE MACHINE [CORR2 changes to S2, S3, S7]

```text
S0  INPUT    r; bound R (incl. SEP-NACR, registry identity); K; W(f); T(r); r.abstention.
S1  APPLY    SEP-EV-0. Not applicable → (null, null, null); STOP.
S2  ADMIT    SEP-AV-1, AV-2, AV-3, AV-6 over ADMISSION_INPUT_SIGNATURE. Fail → HOLD; STOP.
             Compute PART(r, c) for every required component.
S3  GATES    F := failing gates among EV-1..EV-4.
             Reads EXACTLY EV_INPUT_SIGNATURE (§6.1): no edgeState, no bearing output, no W, no T.
S4  INDET    F ≠ ∅ → (INDETERMINATE, F, null); STOP.
S5  EVAL     EVALUABLE; reasons null.
S6  PASS-1   B-1a | B-1b | B-2 | B-3 (CORR1, unchanged).
S7  PASS-2   DIRECTIONAL SUPPORTS_LEAF only: AV-5, then SEP-U-X / U-2 / U-3 / U-0 / U-1
             → HOLD-U | SHARED_NON_UNIQUE | UNIQUENESS_UNRESOLVED (bearing null) | DIRECT_SUPPORT.
S8  OUTPUT   triple, plus the T(r) uniqueness basis. §F.3/§F.5 unchanged; consumers bound by O-1(a)–(j).
```

The graph is S2 → S3 → S6 → S7 and remains acyclic: S7 reads the S4/S6 outcomes of *other* records only. CORR1.IV1's non-circularity finding is unaffected.

---

## 11. A-E023 AND A-E001

**A-E023**, with the fixed inputs F-M-0205; M-RES-CAPABILITY-ADVANTAGE; TT-NTSTJ-RS; PLAN; DE-4; FORMAL_ONLY; PARTIAL; [c2,c3,c4]; OPEN.

- **Admission.** No NACR clause on the M (Appendix A: c1 REFERENT; c2 FLOW_DESTINATION; c3 STATED_PURPOSE; c4 STATUS_EXCLUSIVITY; all documentary). Abstention null. No AV-6 conflict. edgeState PARTIAL triggers no hold.
- **PART:** c1 SUPPLIED; c2, c3, c4 ORDINARY_MISSING_ASSESSABLE.
- **EV:** EV-1..EV-4 pass → **EVALUABLE**, reasons null. No authority contradiction was found.
- **Bearing:** under the Owner-accepted conservative DE-4 ceiling (§14, Decision 3), B-1a gives **NON_DISCRIMINATING**. This is the candidate successor bearing only. The physical row is unchanged, and no materialization is authorized. U-3 is never reached.

**A-E001.** Not adjudicated. **A_E001_REQUIRES_READJUDICATION = YES** (CORR1 §17, unchanged). Its componentSupply/missingComponents inconsistency is establishment-side and outside EV (§6.2). Under CORR2 its record is admitted: no NACR, no conflict. It still has no trace and no witness, so it routes to MIG-6c.

---

## 12. IMPACT CENSUS — SUMMARY (`…_CORR2_IMPACT_CENSUS.json`)

**Material counts.** All reproduce exactly (census `materialCountVerification`):

| Count | Value |
|---|---|
| Section-I records | 6 |
| execution cells | 110 |
| current legacy NOT_DETERMINABLE | 0 |
| DE-4 mechanical projections (candidate migration consequences; not materialized) | 5 |
| re-adjudication | 1 |
| value changes (candidate; not materialized) | 3 |
| historical mapped (byte-deduplicated) | 122 |
| historical DE-4 mechanical (candidate) / recompute | 68 / 54 |
| legacy NOT_DETERMINABLE | 5 identities / 9 byte-deduplicated / 3 artifacts |
| existing W / existing T | 0 / 0 |

Walk: 2082 files (= 2078 + 4 new JSON artifacts since CORR1); 377 records.

**Incidence of CORR2 changes:**

- NACR-domain records 0; declared abstentions 0; AV-6 conflicts 0;
- generic-H-7 declarations outside NACR 0;
- U-3 (UNIQUENESS_UNRESOLVED) 0, because no witness exists.

**Delta versus the CORR1 census:** no count changes. New sections: the 219-row component-domain proof, the positive control, and the Owner-decision input.

**Impact surfaces** (schema, matrix, validators, assembly, consumers; not Owner decisions).

- Schema, field-source matrix and validators are as in CORR1. Validators add the exact EV signature check and AV-6.
- Assembly: UNIQUENESS_UNRESOLVED records are materializable; defect holds are not.
- HEDC gains O-1(j).
- Report product: NO_CHANGE. Mode-D: NO_CHANGE.
- Consumers: unchanged; no new live consumer.

---

## 13. RULE CLASSIFICATION (A / B / C / D derivational class, plus a separate Owner-decision status)

The derivational class records *where a rule comes from*. Owner acceptance of a methodology choice does **not** turn a Class-C proposal into A or B. Owner status is recorded separately.

| Rule | Class | OWNER_DECISION_STATUS | Basis |
|---|---|---|---|
| Architecture C (two axes, three fields, NOT_DETERMINABLE outside the bearing vocabulary) | C | **ACCEPTED** (Decision 1) | unchanged |
| SEP-SD-2; direction-only DIRECT_SUPPORT / SHARED on PARTIAL/OPEN; B-2 counter analogue (CORR1 surface 2b) | C | **ACCEPTED** (Decision 2) | O-1 preserved; §F.3 unchanged |
| SEP-DE4 / SEP-B-1a / SEP-SD-4 / SEP-I-5 | C | **ACCEPTED — conservative** (Decision 3) | constitutive exception NOT AVAILABLE; predecessor ceiling (A) unchanged |
| SEP-U-3 / SD-3 / I-3 / I-8 / FW-26 / FW-27 / O-1(g),(j) | C | **ACCEPTED — proven sharing only** (Decision 4) | Owner decision accepted; rule text pending fresh independent IV |
| SEP-EV-1, EV-2, EV-4 | C (A predicates) | within Decision 1 | unchanged |
| SEP-EV-3 | C | within Decision 1 | A predicates (§G-7, §D l.997, view-schema abstention); defined over PART |
| EV_INPUT_SIGNATURE / ADMISSION_INPUT_SIGNATURE / SEP-I-10 | C | within Decision 1 | exact specification; mechanical |
| Component partition PART; SEP-AV-6 | C | within Decision 1 | mechanical over coder-judgment inputs; contradiction hold |
| SEP-AV-1..5 | C | within Decision 1 | unchanged |
| **Generic-H-7 → NACR reduction (§5)** | **B** | not an Owner choice (source derivation) | exhaustive derivation over 219 enumerated components from A premises P1–P4 |
| SEP-NACR-1 invalidity of out-of-NACR declarations | B (consequence) / C (HOLD routing) | not an Owner choice | follows from the reduction |
| SEP-NACR-V version binding | C | within Decision 1 | C34 §6 version-binding pattern |
| SEP-EV-C closure | C | within Decision 1 | rests on the B reduction |
| SEP-B-1b | A | n/a | §F.3 PR rule |
| SEP-B-2 (partial counter bearing), B-3, W, T | C | within Decisions 1–2 | unchanged |
| SEP-U-X, U-0, U-1, U-2 | C | within Decisions 1, 4 | unchanged |
| SEP-SD-1, SD-5; O-1(a)–(f),(h),(i) | C | within Decision 1 | unchanged |
| SEP-MIG-0..4, 5A, 5B, 5C, 6a, 6c, 7, 8 | C | within Decision 1 (the 5A/6a cap rests on Decision 3) | MIG-5 and MIG-6b stay deleted |
| SEP-I, FW, BC (others) | C | within Decision 1 | unchanged |
| Registry quantities, NACR extraction, Cmp table, Appendix A inventory, census counts | B (data) | n/a | mechanical |

**LOAD_BEARING_CLASS_D_RULES = 0.**

---

## 14. OWNER DECISION LEDGER (controlling Owner inputs; no open surface)

**OPEN_OWNER_METHODOLOGY_SURFACES = 0 · OWNER_DECIDED_METHODOLOGY_SURFACES = 4.**

- **Source.** The Owner's U-3 addendum to CORR2 (2026-10-05), and the Owner's CORR2.CORR1 authorization (2026-10-05), which records acceptance of the three remaining recommendations. Both are OWNER FACTS carried by the current Owner instructions.
- **Scope.** These decisions settle the methodology *choices*. They do not accept, verify, bind or implement this candidate package.

| # | Decision | Accepted option | Semantic consequence | Implementation consequence | Verification status |
|---|---|---|---|---|---|
| 1 | Architecture C — successor semantics for supportClass | **ACCEPTED**: separate `bearingEvaluability` from `supportBearing`; legacy NOT_DETERMINABLE is not a successor bearing value | Two typed axes (§5 of CORR1; §6 here). INDETERMINATE gives null bearing with reasons. Evaluability never reads edgeState. NOT_DETERMINABLE is readable on legacy records only. | A future, separately authorized act adds the successor methodology text, then schema and field-source-matrix successors, then validators and a successor view with a MIG ledger. Nothing is implemented here. | The candidate's conformance to the accepted architecture is **pending fresh independent IV**. |
| 2 | Direction-only bearing on incomplete content | **ACCEPTED**: a PARTIAL/OPEN edge may carry directional bearing (DIRECT_SUPPORT on proven uniqueness, SHARED on proven sharing, DIRECT_CONTRADICTION for directional counter content) when direction is lawfully established | Direction ≠ establishment. Bearing alone establishes no mechanism, Tree Target, Environment, Pair, ECS or downstream outcome (O-1(a),(b),(i)). §F.3 establishment rules are unchanged. | A future HEDC must implement the O-1(b) witness coupling (same M/leaf, object, scope, time, relation instance, distinguishing supplying fact). No HEDC is authored here. | **Pending fresh independent IV** of the rule text (SD-2, B-2, O-1). ENVIRONMENT_OUTCOME_PRESERVATION = NOT_YET_PROVEN. |
| 3 | DE-4 successor ceiling | **ACCEPTED — conservative**: an admitted EVALUABLE DE-4 record → `supportBearing = NON_DISCRIMINATING` while the C34 §6 constitutive exception is unavailable | DE-4 is never an evaluability reason. The cap binds in every direction. The constitutive exception remains NOT AVAILABLE, with the four-part instance test preserved. The predecessor C34 ceiling (Class A) is unchanged. | The 5 controlling-view projections (3 value changes: F-B-0025, F0024, A-E023 → ND) and the 68 historical DE-4 projections are no longer conditional on an Owner choice. They are **candidate migration consequences pending independent verification and later authorized materialization**. None is materialized. A-E023's physical row is unchanged. | **Pending fresh independent IV** of SEP-DE4 / B-1a / SD-4 / I-5 and of the projection counts. |
| 4 | U-3 unresolved uniqueness | **ACCEPTED — proven sharing only** | SHARED_NON_UNIQUE requires proven directional bearing to more than one lawful alternative. Directional X plus an INDETERMINATE alternative → UNIQUENESS_UNRESOLVED: supportBearing null, X trace retained, no DIRECT, no SHARED. An INDETERMINATE alternative is not positive evidence. | Successor views may materialize UNIQUENESS_UNRESOLVED records (EVALUABLE, null bearing). Future consumers follow O-1(j). | **Pending fresh independent IV** of SEP-U-3 and the dependent rules (§7). |

**Historical decision provenance (not open options):**

- Rejected for Decision 1: keeping the predecessor five-class supportClass.
- Rejected for Decision 2: requiring establishment before directional bearing.
- Rejected for Decision 3: direction-preserving DE-4.
- Rejected for Decision 4: broadened SHARED that includes unresolved alternatives.

None is to be re-asked.

**No new Owner surface.** F01's result is a source derivation (§5.5). CORR2.CORR1 introduces no methodology choice.

---

## 15. ENVIRONMENT SAFETY AND THE GATE

**ENVIRONMENT_OUTCOME_PRESERVATION = NOT_YET_PROVEN.**

- No current §F.3 / §F.5 computation reads any successor field, abstention code, W or T.
- No supportBearing alone establishes an Environment.
- A future HEDC must couple bearing to the same qualified establishing witness for:
  - the M / leaf;
  - the organizational object;
  - the bridged scope;
  - the T0 time;
  - the lawful relation instance;
  - the fact(s) supplying the DISTINGUISHING component.
- O-1(a)–(j) remain a deferred minimum obligation. No HEDC is authored.

**ENVIRONMENT-MATH PRESERVATION GATE.** Root Definitional/E9 unchanged → Stage-2 measures inputs only → no Environment assignment before a frozen determination contract → ECS only after two lawful Environment determinations.

This act involves no Environment assignment, candidate or ranking, and no U-7, OM-1, MD-2 Φ, D2-10, HEDC, RULE FREEZE, 905 / 18-side replay, Pair, ECS or friction.

---

## 16. LIMITATIONS AND OPEN DEPENDENCIES (none blocks IV)

- **The Appendix A classification is semantic reading.** Each row is inspectable and contestable. An IV dispute on any row is a bounded row-level issue. If a row were shown to be a non-documentable kind, it would need an NACR clause through §M, and the B claim would narrow accordingly.
- **The reduction is version-bound** to registry `cb08b51e…` (SEP-NACR-V).
- **OD-1 (PRES DE-4), OD-3 (measured surface), OD-4 (HEDC contract), OD-5 (coding cost), OD-6 (witness correctness), OD-7 (comparator boundary), OD-8 (abstention field status):** as in CORR1 §24.
- **OD-2 (H-7 edgeState precedence):** still unresolved for edgeState itself and still not load-bearing here.
- **UNIQUENESS_UNRESOLVED may persist indefinitely.** It is a truthful state, not a defect.
- **The positive control** is synthetic; it proves reachability, not historical coding.

---

## 17. VALIDATION AND PRESERVATION — CORR2.CORR1.CORR1.CORR1 ACT (positive-control correction)

Physical source: that act's manifest `4b21d90591d97c4344fed7e6a7804552fd830278f0040097a83c7da8a4c147ad` (11021 B). This reporting act (§0D) restates it and adds no new validation claim about it. This reporting act's own preservation record is in its own manifest.

**Performed in the CORR2.CORR1.CORR1.CORR1 act:**

- **Parent identity checks** of the CORR2.CORR1.CORR1 package, exact SHA-256 and bytes, all matching:
  - `STAGE2_SUPPORTCLASS_EVALUABILITY_SEMANTIC_SEPARATION_1_CORR2_CORR1_CORR1_CANDIDATE.md`: `08bcf3bde0e06cf3eca31e1c6f6bb6673173b1c743cfeb66c60bd13b53369abe` (91211 B)
  - `STAGE2_SUPPORTCLASS_EVALUABILITY_SEMANTIC_SEPARATION_1_CORR2_CORR1_CORR1_IMPACT_CENSUS.json`: `a1dd9c77f117889cf3aaf78ae59f39e8a8bc2828f76afabf31e3220b368fb73f` (180514 B)
  - `STAGE2_SUPPORTCLASS_EVALUABILITY_SEMANTIC_SEPARATION_1_CORR2_CORR1_CORR1_MANIFEST.json`: `a1d9a165906c15c792508d2731407deea7f55f869edd1d3a247d9d864caaa5df` (8017 B)
- **Read of the CORR2.CORR1.CORR1.IV1 package**, as the finding specification and as a cross-check only, never a source:
  - `STAGE2_SUPPORTCLASS_EVALUABILITY_SEMANTIC_SEPARATION_1_CORR2_CORR1_CORR1_IV1_FINDINGS.json`: `6a68b0acce22f8ff3303f4305243b20ac5f21898503425ead099a1bdd44ba4ff` (714361 B)
  - `STAGE2_SUPPORTCLASS_EVALUABILITY_SEMANTIC_SEPARATION_1_CORR2_CORR1_CORR1_IV1_MANIFEST.json`: `613f293e1f44d879e7d88451f8485d62ba8d46006495f52ecadf50fd373b0b0d` (1250360 B)
  - `STAGE2_SUPPORTCLASS_EVALUABILITY_SEMANTIC_SEPARATION_1_CORR2_CORR1_CORR1_IV1_REPORT.md`: `9a62e93dde6c1dad7efc233a99192aff6006ab53a678db5fca4d609b6e18a5a1` (30175 B)
- **Re-derivation of all 74 W(f) dispositions** under the uniform H-2.2 reading (§8.1), giving SYN-PC2: 6 SELECTED, 68 NOT_SELECTABLE, 7 materialized records.
- **Mechanical checks:** W-1..W-4, T-1..T-4 and the SEP-U derivation all passed, giving U-1 DIRECT_SUPPORT.
- **Section comparison with the parent:**
  - changed: header, §0, §1, §8, §18;
  - new: §0C;
  - byte-identical: §0B, §0A, §2, §3, §4, §5, §6, §7, §9, §10, §11, §12, §13, §14, §15, §16, §17, Appendix A.

  §17 was among the byte-identical sections in that act, which is how it carried earlier-act text (remnant B, corrected here).
- **The declared positive-control correction surfaces were the only changes.** The F01 proof (§5, Appendix A), the EV signature and partition (§6), U-3 (§7), the DE-4 and Owner ledger (§13–§14), migration (CORR1 by reference), Environment safety (§15) and the limitations (§16) were untouched.
- **Census:** changed only in positiveControl (SYN-PC → SYN-PC2), positiveControlSuperseded, parentCensusReference, deltaVsParentCensus, artifact/act/mode.
- **Real-data counts unchanged:** Section-I 6; execution cells 110; mechanical projections 5; re-adjudication 1; value changes 3; historical mapped 122; historical DE-4 68; historical recompute 54; supportClass record objects 377; normalized walk 2082.
- **Git:** read-only (`GIT_OPTIONAL_LOCKS=0`).

**Not performed in that act:**

- no methodology, H-2.2, registry, TT, W, B-3, U-3 or DE-4 change;
- no Owner-decision change and no new Owner surface;
- no implementation, schema or field-source-matrix edit;
- no historical recoding, A-E001 adjudication or A-E023 change;
- no Final Regression, HEDC, Environment work or Git mutation;
- IV not begun.

**Preservation (that act):**

- **Hashed before writing: 1386 files.** Scope: tracked files, WORKBENCH/DOWNLOADS, docs/reference, docs/governance, docs/contracts, Downloads, Git metadata (HEAD, config, index, logs/HEAD, packed-refs, refs/heads/main) and the sibling `03_SOURCE_ARTIFACTS`.
- **After writing the candidate and census:** 1388 files; changed 0, removed 0. The only additions were that act's candidate and census. Its manifest was written after the check.
- **HEAD** before and after: `2567223087d99b40bdfd174eed32566be7080e44`.
- **Porcelain (`-uall`):** 718 → 720 after the candidate and census, 721 expected after the manifest.
- **Tracked diff:** empty. **Staged diff:** empty.
- **Outputs:** that act wrote only its three authorized outputs in `STAGE2_SUPPORTCLASS_EVALUABILITY_SEMANTIC_SEPARATION_1_CORR2_CORR1_CORR1_CORR1_2026-10-05/`.
- **Scratch** (non-authority, outside the repository): `/private/tmp/mv_sc_eval_sep1_c2c1c1c1_scratch/`.

---

## 18. TERMINAL STATE

```text
STAGE2_SUPPORTCLASS_EVALUABILITY_SEMANTIC_SEPARATION_1_CORR2_CORR1_CORR1_CORR1_CORR1_READY_FOR_IV
(supersedes STAGE2_SUPPORTCLASS_EVALUABILITY_SEMANTIC_SEPARATION_1_CORR2_CORR1_CORR1_CORR1_READY_FOR_IV; reporting-consistency correction only.
 The CORR2.CORR1.CORR1.IV1 verdict stays FAIL, BLOCKING = 1, until a fresh non-Claude IV verifies this package.)
Owner methodology decisions : 4 ACCEPTED, 0 open
Package                     : ownerAccepted = false · independentlyVerified = false ·
                              controlling = false · implemented = false
```

Current gate (this act): both reporting remnants (§0D A and B) are corrected, §8 is byte-identical to the parent, and no methodology, positive-control or Owner-decision content changed.

*Inherited gate record (CORR2.CORR1 act; retained unchanged):* every stale Owner-surface reference is removed or neutralized by the status-reading clause, and all four accepted decisions are represented consistently in:

- the §0 summary;
- §1, §2, §3 and §7;
- §11 and §12;
- the §13 class plus status table;
- the §14 ledger;
- the census;
- the manifest.

Unchanged CORR2 properties:

- F01 is proved exhaustive.
- The EV signature is exact.
- AV-6 holds contradictions.
- The positive control passes W-1..W-4 and U-1.
- A missing sibling cannot yield DIRECT.
- There are 0 load-bearing D rules.
- No historical bytes changed, nothing is implemented, and Environment math is untouched.

STOP AFTER THE THREE FILES. Do not begin IV. Do not implement.

---

## APPENDIX A — COMPONENT-DOMAIN PROOF TABLE (all 74 Ms, 219 required components)

Columns:

- **Mechanism.**
- **c:** the component ID.
- **Semantic requirement:** the §D component text, truncated here; full text in the census.
- **Kind.**
- **Basis:** a legend code, below.
- **NACR:** an explicit NACR clause, YES / NO.
- **H-7:** generic H-7 applicability.
- **Locator.**
- **EV:** the successor EV treatment.
  - `MISS`: never NON_ASSESSABLE; unsupplied → ORDINARY_MISSING_ASSESSABLE; a declaration is invalid → HOLD-NA.
  - `NACR-1`: NON_ASSESSABLE when the trigger holds (EV-3); otherwise SUPPLIED or ORDINARY_MISSING_ASSESSABLE with explicit CONDITION_NOT_MET.

**Basis legend:**

- `BK-REF`: organizational actor/object/group/resource/domain named by certified content; any C34 §6 DE form; competence per G-1/G-2/G-6
- `BK-FRAME`: purpose stated in a governing record (row text); G-1/G-6
- `BK-TIME`: standing/recurring/over-time/immediacy shown by records; CH-FRAME + K-6 (§A.8), C34 §9 (no numeric minimum), C34 §11 continuity; REPETITION_INTRINSIC rows
- `BK-PRACTICE`: operative practice or mode; C34 §8 operative routes (rule in force + ≥1 governed decision, or competent record of routine application); G-3
- `BK-OUTPUT`: documented operating condition (row text "documented condition"); G-6
- `BK-RULE`: three-layer coincidence on one structure from rule/discretion/approval records (E9/09 §8; SUPPORTING base, row text)
- `BK-ACT`: recorded gain/loss of the same contested position/resource; DE-1; a same-object outcome, not a cross-channel valuation
- `BK-BASIS`: deciding/allocation/gating basis that the record states or necessarily entails; G-6 ("unless the record itself evidences … e.g. it shows the deciding basis"); C34 §7.2 decision-rule component; DR-L1 standard (affirmatively states or necessarily entails)
- `BK-EXCL`: affirmative record of the actual basis/terms excluding the named basis; never from silence (J-6); no hidden completion (C34 §7.4); unentailed → missing (H-3)
- `BK-REL`: relation/linkage witnessed on one relationInstance by documentary linkage (§F.4, §F.4.1 L-1..L-6); documentary ceiling disclosed in rows (§W l.1494; §Q F02 l.1311); no causal counterfactual (§D l.992; C34 §5.8)
- `BK-STATUS`: primary/principal/mainly status shown by a competent affirmative record over the domain (row text; G-6); absent → component missing (e.g. §D l.987 "absent → fail closed (component missing)"); closed-world reading forbidden
- `BK-FLOW`: direction/destination of a resource or value flow recorded in transfers/allocations; C34 §6 DE-1/DE-3; D-07 neutral question
- `BK-CAP`: capacity evidenced through the route the row names (applied instance, competent record of demonstration, listed observable capabilities); §D l.965/966/990
- `BK-OPEN`: open-category organizational good (§D header: any member satisfies); members are organizational grants (access, protection, influence, entrusted standing); an inner-feeling reading is excluded by G-8 and §A.7(f)
- `BK-NEG`: COMPETENT_AFFIRMATIVE_ABSENCE-grade affirmative record (J-2, J-4); never silence (J-3, J-6)
- `BK-SCOPE`: observedScope/claimedScope and temporal state (C34 §10, §11; §E)
- `BK-NACR1`: assessable iff a lawful comparison basis exists ((a) the system's own common-unit records, or (b) a competent record that performs the comparison); otherwise mandatory abstention

| Mechanism | c | Semantic requirement | Kind | Basis | NACR | H-7 | Locator | EV |
|---|---|---|---|---|---|---|---|---|
| M-PRES-HIGHER-MISSION | c1 | presenting organizational actor | REFERENT | BK-REF | NO | NO | §D row l.921 | MISS |
| M-PRES-HIGHER-MISSION | c2 | content = ultimate-significance purpose of core activity | RECORD_FRAME | BK-FRAME | NO | NO | §D row l.921 | MISS |
| M-PRES-HIGHER-MISSION | c3 | official channel/record | RECORD_FRAME | BK-FRAME | NO | NO | §D row l.921 | MISS |
| M-PRES-HIGHER-MISSION | c4 | standing frame (CH-FRAME) | TEMPORAL_STANDING | BK-TIME | NO | NO | §D row l.921 | MISS |
| M-PRES-INNOVATION-ACHIEVEMENT | c1 | actor | REFERENT | BK-REF | NO | NO | §D row l.922 | MISS |
| M-PRES-INNOVATION-ACHIEVEMENT | c2 | content = innovation/progress/achievement leadership | RECORD_FRAME | BK-FRAME | NO | NO | §D row l.922 | MISS |
| M-PRES-INNOVATION-ACHIEVEMENT | c3 | official record | RECORD_FRAME | BK-FRAME | NO | NO | §D row l.922 | MISS |
| M-PRES-INNOVATION-ACHIEVEMENT | c4 | standing frame | TEMPORAL_STANDING | BK-TIME | NO | NO | §D row l.922 | MISS |
| M-PRES-APPLIED-EXPERIMENTATION | c1 | actor | REFERENT | BK-REF | NO | NO | §D row l.923 | MISS |
| M-PRES-APPLIED-EXPERIMENTATION | c2 | content = {applied innovation/prototyping/hands-on technical work} | RECORD_FRAME | BK-FRAME | NO | NO | §D row l.923 | MISS |
| M-PRES-APPLIED-EXPERIMENTATION | c3 | official record | RECORD_FRAME | BK-FRAME | NO | NO | §D row l.923 | MISS |
| M-PRES-APPLIED-EXPERIMENTATION | c4 | standing frame | TEMPORAL_STANDING | BK-TIME | NO | NO | §D row l.923 | MISS |
| M-PRES-ABSOLUTE-BELIEF | c1 | actor | REFERENT | BK-REF | NO | NO | §D row l.924 | MISS |
| M-PRES-ABSOLUTE-BELIEF | c2 | belief/value set | RECORD_FRAME | BK-FRAME | NO | NO | §D row l.924 | MISS |
| M-PRES-ABSOLUTE-BELIEF | c3 | non-revisable/absolute claim | RECORD_FRAME | BK-FRAME | NO | NO | §D row l.924 | MISS |
| M-PRES-ABSOLUTE-BELIEF | c4 | participant audience | REFERENT | BK-REF | NO | NO | §D row l.924 | MISS |
| M-PRES-ABSOLUTE-BELIEF | c5 | standing frame | TEMPORAL_STANDING | BK-TIME | NO | NO | §D row l.924 | MISS |
| M-PRES-EXPRESSIVE-MEANING | c1 | actor | REFERENT | BK-REF | NO | NO | §D row l.925 | MISS |
| M-PRES-EXPRESSIVE-MEANING | c2 | content = {creative/aesthetic/relational} activity as meaning carrier | RECORD_FRAME | BK-FRAME | NO | NO | §D row l.925 | MISS |
| M-PRES-EXPRESSIVE-MEANING | c3 | official record | RECORD_FRAME | BK-FRAME | NO | NO | §D row l.925 | MISS |
| M-PRES-EXPRESSIVE-MEANING | c4 | standing frame | TEMPORAL_STANDING | BK-TIME | NO | NO | §D row l.925 | MISS |
| M-PRES-STRICT-HIERARCHY | c1 | actor | REFERENT | BK-REF | NO | NO | §D row l.926 | MISS |
| M-PRES-STRICT-HIERARCHY | c2 | strict binding rules | RECORD_FRAME | BK-FRAME | NO | NO | §D row l.926 | MISS |
| M-PRES-STRICT-HIERARCHY | c3 | visible hierarchy | RECORD_FRAME | BK-FRAME | NO | NO | §D row l.926 | MISS |
| M-PRES-STRICT-HIERARCHY | c4 | declared punishment for defection | RECORD_FRAME | BK-FRAME | NO | NO | §D row l.926 | MISS |
| M-PRES-STRICT-HIERARCHY | c5 | tribute: regular resource transfers/renders from members or lower levels to the apex as… | RECORD_FRAME | BK-FRAME | NO | NO | §D row l.926 | MISS |
| M-PRES-BELONGING-CONTINUITY | c1 | actor | REFERENT | BK-REF | NO | NO | §D row l.927 | MISS |
| M-PRES-BELONGING-CONTINUITY | c2 | content: the combined tradition/loyalty/care/continuity/belonging identity asserting co… | RECORD_FRAME | BK-FRAME | NO | NO | §D row l.927 | MISS |
| M-PRES-BELONGING-CONTINUITY | c3 | official record | RECORD_FRAME | BK-FRAME | NO | NO | §D row l.927 | MISS |
| M-PRES-BELONGING-CONTINUITY | c4 | standing frame (CH-FRAME) | TEMPORAL_STANDING | BK-TIME | NO | NO | §D row l.927 | MISS |
| M-PRES-DESIRE-FRAMING | c1 | actor | REFERENT | BK-REF | NO | NO | §D row l.928 | MISS |
| M-PRES-DESIRE-FRAMING | c2 | participant/customer audience | REFERENT | BK-REF | NO | NO | §D row l.928 | MISS |
| M-PRES-DESIRE-FRAMING | c3 | frame = {pleasure/lifestyle/belonging/recognition/choice/status/convenience/other immed… | RECORD_FRAME | BK-FRAME | NO | NO | §D row l.928 | MISS |
| M-PRES-DESIRE-FRAMING | c4 | standing frame | TEMPORAL_STANDING | BK-TIME | NO | NO | §D row l.928 | MISS |
| M-INQUIRY-OPERATION | c1 | work unit | REFERENT | BK-REF | NO | NO | §D row l.932 | MISS |
| M-INQUIRY-OPERATION | c2 | open-question inquiry as operating mode | PRACTICE_MODE | BK-PRACTICE | NO | NO | §D row l.932 | MISS |
| M-INQUIRY-OPERATION | c3 | rational-analytical method applied | PRACTICE_MODE | BK-PRACTICE | NO | NO | §D row l.932 | MISS |
| M-THEORY-PRODUCTION | c1 | unit | REFERENT | BK-REF | NO | NO | §D row l.933 | MISS |
| M-THEORY-PRODUCTION | c2 | output = new theoretical/explanatory construct | OUTPUT_RECORD | BK-OUTPUT | NO | NO | §D row l.933 | MISS |
| M-OPEN-CRITICAL-EXCHANGE | c1 | participants | REFERENT | BK-REF | NO | NO | §D row l.934 | MISS |
| M-OPEN-CRITICAL-EXCHANGE | c2 | exchange of ideas | PRACTICE_MODE | BK-PRACTICE | NO | NO | §D row l.934 | MISS |
| M-OPEN-CRITICAL-EXCHANGE | c3 | criticism by argument practised | PRACTICE_MODE | BK-PRACTICE | NO | NO | §D row l.934 | MISS |
| M-ADJ-ARGUMENT-QUALITY | c1 | shared rules of argument in force | RULE_STRUCTURE | BK-RULE | NO | NO | §D row l.935 | MISS |
| M-ADJ-ARGUMENT-QUALITY | c2 | contested issue with competing positions | ACT_INSTANCE | BK-ACT | NO | NO | §D row l.935 | MISS |
| M-ADJ-ARGUMENT-QUALITY | c3 | decision basis = better-supported position under those rules | BASIS_CRITERION | BK-BASIS | NO | NO | §D row l.935 | MISS |
| M-ADJ-ARGUMENT-QUALITY | c4 | title/wealth/tenure/force not the deciding basis | EXCLUSION_NEGATIVE_BASIS | BK-EXCL | NO | NO | §D row l.935 | MISS |
| M-AUTH-EPISTEMIC | c1 | allocated authority/standing | ACT_INSTANCE | BK-ACT | NO | NO | §D row l.936 | MISS |
| M-AUTH-EPISTEMIC | c2 | basis = demonstrated understanding | BASIS_CRITERION | BK-BASIS | NO | NO | §D row l.936 | MISS |
| M-AUTH-EPISTEMIC | c3 | applied instance or routine-application record | ACT_INSTANCE | BK-ACT | NO | NO | §D row l.936 | MISS |
| M-RES-KNOWLEDGE-PRIMARY | c1 | knowledge-as-resource content: records treat knowledge/concepts/theoretical understandi… | RECORD_TREATMENT | BK-FRAME | NO | NO | §D row l.937 | MISS |
| M-RES-KNOWLEDGE-PRIMARY | c2 | legitimate standing grounded in knowledge contribution/demonstrated understanding | BASIS_CRITERION | BK-BASIS | NO | NO | §D row l.937 | MISS |
| M-RES-KNOWLEDGE-PRIMARY | c3 | structural-relation witness (ONE relationInstance): the record evidences the TIED stage… | RELATION_LINKAGE | BK-REL | NO | NO | §D row l.937 | MISS |
| M-RES-CONCEPTUAL-GENERATION | c1 | generation of new concepts/theoretical constructs as resource renewal | OUTPUT_RECORD | BK-OUTPUT | NO | NO | §D row l.938 | MISS |
| M-RES-CONCEPTUAL-GENERATION | c2 | renewal (not mere reallocation of a fixed stock) | EXCLUSION_NEGATIVE_BASIS | BK-EXCL | NO | NO | §D row l.938 | MISS |
| M-STRUCTURED-IMPLEMENTATION | c1 | plan/method | REFERENT | BK-REF | NO | NO | §D row l.939 | MISS |
| M-STRUCTURED-IMPLEMENTATION | c2 | coordinated roles | REFERENT | BK-REF | NO | NO | §D row l.939 | MISS |
| M-STRUCTURED-IMPLEMENTATION | c3 | disciplined execution | PRACTICE_MODE | BK-PRACTICE | NO | NO | §D row l.939 | MISS |
| M-HIERARCHY-EFFICIENCY | c1 | hierarchy | REFERENT | BK-REF | NO | NO | §D row l.940 | MISS |
| M-HIERARCHY-EFFICIENCY | c2 | function = coordinating efficient implementation | FUNCTION_RECORD | BK-REL | NO | NO | §D row l.940 | MISS |
| M-STRATEGY-TO-SCALE | c1 | strategy | REFERENT | BK-REF | NO | NO | §D row l.941 | MISS |
| M-STRATEGY-TO-SCALE | c2 | structured implementation | PRACTICE_MODE | BK-PRACTICE | NO | NO | §D row l.941 | MISS |
| M-STRATEGY-TO-SCALE | c3 | durable/scalable result realised | OUTPUT_RECORD | BK-OUTPUT | NO | NO | §D row l.941 | MISS |
| M-ADV-REALISED-RESULT | c1 | advancement decision/rule | RULE_OR_DECISION | BK-RULE | NO | NO | §D row l.942 | MISS |
| M-ADV-REALISED-RESULT | c2 | realised result independently evidenced | OUTPUT_RECORD | BK-OUTPUT | NO | NO | §D row l.942 | MISS |
| M-ADV-REALISED-RESULT | c3 | status/relationships not the basis | EXCLUSION_NEGATIVE_BASIS | BK-EXCL | NO | NO | §D row l.942 | MISS |
| M-AUTH-DELIVERY | c1 | authority allocation | ACT_INSTANCE | BK-ACT | NO | NO | §D row l.943 | MISS |
| M-AUTH-DELIVERY | c2 | basis = delivery record/capability | BASIS_CRITERION | BK-BASIS | NO | NO | §D row l.943 | MISS |
| M-AUTH-DELIVERY | c3 | no fixed elite gate | EXCLUSION_NEGATIVE_BASIS | BK-EXCL | NO | NO | §D row l.943 | MISS |
| M-RES-CAPABILITY-ADVANTAGE | c1 | resources | REFERENT | BK-REF | NO | NO | §D row l.944 | MISS |
| M-RES-CAPABILITY-ADVANTAGE | c2 | destination = {capability/technology/strategic assets} | FLOW_DESTINATION | BK-FLOW | NO | NO | §D row l.944 | MISS |
| M-RES-CAPABILITY-ADVANTAGE | c3 | competitive-position purpose stated in governing record | STATED_PURPOSE | BK-FRAME | NO | NO | §D row l.944 | MISS |
| M-RES-CAPABILITY-ADVANTAGE | c4 | primary status: the record shows capability deployment as the primary object of resourc… | STATUS_EXCLUSIVITY | BK-STATUS | NO | NO | §D row l.944 | MISS |
| M-AUTH-TECHNICAL-CREDIBILITY | c1 | authority/standing allocation | ACT_INSTANCE | BK-ACT | NO | NO | §D row l.945 | MISS |
| M-AUTH-TECHNICAL-CREDIBILITY | c2 | basis = technical credibility/demonstrated ability | BASIS_CRITERION | BK-BASIS | NO | NO | §D row l.945 | MISS |
| M-AUTH-TECHNICAL-CREDIBILITY | c3 | applied instance or operative record | ACT_INSTANCE | BK-ACT | NO | NO | §D row l.945 | MISS |
| M-CAPABILITY-YIELDS-CONTROL | c1 | capability/advantage built by the deployment | REFERENT | BK-REF | NO | NO | §D row l.946 | MISS |
| M-CAPABILITY-YIELDS-CONTROL | c2 | treated/operating as the basis of the organization's power, influence or control (relat… | RELATION_LINKAGE | BK-REL | NO | NO | §D row l.946 | MISS |
| M-EMPIRICAL-TEST-ITERATE | c1 | solution/concept | REFERENT | BK-REF | NO | NO | §D row l.947 | MISS |
| M-EMPIRICAL-TEST-ITERATE | c2 | empirical test | ACT_INSTANCE | BK-ACT | NO | NO | §D row l.947 | MISS |
| M-EMPIRICAL-TEST-ITERATE | c3 | keep/discard/revise by result | BASIS_CRITERION | BK-BASIS | NO | NO | §D row l.947 | MISS |
| M-IMMEDIATE-EMPIRICAL-ITERATION | c1 | solution/concept | REFERENT | BK-REF | NO | NO | §D row l.948 | MISS |
| M-IMMEDIATE-EMPIRICAL-ITERATION | c2 | immediate empirical test upon conception | TEMPORAL_STANDING | BK-TIME | NO | NO | §D row l.948 | MISS |
| M-IMMEDIATE-EMPIRICAL-ITERATION | c3 | keep/discard/revise by result | BASIS_CRITERION | BK-BASIS | NO | NO | §D row l.948 | MISS |
| M-IMMEDIATE-EMPIRICAL-ITERATION | c4 | continuous problem-solving operation | TEMPORAL_STANDING | BK-TIME | NO | NO | §D row l.948 | MISS |
| M-ADJ-TEST-RESULT | c1 | contested issue | ACT_INSTANCE | BK-ACT | NO | NO | §D row l.949 | MISS |
| M-ADJ-TEST-RESULT | c2 | test | ACT_INSTANCE | BK-ACT | NO | NO | §D row l.949 | MISS |
| M-ADJ-TEST-RESULT | c3 | decision followed result | BASIS_CRITERION | BK-BASIS | NO | NO | §D row l.949 | MISS |
| M-ADJ-TEST-RESULT | c4 | rank/prior agreement/proposer not decisive | EXCLUSION_NEGATIVE_BASIS | BK-EXCL | NO | NO | §D row l.949 | MISS |
| M-WORKING-RESULT | c1 | iteration sequence | TEMPORAL_STANDING | BK-TIME | NO | NO | §D row l.950 | MISS |
| M-WORKING-RESULT | c2 | working result produced | OUTPUT_RECORD | BK-OUTPUT | NO | NO | §D row l.950 | MISS |
| M-RES-STAKE-UNPROVEN | c1 | resources | REFERENT | BK-REF | NO | NO | §D row l.951 | MISS |
| M-RES-STAKE-UNPROVEN | c2 | unproven solution | REFERENT | BK-REF | NO | NO | §D row l.951 | MISS |
| M-RES-STAKE-UNPROVEN | c3 | commitment before proof | ACT_INSTANCE | BK-ACT | NO | NO | §D row l.951 | MISS |
| M-RES-REALLOC-BY-RESULT | c1 | tested solutions | REFERENT | BK-REF | NO | NO | §D row l.952 | MISS |
| M-RES-REALLOC-BY-RESULT | c2 | redistribution toward successful / away from failed | FLOW_DESTINATION | BK-FLOW | NO | NO | §D row l.952 | MISS |
| M-RES-REALLOC-BY-RESULT | c3 | governing basis of the flow = result | BASIS_CRITERION | BK-BASIS | NO | NO | §D row l.952 | MISS |
| M-NO-EXTERNAL-ARBITER | c1 | redistribution domain at matched scope | REFERENT | BK-REF | NO | NO | §D row l.953 | MISS |
| M-NO-EXTERNAL-ARBITER | c2 | affirmative record of the ENTIRE governing basis of that redistribution domain at match… | BOUNDED_NEGATIVE_CONTENT | BK-NEG | NO | NO | §D row l.953 | MISS |
| M-NO-EXTERNAL-ARBITER | c3 | matched scope/time | SCOPE_TIME_MATCH | BK-SCOPE | NO | NO | §D row l.953 | MISS |
| M-INTERPRETIVE-CONTROL | c1 | controlling group | REFERENT | BK-REF | NO | NO | §D row l.954 | MISS |
| M-INTERPRETIVE-CONTROL | c2 | belief/value system | REFERENT | BK-REF | NO | NO | §D row l.954 | MISS |
| M-INTERPRETIVE-CONTROL | c3 | authority to issue binding interpretation | RULE_STRUCTURE | BK-RULE | NO | NO | §D row l.954 | MISS |
| M-INTERPRETIVE-CONTROL | c4 | exercise instance/record | ACT_INSTANCE | BK-ACT | NO | NO | §D row l.954 | MISS |
| M-MEANING-GOVERNED-COMPLIANCE | c1 | binding interpretation issued by the controlling group | ACT_INSTANCE | BK-ACT | NO | NO | §D row l.955 | MISS |
| M-MEANING-GOVERNED-COMPLIANCE | c2 | compliance/conduct of participants following that interpretation (applied instances or … | RELATION_LINKAGE | BK-REL | NO | NO | §D row l.955 | MISS |
| M-RES-UPWARD-TRANSFER | c1 | participant source | REFERENT | BK-REF | NO | NO | §D row l.956 | MISS |
| M-RES-UPWARD-TRANSFER | c2 | controlling-group destination | FLOW_DESTINATION | BK-FLOW | NO | NO | §D row l.956 | MISS |
| M-RES-UPWARD-TRANSFER | c3 | resource of any channel | REFERENT | BK-REF | NO | NO | §D row l.956 | MISS |
| M-RULE-EXEMPT-UPPER | c1 | rule | RULE_STRUCTURE | BK-RULE | NO | NO | §D row l.957 | MISS |
| M-RULE-EXEMPT-UPPER | c2 | bound lower level | REFERENT | BK-REF | NO | NO | §D row l.957 | MISS |
| M-RULE-EXEMPT-UPPER | c3 | exempt upper group | RULE_STRUCTURE | BK-RULE | NO | NO | §D row l.957 | MISS |
| M-ADV-DOCTRINAL-ALIGNMENT | c1 | allocated support/advancement | ACT_INSTANCE | BK-ACT | NO | NO | §D row l.958 | MISS |
| M-ADV-DOCTRINAL-ALIGNMENT | c2 | basis = alignment with belief system | BASIS_CRITERION | BK-BASIS | NO | NO | §D row l.958 | MISS |
| M-ADV-DOCTRINAL-ALIGNMENT | c3 | applied instance/routine record | ACT_INSTANCE | BK-ACT | NO | NO | §D row l.958 | MISS |
| M-THREAT-AMPLIFICATION | c1 | organizational actor | REFERENT | BK-REF | NO | NO | §D row l.959 | MISS |
| M-THREAT-AMPLIFICATION | c2 | external party/threat | REFERENT | BK-REF | NO | NO | §D row l.959 | MISS |
| M-THREAT-AMPLIFICATION | c3 | amplifying communication or act addressed to members | ACT_INSTANCE | BK-ACT | NO | NO | §D row l.959 | MISS |
| M-INTERNAL-ENEMY-DESIGNATION | c1 | organizational actor | REFERENT | BK-REF | NO | NO | §D row l.960 | MISS |
| M-INTERNAL-ENEMY-DESIGNATION | c2 | internal party | REFERENT | BK-REF | NO | NO | §D row l.960 | MISS |
| M-INTERNAL-ENEMY-DESIGNATION | c3 | designation as dissenter/enemy | ACT_INSTANCE | BK-ACT | NO | NO | §D row l.960 | MISS |
| M-INTERNAL-ENEMY-DESIGNATION | c4 | organizational act (sanction/exclusion/communication) | ACT_INSTANCE | BK-ACT | NO | NO | §D row l.960 | MISS |
| M-SACRED-UNITY-PERSISTENCE-FUNCTION | c1 | the act is framed as consolidating the belief system / sacred unity | RECORD_FRAME | BK-FRAME | NO | NO | §D row l.961 | MISS |
| M-SACRED-UNITY-PERSISTENCE-FUNCTION | c2 | the framing calls for group cohesion around the belief system and its controlling order | RECORD_FRAME | BK-FRAME | NO | NO | §D row l.961 | MISS |
| M-SACRED-UNITY-PERSISTENCE-FUNCTION | c3 | preservation endpoint: the record's framing or operative content affirmatively links th… | RELATION_LINKAGE | BK-REL | NO | NO | §D row l.961 | MISS |
| M-RES-EXPRESSIVE-EXPENDITURE | c1 | resources | REFERENT | BK-REF | NO | NO | §D row l.962 | MISS |
| M-RES-EXPRESSIVE-EXPENDITURE | c2 | destination = {creative/aesthetic/relational} activity | FLOW_DESTINATION | BK-FLOW | NO | NO | §D row l.962 | MISS |
| M-RES-NO-INTERNAL-REPLENISHMENT | c1 | resource-use domain | REFERENT | BK-REF | NO | NO | §D row l.963 | MISS |
| M-RES-NO-INTERNAL-REPLENISHMENT | c2 | competent affirmative record that no internal replenishment/accountability mechanism go… | BOUNDED_NEGATIVE_CONTENT | BK-NEG | NO | NO | §D row l.963 | MISS |
| M-AUTH-TOPDOWN-EXPLICIT | c1 | hierarchy | REFERENT | BK-REF | NO | NO | §D row l.964 | MISS |
| M-AUTH-TOPDOWN-EXPLICIT | c2 | fast top-down decision instance/routine record | ACT_INSTANCE | BK-ACT | NO | NO | §D row l.964 | MISS |
| M-AUTH-TOPDOWN-EXPLICIT | c3 | consultation non-displacing | EXCLUSION_NEGATIVE_BASIS | BK-EXCL | NO | NO | §D row l.964 | MISS |
| M-ENFORCE-STRENGTH | c1 | authority holder | REFERENT | BK-REF | NO | NO | §D row l.965 | MISS |
| M-ENFORCE-STRENGTH | c2 | demonstrated strength | CAPACITY_DEMONSTRATED | BK-CAP | NO | NO | §D row l.965 | MISS |
| M-ENFORCE-STRENGTH | c3 | compliance enforced by it | RELATION_LINKAGE | BK-REL | NO | NO | §D row l.965 | MISS |
| M-ENFORCE-SANCTION | c1 | declared sanction rule/regime for defection | RULE_STRUCTURE | BK-RULE | NO | NO | §D row l.966 | MISS |
| M-ENFORCE-SANCTION | c2 | operative enforcement capacity evidenced by an applied instance or a competent record o… | CAPACITY_DEMONSTRATED | BK-CAP | NO | NO | §D row l.966 | MISS |
| M-ENFORCE-RESOURCE-CONTROL | c1 | authority holder | REFERENT | BK-REF | NO | NO | §D row l.967 | MISS |
| M-ENFORCE-RESOURCE-CONTROL | c2 | control of resources | CONTROL_RELATION | BK-RULE | NO | NO | §D row l.967 | MISS |
| M-ENFORCE-RESOURCE-CONTROL | c3 | use of that control to secure compliance | RELATION_LINKAGE | BK-REL | NO | NO | §D row l.967 | MISS |
| M-ENFORCE-RESOURCE-INFORMATION-CONTROL | c1 | authority holder | REFERENT | BK-REF | NO | NO | §D row l.968 | MISS |
| M-ENFORCE-RESOURCE-INFORMATION-CONTROL | c2 | control of resources AND information | CONTROL_RELATION | BK-RULE | NO | NO | §D row l.968 | MISS |
| M-ENFORCE-RESOURCE-INFORMATION-CONTROL | c3 | use of that control to make authority enforceable | RELATION_LINKAGE | BK-REL | NO | NO | §D row l.968 | MISS |
| M-ZERO-SUM-PRIMACY-CONTEST | c1 | internal actors | REFERENT | BK-REF | NO | NO | §D row l.969 | MISS |
| M-ZERO-SUM-PRIMACY-CONTEST | c2 | contested position/resource | REFERENT | BK-REF | NO | NO | §D row l.969 | MISS |
| M-ZERO-SUM-PRIMACY-CONTEST | c3 | zero-sum gain/loss | OUTCOME_STRUCTURE | BK-ACT | NO | NO | §D row l.969 | MISS |
| M-ZERO-SUM-PRIMACY-CONTEST | c4 | manifestation ∈ {competition/tactical dominance/destruction/appropriation} | ACT_INSTANCE | BK-ACT | NO | NO | §D row l.969 | MISS |
| M-POSITION-BY-RESOURCE-HOLD | c1 | actor position | REFERENT | BK-REF | NO | NO | §D row l.970 | MISS |
| M-POSITION-BY-RESOURCE-HOLD | c2 | dependence on take/control/defend capacity | RELATION_LINKAGE | BK-REL | NO | NO | §D row l.970 | MISS |
| M-RES-COERCIVE-REDISTRIBUTION | c1 | source actor lacking {force/tactical cunning/institutional position} | REFERENT | BK-REF | NO | NO | §D row l.971 | MISS |
| M-RES-COERCIVE-REDISTRIBUTION | c2 | destination able to take/control/defend | REFERENT | BK-REF | NO | NO | §D row l.971 | MISS |
| M-RES-COERCIVE-REDISTRIBUTION | c3 | coercive redistribution act | ACT_INSTANCE | BK-ACT | NO | NO | §D row l.971 | MISS |
| M-RES-NETWORK-PRESERVATION | c1 | accumulated resources | REFERENT | BK-REF | NO | NO | §D row l.972 | MISS |
| M-RES-NETWORK-PRESERVATION | c2 | durable relationship network | REFERENT | BK-REF | NO | NO | §D row l.972 | MISS |
| M-RES-NETWORK-PRESERVATION | c3 | preservation/circulation within it | FLOW_DESTINATION | BK-FLOW | NO | NO | §D row l.972 | MISS |
| M-CONTINUITY-VIA-RELATIONS | c1 | roles/practices | REFERENT | BK-REF | NO | NO | §D row l.973 | MISS |
| M-CONTINUITY-VIA-RELATIONS | c2 | reproduction across time | TEMPORAL_STANDING | BK-TIME | NO | NO | §D row l.973 | MISS |
| M-CONTINUITY-VIA-RELATIONS | c3 | via established relationships | RELATION_LINKAGE | BK-REL | NO | NO | §D row l.973 | MISS |
| M-RES-NETWORK-AS-PRINCIPAL-RESOURCE | c1 | the network is maintained/protected as the principal conserved asset (records show prot… | STATUS_EXCLUSIVITY | BK-STATUS | NO | NO | §D row l.974 | MISS |
| M-RES-NETWORK-AS-PRINCIPAL-RESOURCE | c2 | comfort/belonging/status/trust circulate mainly within it | STATUS_EXCLUSIVITY | BK-STATUS | NO | NO | §D row l.974 | MISS |
| M-MEMBERSHIP-ASCRIBED | c1 | in-group | REFERENT | BK-REF | NO | NO | §D row l.975 | MISS |
| M-MEMBERSHIP-ASCRIBED | c2 | entry basis ∈ {family/kinship/origin/other durable pre-existing relation} | BASIS_CRITERION | BK-BASIS | NO | NO | §D row l.975 | MISS |
| M-MEMBERSHIP-ACQUIRED | c1 | in-group | REFERENT | BK-REF | NO | NO | §D row l.976 | MISS |
| M-MEMBERSHIP-ACQUIRED | c2 | entry after repeated demonstrated loyalty AND reliability AND care AND commitment | BASIS_CRITERION | BK-BASIS | NO | NO | §D row l.976 | MISS |
| M-TRUST-BY-DEMONSTRATED-LOYALTY | c1 | gated good ∈ {deep trust/sensitive resource/information access/protection/influence} | GATED_GOOD | BK-OPEN | NO | NO | §D row l.977 | MISS |
| M-TRUST-BY-DEMONSTRATED-LOYALTY | c2 | gate = demonstrated loyalty over time (reciprocal-belonging loyalty) | BASIS_CRITERION | BK-BASIS | NO | NO | §D row l.977 | MISS |
| M-ACCESS-BY-LOYALTY-RELIABILITY | c1 | gated good ∈ {sensitive information/resources/autonomy/inner-circle access} | GATED_GOOD | BK-OPEN | NO | NO | §D row l.978 | MISS |
| M-ACCESS-BY-LOYALTY-RELIABILITY | c2 | gate = personal loyalty/reliability within the internal structure | BASIS_CRITERION | BK-BASIS | NO | NO | §D row l.978 | MISS |
| M-INFORMAL-LOYALTY-AUTHORITY | c1 | decision/status/authority allocation | ACT_INSTANCE | BK-ACT | NO | NO | §D row l.979 | MISS |
| M-INFORMAL-LOYALTY-AUTHORITY | c2 | basis = in-group relational standing from the justified family {seniority/tenure/trust/… | BASIS_CRITERION | BK-BASIS | NO | NO | §D row l.979 | MISS |
| M-INFORMAL-LOYALTY-AUTHORITY | c3 | informal (not formal-title) character | RULE_STRUCTURE | BK-RULE | NO | NO | §D row l.979 | MISS |
| M-INFORMAL-LOYALTY-AUTHORITY | c4 | abstract performance alone not the basis | EXCLUSION_NEGATIVE_BASIS | BK-EXCL | NO | NO | §D row l.979 | MISS |
| M-DECISIONS-SEEK-RELATIONAL-SAFETY | c1 | documented decision(s) | ACT_INSTANCE | BK-ACT | NO | NO | §D row l.980 | MISS |
| M-DECISIONS-SEEK-RELATIONAL-SAFETY | c2 | relational-safety/group-harmony preservation operative in the decision basis (decisions… | BASIS_CRITERION | BK-BASIS | NO | NO | §D row l.980 | MISS |
| M-PRECEDENCE-CONTINUITY | c1 | documented trade-off | ACT_INSTANCE | BK-ACT | NO | NO | §D row l.981 | MISS |
| M-PRECEDENCE-CONTINUITY | c2 | continuity-side option chosen | ACT_INSTANCE | BK-ACT | NO | NO | §D row l.981 | MISS |
| M-PRECEDENCE-CONTINUITY | c3 | innovation/competition/knowledge option forgone | ACT_INSTANCE | BK-ACT | NO | NO | §D row l.981 | MISS |
| M-EXTERNAL-ADAPTIVE-DEMAND | c1 | operating domain | REFERENT | BK-REF | NO | NO | §D row l.982 | MISS |
| M-EXTERNAL-ADAPTIVE-DEMAND | c2 | documented condition requiring continuous situational adaptation | CONDITION_RECORD | BK-OUTPUT | NO | NO | §D row l.982 | MISS |
| M-OUTWARD-TACTICAL-DISCRETION | c1 | role | REFERENT | BK-REF | NO | NO | §D row l.983 | MISS |
| M-OUTWARD-TACTICAL-DISCRETION | c2 | discretion ∈ {exception procedures/route/supplier/channel change/non-standard transacti… | RULE_STRUCTURE | BK-RULE | NO | NO | §D row l.983 | MISS |
| M-OUTWARD-TACTICAL-DISCRETION | c3 | directed outward | RULE_STRUCTURE | BK-RULE | NO | NO | §D row l.983 | MISS |
| M-RECOGNISED-COMMAND-ORDER | c1 | final-decision holder | RULE_STRUCTURE | BK-RULE | NO | NO | §D row l.984 | MISS |
| M-RECOGNISED-COMMAND-ORDER | c2 | answerability lines | RULE_STRUCTURE | BK-RULE | NO | NO | §D row l.984 | MISS |
| M-RECOGNISED-COMMAND-ORDER | c3 | binding internal rules | RULE_STRUCTURE | BK-RULE | NO | NO | §D row l.984 | MISS |
| M-INSIDER-OUTSIDER-RULE-ASYMMETRY | c1 | internal rules binding insiders | RULE_STRUCTURE | BK-RULE | NO | NO | §D row l.985 | MISS |
| M-INSIDER-OUTSIDER-RULE-ASYMMETRY | c2 | external rules treated situationally/negotiably | RULE_STRUCTURE | BK-RULE | NO | NO | §D row l.985 | MISS |
| M-INSIDER-OUTSIDER-RULE-ASYMMETRY | c3 | difference applied | ACT_INSTANCE | BK-ACT | NO | NO | §D row l.985 | MISS |
| M-DELEGATION-HOW-VS-WHAT | c1 | delegated how-discretion by competence | RULE_STRUCTURE | BK-RULE | NO | NO | §D row l.986 | MISS |
| M-DELEGATION-HOW-VS-WHAT | c2 | rank-retained what/final decision | RULE_STRUCTURE | BK-RULE | NO | NO | §D row l.986 | MISS |
| M-RES-TACTICAL-EXTERNAL-ACQUISITION | c1 | external resource | REFERENT | BK-REF | NO | NO | §D row l.987 | MISS |
| M-RES-TACTICAL-EXTERNAL-ACQUISITION | c2 | tactical acquisition route | ACT_INSTANCE | BK-ACT | NO | NO | §D row l.987 | MISS |
| M-RES-TACTICAL-EXTERNAL-ACQUISITION | c3 | primary-source status (REQUIRED): competent affirmative evidence over the relevant reso… | STATUS_EXCLUSIVITY | BK-STATUS | NO | NO | §D row l.987 | MISS |
| M-RES-ROLE-CONTROLLED-ACCESS | c1 | internal resources | REFERENT | BK-REF | NO | NO | §D row l.988 | MISS |
| M-RES-ROLE-CONTROLLED-ACCESS | c2 | access by role | RULE_STRUCTURE | BK-RULE | NO | NO | §D row l.988 | MISS |
| M-RES-ROLE-CONTROLLED-ACCESS | c3 | hierarchical control | CONTROL_RELATION | BK-RULE | NO | NO | §D row l.988 | MISS |
| M-RES-HIERARCHICAL-RETENTION | c1 | internal resource pool of acquired resources | REFERENT | BK-REF | NO | NO | §D row l.989 | MISS |
| M-RES-HIERARCHICAL-RETENTION | c2 | retention/distribution governed by internal hierarchy | CONTROL_RELATION | BK-RULE | NO | NO | §D row l.989 | MISS |
| M-RES-PROTECTED-ACCESS-EXCHANGE | c1 | adapting-person capability (reads the situation, adjusts, negotiates, organises, moves … | CAPACITY_DEMONSTRATED | BK-CAP | NO | NO | §D row l.990 | MISS |
| M-RES-PROTECTED-ACCESS-EXCHANGE | c2 | protected access to the group resource flow | RULE_STRUCTURE | BK-RULE | NO | NO | §D row l.990 | MISS |
| M-RES-PROTECTED-ACCESS-EXCHANGE | c3 | exchange for acquisition/redistribution/protection/management under internal rules | RELATION_LINKAGE | BK-REL | NO | NO | §D row l.990 | MISS |
| M-RES-ADAPTING-PERSON-RECRUITMENT | c1 | recruitment/retention of adapting people | ACT_INSTANCE | BK-ACT | NO | NO | §D row l.991 | MISS |
| M-RES-ADAPTING-PERSON-RECRUITMENT | c2 | within the protected hierarchical resource network | RELATION_LINKAGE | BK-REL | NO | NO | §D row l.991 | MISS |
| M-ORDER-SUSTAINED-FLEXIBILITY | c1 | necessary base: the same operating structure carries the three-layer coincidence (broad… | STRUCTURE_COINCIDENCE | BK-RULE | NO | NO | §D row l.992 | MISS |
| M-ORDER-SUSTAINED-FLEXIBILITY | c2 | operative-linkage record (REQUIRED): the outward discretion is granted, maintained, bou… | RELATION_LINKAGE | BK-REL | NO | NO | §D row l.992 | MISS |
| M-PARTICIPATION-ARCHITECTURE-CONTROL | c1 | controlling group | REFERENT | BK-REF | NO | NO | §D row l.993 | MISS |
| M-PARTICIPATION-ARCHITECTURE-CONTROL | c2 | controls roles, forms, rules, terms, continued access | CONTROL_RELATION | BK-RULE | NO | NO | §D row l.993 | MISS |
| M-PARTICIPATION-ARCHITECTURE-CONTROL | c3 | non-negotiable by participants | EXCLUSION_NEGATIVE_BASIS | BK-EXCL | NO | NO | §D row l.993 | MISS |
| M-PARTICIPATION-RETENTION | c1 | participants | REFERENT | BK-REF | NO | NO | §D row l.994 | MISS |
| M-PARTICIPATION-RETENTION | c2 | re-engagement/retention mechanism | PRACTICE_MODE | BK-PRACTICE | NO | NO | §D row l.994 | MISS |
| M-PARTICIPATION-RETENTION | c3 | repeated contribution | TEMPORAL_STANDING | BK-TIME | NO | NO | §D row l.994 | MISS |
| M-PARTICIPATION-REPLACEMENT | c1 | participants | REFERENT | BK-REF | NO | NO | §D row l.995 | MISS |
| M-PARTICIPATION-REPLACEMENT | c2 | replacement/recruitment mechanism | PRACTICE_MODE | BK-PRACTICE | NO | NO | §D row l.995 | MISS |
| M-PARTICIPATION-REPLACEMENT | c3 | sustaining participation | TEMPORAL_STANDING | BK-TIME | NO | NO | §D row l.995 | MISS |
| M-COST-MINIMISING-SURPLUS-RETENTION | c1 | participation behaviour standardised by the internal structure (scripts/roles/rules sta… | RULE_STRUCTURE | BK-RULE | NO | NO | §D row l.996 | MISS |
| M-COST-MINIMISING-SURPLUS-RETENTION | c2 | architecture organised to minimise the cost of participant contribution | FUNCTION_RECORD | BK-REL | NO | NO | §D row l.996 | MISS |
| M-COST-MINIMISING-SURPLUS-RETENTION | c3 | surplus retained/redistributed upward | FLOW_DESTINATION | BK-FLOW | NO | NO | §D row l.996 | MISS |
| M-RES-ASYMMETRIC-RETENTION | c1 | contribution {labour/time/money/attention/energy/emotional involvement/data/social cont… | REFERENT | BK-REF | NO | NO | §D row l.997 | MISS |
| M-RES-ASYMMETRIC-RETENTION | c2 | return {pleasure/convenience/product/service/emotional stimulation/belonging/status/sec… | REFERENT | BK-REF | NO | NO | §D row l.997 | MISS |
| M-RES-ASYMMETRIC-RETENTION | c3 | comparative component (commensurability rule): (i) contribution and return channels ide… | CROSS_CHANNEL_COMPARISON | BK-NACR1 | YES | YES→NACR-1 | §D row l.997; TT-SFPSFJ-RES l.766; §C l.900; §G-7 l.1206; §F.3 l.1121–1122 | NACR-1 |

Totals: 74 Ms, 219 components; explicit NACR = 1; generic H-7 applicable outside NACR = 0.
