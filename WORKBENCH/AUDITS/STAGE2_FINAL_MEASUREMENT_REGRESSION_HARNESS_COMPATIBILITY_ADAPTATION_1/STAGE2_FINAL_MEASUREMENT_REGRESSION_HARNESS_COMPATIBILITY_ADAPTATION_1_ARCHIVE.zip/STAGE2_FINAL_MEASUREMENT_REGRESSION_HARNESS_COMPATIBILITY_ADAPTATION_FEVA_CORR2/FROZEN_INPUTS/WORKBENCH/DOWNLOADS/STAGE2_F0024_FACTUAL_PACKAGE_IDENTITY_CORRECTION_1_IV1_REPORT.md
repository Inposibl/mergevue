# STAGE2_F0024_FACTUAL_PACKAGE_IDENTITY_CORRECTION_1_IV1 — Independent verification report

Actor: Codex. Role: AUDITOR, specialized by the current Owner task as independent provenance / state-integrity auditor. Mode: READ-ONLY INDEPENDENT VERIFICATION. Date: 2026-10-05 (America/Asuncion).

**VERDICT: PASS. BLOCKING: 0. MAJOR: 0. MINOR: 1.**

The parked candidate correctly changes one F0024 factualPackageIdentity object: four subfields change, thirteen remain identical, and no analytical field changes. One non-blocking reporting defect qualifies the candidate's negative-proof wording. The complete old identity is unsupported by the current lawful authority path.

## 1. Mandate, independence and physical baseline

Current explicit Owner attachment authorizes this bounded IV and exactly these three output files. It appoints Codex as auditor and identifies Z-Ai as candidate author. Codex did not author this candidate in this session; no material candidate authorship by this auditor is known. The specialization is executed under AGENTS_A.md, with the explicit Owner instruction controlling the output exception to read-only mode.

Authorized physical repository root: `/Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)`.
Branch: `main`. HEAD: `2567223087d99b40bdfd174eed32566be7080e44`.
Initial Git porcelain state: 662 untracked file entries; no tracked or staged modifications. Initial status digest: `72d328e41cec2b98a83c44e3db3532f682b7dbf2fa9747081bbecae0ac2314a4`.
All writes are confined to WORKBENCH/DOWNLOADS and the three IV1 filenames. The physical destination lies inside the authorized repository; the output directory and destinations are not symlinks.

Read: AGENTS.md, AGENTS_A.md, MERGEVUE_CAUSALITY_PROOF_AND_AGENT_CONTROL.md, and skills/mergevue-agent-quality-gate/SKILL.md. Applied bounded evidence classification, independence, scope, causal-claim limitation, and hard-fail checks.

The latest full Control Tree found is docs/governance/MERGEVUE_CONTROL_TREE_v2.1_2026-09-04.md. Its recomputed SHA `360bafa29bad5ea93752323d4a217bf59aaec628e0e2b236350a2edd9c1f7128` matches its .sha256; latest path binding commit is `7792c5e` (2026-09-04). The report-product addendum dated 2026-09-21 hashes to `83cdd1ec02f11579167ef24737fd8f2c24e8f6bd7993909054649dcc3e776815`, matching its .sha256, latest binding `18daf4c`. The addendum states that it changes report/commercial interpretation only. Neither older tree nor Workbench report is used to override this current Owner-appointed Stage-2 act.

## 2. Evidence and identity

| Physically inspected input | Bytes | Recomputed SHA-256 |
|---|---:|---|
| `WORKBENCH/DOWNLOADS/STAGE2_F0024_FACTUAL_PACKAGE_IDENTITY_CORRECTION_1_2026-10-04/STAGE2_F0024_FACTUAL_PACKAGE_IDENTITY_CORRECTION_1.json` | 11108 | `0711b74240ddeecac7a95f15a0093ce44f3288f440929d6b803516e53ba6f983` |
| `WORKBENCH/DOWNLOADS/STAGE2_F0024_FACTUAL_PACKAGE_IDENTITY_CORRECTION_1_2026-10-04/STAGE2_F0024_FACTUAL_PACKAGE_IDENTITY_CORRECTION_1_REPORT.md` | 10282 | `ea964bbcfc760ef5a7ed5ee9457460b038d9c1e5b92c77ad4ae106e51cb75e79` |
| `WORKBENCH/DOWNLOADS/STAGE2_CORR4_PILOT_STAGE1_SOURCE_MAP.json` | 17490 | `665aac81c2e0127d08f0406186891959255391cb99ec34611a972209565f4a7f` |
| `WORKBENCH/DOWNLOADS/STAGE2_CORR4_PILOT_ANALYTICAL_PROVENANCE_SIDECAR_CORR1.jsonl` | 82425 | `84ab83d23209eae9f775844502676d462490ca8954f8d7a135d28acf5234d6af` |
| `/Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A WORKBENCH/02_CASE_RESEARCH/aol-time-warner/01_T0_PRE_T0_BASELINE/candidate/06_FACTS.json` | 61728 | `88b20920149b3fcde03e4e060cf4361e9494fe0137540bbc654c526337fd5f10` |
| `WORKBENCH/DOWNLOADS/STAGE2_POST_RECONCILIATION_EXECUTION_1_CODER_A_2026-10-04/STAGE2_POST_RECONCILIATION_EXECUTION_1_CODER_A_RECORDS.jsonl` | 104314 | `8914e745d5df3fbcfc4c4d47be3643ab44a0a3e89fae3d3445b9a94a0b042c71` |
| `WORKBENCH/DOWNLOADS/STAGE2_POST_RECONCILIATION_EXECUTION_1_CODER_B_2026-10-04/STAGE2_POST_RECONCILIATION_EXECUTION_1_CODER_B_RECORDS.jsonl` | 76833 | `8ab5ac2b55370479d45fb7f351d428fc1d34856675e25ac86da0b87905419d98` |
| `WORKBENCH/DOWNLOADS/STAGE2_F0024_FACTUAL_PACKAGE_IDENTITY_CORRECTION_1_2026-10-04/STAGE2_F0024_FACTUAL_PACKAGE_IDENTITY_CORRECTION_1_MANIFEST.json` | 3005 | `d7dd3910e4120ad6e2f144241acfca53626594aa010b66d03fa5c732a96d552a` |
| `WORKBENCH/DOWNLOADS/STAGE2_POST_RECONCILIATION_EXECUTION_1_AB_COMPARISON_2026-10-04/STAGE2_POST_RECONCILIATION_EXECUTION_1_AB_COMPARISON.json` | 87506 | `2e8256657225f36612dd00e79a69e755b5fc0d96631ce1523949e57cd49f1f20` |

Candidate JSON and report match both Owner pins and candidate-manifest bindings. Candidate-manifest physical identity is independently recomputed as **3005 bytes**, SHA **d7dd3910e4120ad6e2f144241acfca53626594aa010b66d03fa5c732a96d552a**. Both output bindings, five inspected-input bindings, and five candidate authority echoes match the physical files. The candidate manifest excludes its own self-hash as declared.

Source-of-truth classification:
- Owner fact: audit scope, five pinned inputs, accepted-overlay firewalls, F-B-0025 UNADJUDICATED boundary, and excluded later acts.
- Source fact: physical hashes/bytes, parsed identities, record counts, exact object comparisons, and preservation checks.
- Candidate / agent claim: author-side proofs, State Rebase sequencing/classifications, and AB-comparison annotations until independently checked.
- Inference: this validated correction removes the narrow provenance defect for future lawful assembly; it does not establish assembly or readiness.
- Hash-only preservation references: E9 cards/integration files and the accepted acquisition contract. Their contents are not re-audited or newly accepted.

The current Owner task pins the specific Workbench files for this verification. This does not make the Workbench folder a general governance authority. The State Rebase was consulted only for bounded context and firewall locators.

## 3. Exact target and old-value reproduction

The semantic selector is lane A + factId F0024 + mechanismPropositionId M-RES-ROLE-CONTROLLED-ACCESS + targetId TT-STPSTJ-RS + field factualPackageIdentity. It matches **exactly one** historical Lane-A cell, at JSONL line **51**, cellIndex 51, censusCellRef CC-018. The historical lane indicator is `side="A"`; organization side `AOL` is carried by its separate side cell and frozen provenance binding.

Historical assignedValue deep-equals candidate oldValue across **all 17 keys**, including the four specified bad values and all thirteen preserved values. Descriptive line numbers were not used as target authority.

## 4. Corrected identity and convergence

The frozen source map has one aol-time-warner case, ordinal 4. Its thirteen direct identity keys plus factCount→packageFactCount, sideCount→packageSideCount, source-map filename and recomputed source-map hash reconstruct all **17 corrected identity keys exactly**.

The frozen provenance sidecar contains one matching aol-time-warner / AOL / F0024 binding at JSONL line **9**. Its entire factualPackageIdentity deep-equals correctedValue.

The authority-bound physical recordFile exists at the unchanged absolute path. It is **61728 bytes**, hashes to **88b20920149b3fcde03e4e060cf4361e9494fe0137540bbc654c526337fd5f10**, and contains **50 facts**: AOL **25**, TIME_WARNER **25**. Every fact carries record-level case_id="aol-time-warner". F0024 occurs once on AOL (facts array index 23). PackageSideCount=2 matches both physical and frozen counts.

Lane-B Execution-1 is a cross-check only: its F0024 record at line 14 is a planCurrentState rerun, with no factualPackageIdentity field. The existing AB-comparison complete laneBEffectiveValue matches correctedValue; it is corroboration, not the independent source of the correction.

**AUTHORITY_CONVERGENCE = EXACT.**

## 5. Negative proof and the one finding

The old SHA has **zero occurrences** in the frozen source map and sidecar. At the authority-bound AOL path, old bytes 139589 disagree with physical bytes 61728; old count 105 disagrees with physical/frozen count 50. The frozen source map and sidecar require record-level case_id, so the old package-level locator disagrees with their selected binding. The lawful authority path resolves to the corrected object.

**OLD_IDENTITY_SUPPORTED = NO**, for the complete current authority-bound identity.

**MINOR — F0024-IV1-MINOR-001: live-file locator contradiction is overstated.**
Candidate JSON line 173 (`oldCaseIdLocatorContradictedByLiveFile=true`) and report lines 62–63 attribute this contradiction directly to the live file. In fact, the live JSON also contains a top-level case_id="aol-time-warner", as well as that key in all fifty fact records. Presence at record level does not disprove presence at package level. The valid contradiction is with the **frozen selected provenance locator**, not with the existence of a top-level key.

Consequence: qualification of one negative-proof explanation. It changes no target, old/new value, authority convergence, 4/13 surface, analytical purity, or immutability result; therefore it is MINOR and does not block this bounded PASS. Confidence: HIGH; physical structure is source fact and the severity/consequence is inference. No repair was performed. Any later authorized author-side clarification should reflect both key locations without changing the correction.

No universal historical non-existence claim or bad-value origin is needed or certified.

## 6. Exact surface and analytical preservation

| Subfield | Historical oldValue | correctedValue |
|---|---|---|
| `caseIdLocator` | `package-level key 'case_id'` | `record-level key 'case_id'` |
| `packageFactCount` | `105` | `50` |
| `recordFileBytes` | `139589` | `61728` |
| `recordFileSha256` | `4b686b245e412a83424168da6c87db9b392b4ea16eeadff48c0b62e49c7198bb` | `88b20920149b3fcde03e4e060cf4361e9494fe0137540bbc654c526337fd5f10` |

Unchanged keys (**13**): `caseIdKey`, `caseSlug`, `factIdKey`, `factIdLocator`, `identityAuthority`, `identityAuthoritySha256`, `packageDir`, `packageSideCount`, `recordFile`, `recordFormat`, `sideIdKey`, `sideIdLocator`, `stage1Generation`.

There is exactly one correction record and its only target field is factualPackageIdentity. Candidate declared changed/unchanged lists agree with independently computed differences.

An isolated in-memory substitution of that one historical cell's assignedValue was compared recursively with all 116 original Lane-A records. The only differences were:

- `$[50].assignedValue.caseIdLocator`
- `$[50].assignedValue.packageFactCount`
- `$[50].assignedValue.recordFileBytes`
- `$[50].assignedValue.recordFileSha256`

The other **115 historical cells** remain deep-equal; all metadata on the targeted cell remains equal; the **46 other F0024 cells** remain deep-equal. This is a differential proof only: no assembler, effective-view artifact or historical materialisation was created.

No correction changes fact text, factId, caseId, sideId, mechanismPropositionId, targetId, selectionResult, componentSupply, missingComponents, edgeState, planCurrentState, characteristicityState, characteristicityFactIds, temporal state, evidenceForm, supportClass, sourceQualityState, formalOperativeState, sourceClass, observedScope, mechanismObjectTypes, Tree targets, or P-D3 state. Historical and live-file hashes preserve original data; fields absent from a particular cell are not invented to perform the comparison.

## 7. Immutability and firewalls

The Lane-A records retain their Owner-pinned SHA **8914e745d5df3fbcfc4c4d47be3643ab44a0a3e89fae3d3445b9a94a0b042c71**, **104314 bytes**, **116 records**. The Lane-A report and records also match their historical manifest's member hash/byte bindings. Lane-B member bindings match as well.

Pre/post hashing covers **64 protected files**, listed in the IV manifest: the entire candidate package, Lane-A/B Execution-1 packages, accepted-overlay packages, P-D3 execution/comparison packages, frozen provenance inputs, bounded State Rebase context, and semantic preservation references. All remain byte-identical. Only the three IV outputs are added; tracked/staged state and HEAD remain unchanged.

The one correction key is disjoint from existing accepted analytical overlays:
- A-E023 / F-M-0205 planCurrentState = PLAN.
- A-E023 evidenceForm = DE-4 and formalOperativeState = FORMAL_ONLY.
- A-E001 evidenceForm = DE-1.
- P-D3 six-key closure remains a planCurrentState surface; even its F0024 cell is untouched by this factualPackageIdentity correction.

F-B-0025 remains **UNADJUDICATED** as the Owner's disposition. Its competing recorded values remain intact; no winner, output-mootness audit, or replacement value was supplied.

E9 meaning, TT registry, discriminator bridge, sufficiency authority, thin-coverage rule, MD-2 Phi, and Historical Environment Determination Contract are neither changed nor re-audited. Environment-math gate is preserved at this act's scope: Root/E9 unchanged → Stage-2 input measurement only → no Environment assignment before the frozen determination contract → ECS only after two lawful determinations.

## 8. Independent validation and bounded causal conclusion

All **25 independent primary checks** pass; detailed booleans and physical bindings are in FINDINGS.json. JSON parsing rejects duplicate object keys.

Independent identity oracle: source-map reconstruction + complete frozen-sidecar equality + physical live-file SHA/bytes/count. Corrected identity passes. Old identity fails. Reverting each of the four corrected subfields individually makes that oracle fail (four negative controls). Five additional surface controls reject wrong factId, wrong lane, wrong targetId, wrong field, and a second correction record. These are in-memory audit controls, not production fail-closed certification.

The bounded causal chain is:
Owner-pinned frozen map → unchanged physical Stage-1 path and identity → exact F0024 sidecar binding → one correctly targeted replacement object → provenance-valid input for later authorized assembly.
The old object cannot satisfy this chain. The corrected object does. Future authoritative consumption by an assembler is outside this act; it is not simulated or certified here.

**F0024_CORRECTION_VALID_FOR_FUTURE_EFFECTIVE_VIEW = YES**, conditional on separate Owner acceptance and later authorized assembly. The candidate remains parked; today's historical files still retain the old value.

Candidate JSON and manifest retain the terminal READY_FOR_IV suffix, ownerAcceptanceClaimed=false and historicalPackageMutation=false. The literal materialisationStatus begins `NOT_MATERIALIZED` and adds explanatory text requiring separate authorization. It does not claim materialisation or acceptance. The entire artifact remains overlay-only.

## 9. Required summary

```text
VERDICT = PASS
BLOCKING = 0
MAJOR = 0
MINOR = 1
PACKAGE_IDENTITY = PASS
TARGET_IDENTITY = PASS
AUTHORITY_SET_IDENTITY = PASS
OLD_VALUE_REPRODUCED = YES
CORRECTED_VALUE_SUPPORTED = YES
AUTHORITY_CONVERGENCE = EXACT
OLD_IDENTITY_SUPPORTED = NO
CORRECTION_SURFACE = PASS
CORRECTION_RECORDS = 1
CHANGED_SUBFIELDS = 4
UNCHANGED_SUBFIELDS = 13
ANALYTICAL_FIELDS_CHANGED = 0
HISTORICAL_PACKAGE_UNCHANGED = YES
OVERLAY_ONLY = YES
EXISTING_ACCEPTED_OVERLAYS_TOUCHED = NO
FB0025_TOUCHED = NO
ENVIRONMENT_MATH_PRESERVED = YES
F0024_CORRECTION_VALID_FOR_FUTURE_EFFECTIVE_VIEW = YES
CANDIDATE_STATUS_BOUNDARY = PASS
```

## 10. Limits and stop

- Entire State Rebase and its acceptance/classification claims were not independently audited.
- F-B-0025 output-mootness and sourceQualityState were not adjudicated.
- No effective-view assembler, SHA-pinned effective analytical view, final Stage-2 regression, regression PASS, or Historical Environment Determination readiness is certified.
- No Environment assignment, Pair/ECS/friction calculation, sufficiency threshold, thin-coverage rule, MD-2 Phi, or determination contract was authored or re-audited.
- Negative proof concerns the current Owner-pinned lawful authority path; it does not prove absence of the old SHA from every historical file or explain the bad value's origin.
- Preservation proof covers the isolated candidate surface, pinned historical members, and the 64 pre/post-hashed protected files; it is not a retrospective certification of every prior author action.

No candidate/historical data repair, source write, Git mutation, memory-file write, final regression, 905-fact/18-side execution, Environment determination, or Pair/ECS/friction calculation was performed. No Owner acceptance is claimed.

The result is available for the Owner's disposition. No next act is started under this authorization.

**F0024_FACTUAL_PACKAGE_IDENTITY_CORRECTION_1_IV1_PASS**
