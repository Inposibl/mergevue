# STAGE2_EFFECTIVE_VIEW_ASSEMBLY_CONTRACT_1

- **Act:** STAGE-2 CORR4 PILOT — EFFECTIVE-VIEW ASSEMBLY CONTRACT-1
- **Contract version:** STAGE2_EFFECTIVE_VIEW_ASSEMBLY_CONTRACT_1 v1.0 (2026-10-05)
- **Actor:** Z-Ai
- **Role:** EFFECTIVE-VIEW ASSEMBLY CONTRACT AUTHOR / MATERIALISATION AUTHOR (Owner-assigned)
- **Mode:** BOUNDED DETERMINISTIC ASSEMBLY
- **Owner authorization:** Owner act "STAGE-2 CORR4 PILOT — EFFECTIVE-VIEW ASSEMBLY CONTRACT-1", 2026-10-05
- **Repository root:** `/Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)`
- **Baseline HEAD:** `2567223087d99b40bdfd174eed32566be7080e44` (branch `main`)
- **Status:** This contract governs ONE deterministic materialisation act. The resulting effective view is a CANDIDATE. It is NOT controlling until independently verified by a fresh non-author verifier AND separately Owner-accepted.

---

## 1. PURPOSE

Compose the first deterministic, reproducible, SHA-pinned Stage-2 effective analytical view:

```
EFFECTIVE_VIEW = BASE (historical Execution-1 Lane-A records)
               + OVERLAY 1 (FM0205 PLAN/CURRENT correction)
               + OVERLAY 2 (CO-PHYSICAL three-field correction)
               + OVERLAY 3 (F0024 factualPackageIdentity correction)
```

The historical package is never rewritten. Corrections live only in the NEW effective-view candidate.

## 2. INPUT IDENTITIES (fail-closed)

| Role | Artifact | SHA-256 | Bytes | Records |
| --- | --- | --- | --- | --- |
| BASE | `STAGE2_POST_RECONCILIATION_EXECUTION_1_CODER_A_RECORDS.jsonl` | `8914e745d5df3fbcfc4c4d47be3643ab44a0a3e89fae3d3445b9a94a0b042c71` | 104314 | 116 |
| OVERLAY 1 | `STAGE2_FM0205_PLAN_CURRENT_DRIFT_CORRECTION_1.json` | `64f489d7569a58d86d4996d1e9abf8538580915ac37ef31e542a0f13188660c4` | 11015 | 1 correction |
| OVERLAY 2 | `STAGE2_CO_PHYSICAL_STATE_DRIFT_CORRECTION_1.json` | `3319e912014bfd1f2e5c84da5c141c4e1a329d6095c102f2c081a82dced5f84a` | 13892 | 3 corrections |
| OVERLAY 3 | `STAGE2_F0024_FACTUAL_PACKAGE_IDENTITY_CORRECTION_1.json` | `0711b74240ddeecac7a95f15a0093ce44f3288f440929d6b803516e53ba6f983` | 11108 | 1 correction |

Physical source paths (under `WORKBENCH/DOWNLOADS/`):

- BASE: `STAGE2_POST_RECONCILIATION_EXECUTION_1_CODER_A_2026-10-04/STAGE2_POST_RECONCILIATION_EXECUTION_1_CODER_A_RECORDS.jsonl`
- OVERLAY 1: `STAGE2_FM0205_PLAN_CURRENT_DRIFT_CORRECTION_1_2026-10-04/STAGE2_FM0205_PLAN_CURRENT_DRIFT_CORRECTION_1.json`
- OVERLAY 2: `STAGE2_CO_PHYSICAL_STATE_DRIFT_CORRECTION_1_2026-10-04/STAGE2_CO_PHYSICAL_STATE_DRIFT_CORRECTION_1.json`
- OVERLAY 3: `STAGE2_F0024_FACTUAL_PACKAGE_IDENTITY_CORRECTION_1_2026-10-04/STAGE2_F0024_FACTUAL_PACKAGE_IDENTITY_CORRECTION_1.json`

BASE composition: 110 `POST_RECONCILIATION_EXECUTION_CELL_RECORD` + 6 `SECTION_I_RECORD`; pure ASCII; one JSON object per line; LF line terminators; exactly one trailing newline.

Overlay acceptance status: all three overlays are OWNER-ACCEPTED, INDEPENDENTLY VERIFIED, CONTROLLING for their exact correction surfaces. This contract composes them and does not alter, reinterpret, or extend them.

**Gate IN-1 (before) / IN-2 (after):** recompute SHA-256 of BASE and all three overlays before AND after the act; any mismatch from the table above → `EFFECTIVE_VIEW_ASSEMBLY_1_HOLD`.

## 3. CORRECTION EXTRACTION

Corrections are read from the overlay payloads themselves, not from prose:

- OVERLAY 1: its `correctionRecord` object (1 correction).
- OVERLAY 2: its `corrections` array (3 correction objects).
- OVERLAY 3: its `correctionRecords` array (1 correction object with full-object `oldValue` / `correctedValue`).

Required totals: `CORRECTION_RECORDS = 5`, `DISTINCT_TARGET_FIELDS = 5`. Any other count → HOLD.

## 4. TARGET-RESOLUTION RULE (semantic identity, never line number alone)

Line numbers below are descriptive only. Every correction must resolve by semantic identity to EXACTLY ONE base record/field. Resolution with 0 or >1 matches → HOLD.

**SECTION_I corrections** (A-E023, A-E001) require the conjunction:

- `recordType = SECTION_I_RECORD`
- `edgeId` equals the correction's `edgeId`
- `factIds` contains the correction's `factId`
- `mechanismPropositionIds` contains the correction's `mechanismPropositionId`
- `treeTargetIds` contains the correction's `targetId`
- corrected `field` is a direct scalar field of that record

**Execution-cell correction** (F0024) requires the conjunction:

- `recordType = POST_RECONCILIATION_EXECUTION_CELL_RECORD`
- `side = A` (lane A)
- `factId = F0024`
- `mechanismPropositionId = M-RES-ROLE-CONTROLLED-ACCESS`
- `targetId = TT-STPSTJ-RS`
- `field = factualPackageIdentity`
- corrected effective field is `assignedValue` (the cell's carrier of the factualPackageIdentity object)

Resolved targets (descriptive lines): A-E023 SECTION_I record (line 116), A-E001 SECTION_I record (line 115), F0024 `factualPackageIdentity` execution cell (line 51).

## 5. OLD-VALUE PRECONDITION RULE

Before applying any correction, the target's current value must deep-equal the correction's `oldValue`:

- A-E023 `planCurrentState` = `CURRENT`
- A-E023 `evidenceForm` = `DE-2`
- A-E023 `formalOperativeState` = `OPERATIVE`
- A-E001 `evidenceForm` = `DE-3`
- F0024 cell `assignedValue` = the complete accepted historical 17-key `factualPackageIdentity` old object (as carried verbatim in OVERLAY 3 `oldValue`)

Any precondition failure → HOLD. Corrections are never applied silently over unexpected values.

## 6. OVERLAY COLLISION GATE

Build the complete correction-path set before application. Expected five distinct effective targets:

1. `A-E023.planCurrentState`
2. `A-E023.evidenceForm`
3. `A-E023.formalOperativeState`
4. `A-E001.evidenceForm`
5. `F0024(execution cell).assignedValue` (effective field: factualPackageIdentity)

Required: `OVERLAY_COLLISIONS = 0` — no two corrections may target the same (record, effective field). Any collision → HOLD.

## 7. CANONICAL APPLICATION ORDER + ORDER INDEPENDENCE

Canonical order (for reproducibility):

1. OVERLAY 1 — FM0205 PLAN/CURRENT
2. OVERLAY 2 — CO-PHYSICAL three-field
3. OVERLAY 3 — F0024 factualPackageIdentity

Because all five target fields are disjoint, the assembler must additionally apply the three overlay packages in ALL SIX permutations, serialize each result under §8, and require byte-identical output. Required: `ORDER_INDEPENDENCE = PASS`. Any permutation divergence → HOLD.

## 8. DETERMINISTIC SERIALIZATION RULE

The effective view is JSONL with the BASE's exact physical conventions:

- File bytes are pure ASCII: one record per line; LF (`\n`) terminator after every record, including the last (exactly one trailing newline; no CRLF; no BOM). Non-ASCII codepoints inside string values are stored as `\uXXXX` escapes (the historical base carries exactly two such escapes, one em-dash `\u2014` on each of the two F-E-0182 SECTION_I lines).
- Line text = `json.dumps(record, ensure_ascii=True, separators=(", ", ": "))` (Python 3 `json.dumps` defaults: ASCII escaping + canonical `", "`/`": "` spacing), with key order = the record's historical insertion order. Corrections replace scalar values ONLY; they never insert, delete, move, or rename keys, so key order is preserved by construction.
- **Round-trip invariant (verified before authoring, 116/116):** every unmodified historical record re-serializes byte-identically to its historical line under this rule. Therefore unchanged records MUST be emitted as their historical line bytes verbatim, and the only byte-level changes in the effective view are the corrected values on the three changed lines. (The three changed lines contain no `\uXXXX` escapes and no non-ASCII codepoints, so the correction values serialize identically under this rule.)
- No pretty-printing, no `sort_keys`, no incidental formatting dependencies.

**SHA-256 generation rule:** `EFFECTIVE_VIEW_SHA256` = SHA-256 over the complete serialized file bytes (116 lines + terminators), computed once after final serialization and recorded in PROOF and MANIFEST.

## 9. OUTPUT RECORD-ORDER / STRUCTURE PRESERVATION

The effective view must preserve: record count = 116; record ordering = historical order; record identities = historical identities; all non-corrected fields = byte/semantic-equivalent values. Forbidden: inserted/deleted/reordered records, whole-row replacement synthesis, schema expansion, normalization of unrelated values.

Required: `RECORD_COUNT_PRESERVED = YES`, `RECORD_ORDER_PRESERVED = YES`.

## 10. EXPECTED EFFECTIVE VALUES

| Surface | Field | Historical | Effective |
| --- | --- | --- | --- |
| A-E023 SECTION_I | `planCurrentState` | CURRENT | **PLAN** |
| A-E023 SECTION_I | `evidenceForm` | DE-2 | **DE-4** |
| A-E023 SECTION_I | `formalOperativeState` | OPERATIVE | **FORMAL_ONLY** |
| A-E001 SECTION_I | `evidenceForm` | DE-3 | **DE-1** |
| A-E001 SECTION_I | `planCurrentState` | CURRENT | CURRENT (UNCHANGED / lawful) |
| F0024 cell `assignedValue` | `recordFileBytes` | 139589 | **61728** |
| F0024 cell `assignedValue` | `recordFileSha256` | `4b686b24…7198bb` | **`88b20920149b3fcde03e4e060cf4361e9494fe0137540bbc654c526337fd5f10`** |
| F0024 cell `assignedValue` | `packageFactCount` | 105 | **50** |
| F0024 cell `assignedValue` | `caseIdLocator` | package-level key 'case_id' | **record-level key 'case_id'** |

All remaining 13 `factualPackageIdentity` subfields unchanged.

## 11. EXPECTED DIFF GEOMETRY (fail-closed)

Relative to the historical 116-record base:

- `CHANGED_RECORDS = 3` — (a) A-E023 SECTION_I record, (b) A-E001 SECTION_I record, (c) F0024 factualPackageIdentity execution cell
- `UNCHANGED_RECORDS = 113`
- `DISTINCT_TARGET_FIELDS_CHANGED = 5`
- `LEAF_DIFFERENCES = 8` — recursive scalar/leaf diff, exactly:
  1. A-E023 `planCurrentState`
  2. A-E023 `evidenceForm`
  3. A-E023 `formalOperativeState`
  4. A-E001 `evidenceForm`
  5. F0024 `assignedValue.recordFileBytes`
  6. F0024 `assignedValue.recordFileSha256`
  7. F0024 `assignedValue.packageFactCount`
  8. F0024 `assignedValue.caseIdLocator`
- `OTHER_EFFECTIVE_DIFFS = 0` — the observed leaf-diff set must EQUAL the eight-entry set above; any extra or missing leaf → HOLD.

## 12. FIREWALLS

1. **F-B-0025 firewall.** `F-B-0025 sourceQualityState` remains `UNADJUDICATED`. The assembler must not select `COMPETENT` or `COMPETENT_SELF_DESCRIPTION_UNCORROBORATED` for it and must not alter its historical value to create a clean view. Required: `FB0025_TOUCHED = NO` (all F-B-0025-bearing records byte-identical).
2. **A-E001 planCurrentState firewall.** A-E001 `planCurrentState = CURRENT` is lawful history and stays unchanged.
3. **P-D3 / accepted-state firewall.** No alteration of: P-D3 six-key closure; F-E-0182 effective values; characteristicity fields; temporal fields; sourceQualityState; sourceClass; supportClass; discriminatorIds; treeTargetIds; counterevidenceFactIds; conflictFactIds; sufficiencyExpression(Result); edgeState; missingComponents; mechanism selection; fact text. Only the five accepted correction targets may differ from history (enforced mechanically by §11 exact-set leaf diff).
4. **F0024 IV-MINOR-001 explanatory precision.** Do NOT carry forward the false explanatory claim that the live Stage-1 file lacks a package-level `case_id`. The live Stage-1 JSON contains BOTH a top-level `case_id` AND record-level `case_id` on all 50 facts. The corrected `record-level` locator is controlling because the frozen Stage-1 source map and frozen provenance sidecar select the record-level locator. This is explanatory provenance only and does not alter the correction value.
5. **Environment-math preservation gate.** Root Definitional v1.7, A1-A4, R1-R4, T1 nine-Environment geometry, nine resource formulas, E9 semantic authority, Stage-2 TT registry, discriminator→tree-target bridge remain unchanged. This act performs no Environment assignment, no U-7/OM-1/MD-2/D2-10 act, no determination-contract authoring, no RULE FREEZE, no outcome use, no Pair/ECS/friction calculation. Required: `ENVIRONMENT_MATH_PRESERVED = YES`.

## 13. FAIL-CLOSED CONDITIONS

HOLD (`EFFECTIVE_VIEW_ASSEMBLY_1_HOLD`) if ANY of: base hash mismatch; overlay hash mismatch; target not unique; old-value precondition mismatch; overlay collision; unexpected changed field; changed-record count ≠ 3; leaf-diff count ≠ 8; record count ≠ 116; record order change; permutation-order output differs; historical source change; F-B-0025 change; any Environment/methodology surface change. Do not repair around a failed gate; emit no partial outputs.

## 14. HISTORICAL IMMUTABILITY + MATERIALISATION BOUNDARY

- BASE and all three overlays are READ-ONLY inputs. Re-hash before and after the act. `HISTORICAL_PACKAGE_MUTATED = NO`.
- This act materialises exactly ONE NEW candidate effective-view artifact set; corrections are never written back into the historical package.
- `EFFECTIVE_VIEW_CANDIDATE_MATERIALISED = YES`; `EFFECTIVE_VIEW_OWNER_ACCEPTED = NO`; `EFFECTIVE_VIEW_INDEPENDENTLY_VERIFIED = NO`.

## 15. LINEAGE / REPRODUCIBILITY

The materialised candidate binds:

```
BASE_SHA256      = 8914e745d5df3fbcfc4c4d47be3643ab44a0a3e89fae3d3445b9a94a0b042c71
OVERLAY_1_SHA256 = 64f489d7569a58d86d4996d1e9abf8538580915ac37ef31e542a0f13188660c4
OVERLAY_2_SHA256 = 3319e912014bfd1f2e5c84da5c141c4e1a329d6095c102f2c081a82dced5f84a
OVERLAY_3_SHA256 = 0711b74240ddeecac7a95f15a0093ce44f3288f440929d6b803516e53ba6f983
CONTRACT         = STAGE2_EFFECTIVE_VIEW_ASSEMBLY_CONTRACT_1 v1.0 (2026-10-05)
```

plus the resulting `EFFECTIVE_VIEW_SHA256` / `EFFECTIVE_VIEW_BYTES`. The effective view's identity is a pure function of `BASE + exact overlay identities + this contract version` under the deterministic algorithm of §§3–9; any re-execution on identical inputs must reproduce identical bytes.

## 16. REQUIRED OUTPUTS (exactly four, in `WORKBENCH/DOWNLOADS/STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_2026-10-05/`)

1. `STAGE2_EFFECTIVE_VIEW_ASSEMBLY_CONTRACT_1.md` — this contract.
2. `STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_RECORDS.jsonl` — the 116-record effective view.
3. `STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_PROOF.json` — the §17 proof values.
4. `STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_MANIFEST.json` — SHA-256 manifest binding inputs and outputs.

## 17. REQUIRED PROOF CONTENT

`PROOF.json` must report: `BASE_IDENTITY`, `OVERLAY_1_IDENTITY`, `OVERLAY_2_IDENTITY`, `OVERLAY_3_IDENTITY` (PASS), `CORRECTION_RECORDS = 5`, `DISTINCT_TARGET_FIELDS = 5`, `OVERLAY_COLLISIONS = 0`, `TARGETS_UNIQUE = YES`, `OLD_VALUE_PRECONDITIONS = PASS`, `ORDER_INDEPENDENCE = PASS`, `BASE_RECORDS = 116`, `EFFECTIVE_RECORDS = 116`, `CHANGED_RECORDS = 3`, `UNCHANGED_RECORDS = 113`, `DISTINCT_TARGET_FIELDS_CHANGED = 5`, `LEAF_DIFFERENCES = 8`, `OTHER_EFFECTIVE_DIFFS = 0`, `RECORD_COUNT_PRESERVED = YES`, `RECORD_ORDER_PRESERVED = YES`, `FB0025_TOUCHED = NO`, `HISTORICAL_PACKAGE_MUTATED = NO`, `ENVIRONMENT_MATH_PRESERVED = YES`, `EFFECTIVE_VIEW_SHA256`, `EFFECTIVE_VIEW_BYTES` (computed), plus the supporting detail (resolved targets, permutation hashes, leaf-diff list, firewall evidence, post-act input re-hashes).

## 18. CONSUMER BOUNDARY

The effective-view candidate is intended for the FINAL STAGE-2 MEASUREMENT REGRESSION. This act does NOT authorize that regression. No regression may consume the candidate as controlling input until (1) the assembly candidate is independently verified by a fresh non-author verifier AND (2) the Owner accepts the effective view as controlling.

## 19. VERIFICATION / ACCEPTANCE REQUIREMENTS

- Independent verification: fresh non-author verifier (author Z-Ai barred from verifying its own act).
- Owner acceptance: separate, explicit. An agent PASS/COMPLETE never becomes Owner acceptance.
- Until both: the candidate is evidence, not authority.

## 20. FORBIDDEN IN THIS ACT

Modify historical Execution-1; alter accepted overlays; create new analytical corrections; adjudicate F-B-0025; rerun coder A/B; rerun pilot facts; run final regression; modify Stage-2 methodology; establish semantic sufficiency; resolve OM-1/U-7; author MD-2 Φ; author a determination contract; RULE FREEZE; execute 905 facts / 18 sides; determine Environment; calculate Pair/ECS/friction; mutate Git; write memory files; claim independent verification; claim Owner acceptance.

## 21. TERMINAL STATES

- All gates pass → `EFFECTIVE_VIEW_ASSEMBLY_1_READY_FOR_IV`
- Any fail-closed condition → `EFFECTIVE_VIEW_ASSEMBLY_1_HOLD`

STOP after materialisation. Do not begin IV or final regression.
