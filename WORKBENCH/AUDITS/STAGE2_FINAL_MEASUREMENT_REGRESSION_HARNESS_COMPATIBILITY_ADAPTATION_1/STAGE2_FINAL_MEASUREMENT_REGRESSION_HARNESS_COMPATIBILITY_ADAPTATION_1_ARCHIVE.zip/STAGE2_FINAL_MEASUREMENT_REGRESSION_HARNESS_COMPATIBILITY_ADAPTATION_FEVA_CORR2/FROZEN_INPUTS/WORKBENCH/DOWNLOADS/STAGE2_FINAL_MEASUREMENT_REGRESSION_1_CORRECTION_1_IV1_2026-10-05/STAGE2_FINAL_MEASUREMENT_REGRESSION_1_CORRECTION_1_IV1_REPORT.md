# STAGE2_FINAL_MEASUREMENT_REGRESSION_1_CORRECTION_1_IV1_REPORT

VERDICT = HOLD

BLOCKING = 1  
MAJOR = 1  
MINOR = 0  
ADVISORY = 1

REG-007 = HOLD_METHODOLOGY_AMBIGUITY  
ownerAccepted = false  
controlling = false  
ENVIRONMENT_MATH_PRESERVED = YES

## ROLE AND MODE

Codex, Owner-appointed AUDITOR, independent read-only verification of the Claude Opus 5.5 correction candidate. Codex did not author the candidate. Codex authored the earlier failed regression, which was used as a defect locator and identity-history reference only. Its expected values and embedded harness were not used as the oracle. Expected direct bindings were reconstructed before reading Claude's ledger at 2026-10-05T15:56:19.096124+00:00.

Only the three requested IV artifacts are written. No source/candidate repair, coder rerun, official Final Stage-2 Measurement Regression, build, network action, Git command, commit, push, deployment or memory-file write occurs.

## TASK / QUESTION

Does the exact four-member candidate lawfully implement only deterministic measurement-consistency corrections, including a uniquely authorized typed componentSupply representation?

The directly bound values and physical repair mechanics pass. The candidate cannot pass the requested authority gate: the copied nested non-null reference values are not uniquely selected by the inspected method. A separate proof gap concerns the lawful preservation of A-E023 DIRECT_SUPPORT under the inherited DE-4 default.

## EVIDENCE INSPECTED

Physical root: /Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026). Local branch main, HEAD 2567223087d99b40bdfd174eed32566be7080e44, read through Git files. The audit does not run git status or assert a clean working tree.

The current Owner task pins the controlling method and predecessor. Workbench location or historical candidate headers do not change that explicit assignment. The Control Tree hash equals its .sha256 (360bafa29bad5ea93752323d4a217bf59aaec628e0e2b236350a2edd9c1f7128); its candidate/Owner-acceptance distinction is maintained. No later Control Tree base version was found; the September 21 report-product addendum does not settle these Stage-2 binding questions.

- [Controlling method](</Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)/WORKBENCH/DOWNLOADS/STAGE2_PD3_ROLE_BOUNDED_ENTITLEMENT_CLARIFICATION_1_CORR1_2026-10-04/STAGE2_PD3_ROLE_BOUNDED_ENTITLEMENT_CLARIFICATION_1_CORR1_CANDIDATE.md>): cb08b51e1c2fbaec7765989a7a4e15db1788c53eb5fec43f2628ecb88c1d6c73; 344754 bytes.
- [Predecessor](</Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)/WORKBENCH/DOWNLOADS/STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_2026-10-05/STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_RECORDS.jsonl>): a1fcae68939decd0a3c4a39c0a0bc48e8d285bd9cd7ce1928b0d025056244047; 104310 bytes; 116 records.
- [Candidate successor](</Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)/WORKBENCH/DOWNLOADS/STAGE2_FINAL_MEASUREMENT_REGRESSION_1_CORRECTION_1_2026-10-05/STAGE2_EFFECTIVE_VIEW_MEASUREMENT_CORR1_RECORDS.jsonl>): 3737bd5d5aa3b92f7f737fb6b35170ae35e936c2541d8b6fe053f8cb88a816c5; 104402 bytes; 116 records.
- Frozen source map, provenance sidecar, PI-7 binding, both coder-view schema versions, field-source matrix, 30-fact input, bounded CASE-3.4 packet and full CASE-3.4 v1.3.
- Historical Execution-1, three accepted physical-state/provenance overlays, assembly contract and census CORR1 join-divergence locators.
- Candidate ledger/report/manifest, inspected after deriving the direct expected rules. The author builder was not executed; its snapshot-format text was inspected to reproduce aggregate identities.

FINDINGS.json binds every inspected evidence file by SHA/bytes and records all comparisons, negative controls and 96 scalar-leaf diffs. Manifest path/hash/byte bindings: 23 independently measured, all match.

## SOURCE-OF-TRUTH CLASSIFICATION

OWNER FACT: current role, scope, pinned authorities, frozen-overlay applicability, both top-level and record-level case_id existence precision, required IV status boundary.  
METHODOLOGY FACT: M/TT rows, C-1/C-2, F.3/F.4/F.5, J-R rules, H/I and CASE-3.4 default.  
SOURCE/FILESYSTEM FACT: candidate member identities, 116 records, diff, carrier equality, recorded supply, no changes to protected inputs during IV.  
AGENT CLAIM: Claude's deterministic REG-007 proof, supportClass preservation justification and candidate-time snapshot assertions.  
INFERENCE: absence of a proven canonical nested-reference selector; absence of a demonstrated supportClass default override; possible external metadata activity.  
NOT DETERMINABLE: unique supportClass replacement, retrospective actor attribution, lawfulness of every optional non-null reference under every reading.

## PACKAGE / IMMUTABILITY

PACKAGE_MEMBER_COUNT = 4; all JSON/JSONL parse; order and semantic identities preserved; 110 execution cells + 6 Section-I records. Exactly 108 unchanged lines remain byte-identical. Candidate JSONL equals the assembly serialization convention (ASCII JSON, LF, one terminal newline, insertion order retained).

| Candidate member | Bytes | SHA-256 |
|---|---:|---|
| STAGE2_EFFECTIVE_VIEW_MEASUREMENT_CORR1_RECORDS.jsonl | 104402 | 3737bd5d5aa3b92f7f737fb6b35170ae35e936c2541d8b6fe053f8cb88a816c5 |
| STAGE2_FINAL_MEASUREMENT_REGRESSION_1_CORRECTION_1.json | 200862 | b7c26c16e2c383be256e96ff425e29c97a37f92b72ccb8be85e54d2822d9d1dd |
| STAGE2_FINAL_MEASUREMENT_REGRESSION_1_CORRECTION_1_MANIFEST.json | 12200 | 3b0ec4db13a8699af73142a1dedbce572b773df10f427b59332fda297cd21e9c |
| STAGE2_FINAL_MEASUREMENT_REGRESSION_1_CORRECTION_1_REPORT.md | 17313 | ee122a4baf00847c9ff78c8d2fcc2200253ec7f4ac0d35002ff0115f34a329a2 |

Predecessor, method, historical Execution-1 and the three overlay identities match their pinned bindings. Overlay values independently equal the corresponding predecessor carriers/records. Root v1.7 + E9: 35 files, author-format aggregate 6b29eeaaa8526073db675f9b373aeb41aede64fc8e270e1614ca4c11a43cb40b, independently reproduced.

A per-file audit snapshot covers 3702 protected files including Git, DOWNLOADS inputs/candidate, Root/E9 and src/api/scripts. Only .git/logs/refs/remotes/origin/HEAD changed during the IV; all other protected content remained unchanged. No auditor Git operation occurred. Snapshot coverage was extended before any artifact write; first selected-input snapshot started at 2026-10-05T15:54:35.232502+00:00. This proves audit-window stability, not every historical candidate-author operation.

Current 461-file DOWNLOADS aggregate is b629e68cc57814ca9a68578f173a13a517d4c461ade30c2b63961804f241c2c6 versus the author's 1444be1a442bc6dde635d62e6fea93319b0865c20aa84c4d9547f2a850277fb3. .DS_Store has a later modification time than the candidate manifest. That is a plausible explanation, not a reconstructed full historical diff: the author retained only the aggregate. All 23 individually bound files match.

Git local HEAD/ref/index/packed-refs/ORIG_HEAD/HEAD reflog hashes match the candidate snapshot. Remote HEAD reflog has grown since it; FETCH_HEAD and origin/HEAD mtimes advanced while their hashes stayed equal. No candidate-attributable Git mutation is established. Background fetch is an inference; actor attribution is not proved. These observations are not repaired.

## DELTA PURITY

CHANGED_RECORDS = 8  
CHANGED_FIELD_PATHS = 27  
TOTAL_LEAF_DIFFS = 96  
CHANGED = 20 / ADDED = 52 / REMOVED = 24

The scalar-to-object linkageEvidence change counts one removed scalar plus two added leaves; this independently reproduces the author's counting convention.

AUTHORIZED_DETERMINISTIC_CORRECTION = 80 scalar leaves  
UNEXPECTED / UNSUPPORTED CHANGE = 16 scalar leaves

The 16 unsupported additions are relationInstanceId and organizationalObjectRef in six nested Section-I entries and two execution carriers. They copy existing values accurately, but their deterministic authority is not established. This classification is not a claim that their factual objects are false. Delta purity is HOLD, rather than the claimed unconditional UNEXPECTED_DIFFS = 0.

| Record line | Changed top-level path | Leaf diffs | Classification | Unsupported leaves |
|---:|---|---:|---|---:|
| 9 | assignedValue | 9 | UNEXPECTED / UNSUPPORTED CHANGE | 2 |
| 56 | assignedValue | 9 | UNEXPECTED / UNSUPPORTED CHANGE | 2 |
| 111 | componentSupply | 9 | UNEXPECTED / UNSUPPORTED CHANGE | 2 |
| 112 | componentSupply | 9 | UNEXPECTED / UNSUPPORTED CHANGE | 2 |
| 112 | factualPackageIdentity | 4 | AUTHORIZED_DETERMINISTIC_CORRECTION | 0 |
| 113 | componentSupply | 9 | UNEXPECTED / UNSUPPORTED CHANGE | 2 |
| 113 | discriminatorIds | 1 | AUTHORIZED_DETERMINISTIC_CORRECTION | 0 |
| 113 | sufficiencyExpression | 1 | AUTHORIZED_DETERMINISTIC_CORRECTION | 0 |
| 114 | componentSupply | 9 | UNEXPECTED / UNSUPPORTED CHANGE | 2 |
| 114 | discriminatorIds | 1 | AUTHORIZED_DETERMINISTIC_CORRECTION | 0 |
| 114 | sufficiencyExpression | 1 | AUTHORIZED_DETERMINISTIC_CORRECTION | 0 |
| 115 | componentSupply | 9 | UNEXPECTED / UNSUPPORTED CHANGE | 2 |
| 115 | discriminatorIds | 1 | AUTHORIZED_DETERMINISTIC_CORRECTION | 0 |
| 115 | edgeState | 1 | AUTHORIZED_DETERMINISTIC_CORRECTION | 0 |
| 115 | missingComponents | 1 | AUTHORIZED_DETERMINISTIC_CORRECTION | 0 |
| 115 | scopeBridgeState | 1 | AUTHORIZED_DETERMINISTIC_CORRECTION | 0 |
| 115 | sourceClass | 1 | AUTHORIZED_DETERMINISTIC_CORRECTION | 0 |
| 115 | sufficiencyExpression | 1 | AUTHORIZED_DETERMINISTIC_CORRECTION | 0 |
| 115 | sufficiencyExpressionResult | 1 | AUTHORIZED_DETERMINISTIC_CORRECTION | 0 |
| 116 | componentSupply | 9 | UNEXPECTED / UNSUPPORTED CHANGE | 2 |
| 116 | discriminatorIds | 1 | AUTHORIZED_DETERMINISTIC_CORRECTION | 0 |
| 116 | edgeState | 1 | AUTHORIZED_DETERMINISTIC_CORRECTION | 0 |
| 116 | missingComponents | 3 | AUTHORIZED_DETERMINISTIC_CORRECTION | 0 |
| 116 | scopeBridgeState | 1 | AUTHORIZED_DETERMINISTIC_CORRECTION | 0 |
| 116 | sourceClass | 1 | AUTHORIZED_DETERMINISTIC_CORRECTION | 0 |
| 116 | sufficiencyExpression | 1 | AUTHORIZED_DETERMINISTIC_CORRECTION | 0 |
| 116 | sufficiencyExpressionResult | 1 | AUTHORIZED_DETERMINISTIC_CORRECTION | 0 |

## REG-001 THROUGH REG-006

REG-001 — PASS. F0024's frozen source-map case 4 and sidecar agree with accepted overlay/cell 51. Section-I line 112 now has 61728 bytes, 88b20920149b3fcde03e4e060cf4361e9494fe0137540bbc654c526337fd5f10, 50 facts, record-level key 'case_id'. Exactly four identity leaves differ; the other 13 keys and their ordering are preserved. Both top-level and record-level case_id exist per the Owner's explicit precision; the frozen authorities select record-level. No sibling physical package was reopened or absence claim made.

REG-002 — PASS. [C-1/C-2](</Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)/WORKBENCH/DOWNLOADS/STAGE2_PD3_ROLE_BOUNDED_ENTITLEMENT_CLARIFICATION_1_CORR1_2026-10-04/STAGE2_PD3_ROLE_BOUNDED_ENTITLEMENT_CLARIFICATION_1_CORR1_CANDIDATE.md:802>) requires the union of selected M-row D sets. The independently inspected registry rows bind RECOGNISED-COMMAND-ORDER to D-04, ENFORCE-SANCTION to D-06 and RES-CAPABILITY-ADVANTAGE to D-07. Lines 113/114/115/116 match. No new D judgment.

REG-003 — PASS. Registry census: 74 distinct M IDs and 62 TT rows. Exact mechExpr copied from TT-STPSTJ-ESS, TT-STPSTJ-PW, TT-STJSTP-PW and TT-NTSTJ-RS; every leaf exists. Six old unknown leaf occurrences are gone. Independent F.3/F.5 evaluation gives all selected leaves OPEN, every absent sibling OPEN and all six expressions OPEN. No negative/conflict evidence is recorded. A-E001 and A-E023 correctly change TRUE to OPEN. Derived target state within this bounded view is TARGET_NOT_ESTABLISHED_WITHIN_BOUND. No target output is materialized.

REG-004 — PASS, recorded-supply scope. A-E001 required c1,c2; recorded c1; missing c2. A-E023 required c1,c2,c3,c4; recorded c1; missing c2,c3,c4. H-7 gives PARTIAL. This means components are not recorded as supplied; it does not judge actual fact entailment. No absence/negative evidence is created.

REG-005 — PASS. Unit/program are narrower than enterprise under SC-CLAIM and CASE-3.4 §10. Both empty bridge lists produce UNRESOLVED_FAIL_CLOSED, preserving the narrower observation.

REG-006 — PASS. PI-7 keys use case/side/fact/ref/source identity. C-B04/C33-S01 and F-M-0205/S-M1 sectionIFill are OUTSIDE_FROZEN_VOCABULARY. Documentary genre is not a sourceClass. sourceQualityState remains unchanged.

## REG-007 — PRIMARY ADVERSARIAL GATE

BLOCKING IV1-F01. REG-007 = HOLD_METHODOLOGY_AMBIGUITY.

[F.4 applicability](</Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)/WORKBENCH/DOWNLOADS/STAGE2_PD3_ROLE_BOUNDED_ENTITLEMENT_CLARIFICATION_1_CORR1_2026-10-04/STAGE2_PD3_ROLE_BOUNDED_ENTITLEMENT_CLARIFICATION_1_CORR1_CANDIDATE.md:1160>) makes each row's own join declaration controlling. All four selected M rows lack REL-WITNESS. All five consuming TT rows declare it. Component-level and composite-target requirements are distinct; the explicit schema does not provide an unambiguous canonical reference-storage selector for their shared edge.

[J-R7](</Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)/WORKBENCH/DOWNLOADS/STAGE2_PD3_ROLE_BOUNDED_ENTITLEMENT_CLARIFICATION_1_CORR1_2026-10-04/STAGE2_PD3_ROLE_BOUNDED_ENTITLEMENT_CLARIFICATION_1_CORR1_CANDIDATE.md:1167>) says no-join rows record references as null and NO_LAWFUL_LINKAGE without a linkage test; it also allows an affirmative linkage record as voluntary metadata with no output effect. An inherited non-null label with NO_LAWFUL_LINKAGE is not automatically that affirmative record. J-R2/J-R3 cannot be applied as an unconditional copying rule while ignoring J-R7 applicability.

Typed schema passes: six required nested keys, class/identifier object, no status or entailmentBasis or string linkageEvidence, correct M/component/fact membership. Schema validity does not determine canonical values. The six entries and cells 9/56 are consistent physical copies, while the authority question remains open.

### Ten required answers

1. M-row declaration controls component/leaf join applicability; consuming TT-row declaration separately controls composite target join. The rules define these two semantic obligations, but do not unambiguously specify canonical M-labelled nested reference storage when a joint Section-I edge also carries TT context.

2. J-R7 explicitly records null references for no-join rows. Its affirmative-linkage voluntary-metadata clause is not an unconditional permission for non-null refs with NO_LAWFUL_LINKAGE. Claude does not establish that its new nested refs fall within that exception.

3. J-R2/J-R3 bind components and reference objects where REL-WITNESS is applicable. They cannot create an M-local requirement overridden by J-R7. TT join obligations survive, but those clauses do not independently prove unconditional copying of outer refs into every M-labelled component when no linkage is established.

4. Output invariance is reproduced; representation-lawfulness invariance is not proved. The M-reading permission premise is unproved, and equality of OPEN results is not canonical authority.

5. Nested null/null is expressly supported under the no-join M reading; mandatory keys remain present. Leaving outer TT references intact and failing its unestablished join keeps completion OPEN. Its universal canonical status on this joint storage surface is unresolved.

6. No explicit deterministic selector of copied non-null versus M-local null reference storage was found in controlling method, either schema view, field-source matrix, accepted overlays, or assembly contract. The explicit null instruction and conditional voluntary exception cannot be replaced by an author preference.

7. No exact Owner authorization selecting this representation was established. A deterministic correction mandate is insufficient to settle an unresolved methodological storage choice; author assertions do not create that authority.

8. Outer join fields are byte/semantic unchanged and no downstream ADV-2 adjudication was run. The new nested projection embodies a representation choice adjacent to the unresolved issue; it must not be reported as closing the outer A/B divergence.

9. Six c1 memberships are preserved. Compared with an in-memory null-reference variant, edge states, leaf/target results, source classes/diversity applicability, negative/conflict records and all other unchanged fields are invariant. The actual PARTIAL/OPEN/sourceClass corrections on lines 115/116 are attributable to REG-003/004/005/006, not a established join. No affirmative absence introduced.

10. YES. Cells 9 and 56 exactly equal Section-I lines 111 and 112, respectively; all 110 available carrier comparisons have zero divergence.

The in-memory null/null alternative has zero shape errors, the same six expression/target results, identical edge states, outer refs, source classes and negative/conflict records. No mutated fixture is written. This establishes bounded output invariance only. It neither selects the alternative nor legitimizes the candidate's representation.

No categorical FAIL_WRONG_BINDING is asserted while shared M/TT storage authority is unresolved. No PASS is granted on the strength of output invariance. The controlling default and the conditional exception must be made explicit for this exact storage surface before a deterministic correction can be accepted.

## REG-008

MAJOR IV1-F02. A-E023 mechanically preserves PLAN / DE-4 / FORMAL_ONLY and DIRECT_SUPPORT. Independent component, scope, temporal, formOp and current-state gates yield [c2,c3,c4] / PARTIAL / OPEN. These consequences pass.

Lawful preservation of DIRECT_SUPPORT is not established. [CASE-3.4 DE-4](</Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)/docs/reference/root-definitional-v1.7/contract/CASE-3.4_CONTRACT_v1.3.md:213>) expressly defaults to NON-DISCRIMINATING or NOT DETERMINABLE. [H-8](</Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)/WORKBENCH/DOWNLOADS/STAGE2_PD3_ROLE_BOUNDED_ENTITLEMENT_CLARIFICATION_1_CORR1_2026-10-04/STAGE2_PD3_ROLE_BOUNDED_ENTITLEMENT_CLARIFICATION_1_CORR1_CANDIDATE.md:1221>) assigns supportClass relative to the consuming TT; G-5/H-2 distinguish selection/formal component evidence from operative establishment. No current TT has the constitutive exception.

There is no unique automatic replacement among the default classes; no label is assigned here. That does not imply DIRECT_SUPPORT is lawful. The physical-state overlays preserved other fields without separately accepting their methodological correctness. No exact field-specific lawful override was established for A-E023 in the inspected authorities. This finding is a proof gap, not new entailment re-coding, a claimed deterministic alternative or a supportClass write.

## SELF-CHECK REPRODUCTION

Independent predicates were constructed from the method and frozen bindings. The author builder and previous regression harness were not executed.

| Predicate | Independent result |
|---|---|
| F0024_SECTION_I_PROVENANCE_CONSISTENT | YES |
| DISCRIMINATOR_BINDINGS | PASS |
| SUFFICIENCY_EXPRESSIONS | PASS |
| COMPONENT_COVERAGE | PASS |
| SCOPE_BRIDGE_STATES | PASS |
| SOURCE_CLASS_BINDINGS | PASS |
| COMPONENTSUPPLY_SCHEMA | PASS |
| SECTION_I_COMPONENTSUPPLY_SCHEMA_ERRORS | 0 |
| EXECUTION_CELL_COMPONENTSUPPLY_SCHEMA_ERRORS | 0 |
| A_E023_DOWNSTREAM_CONSISTENCY | MECHANICAL_PASS; SUPPORTCLASS_AUTHORITY_NOT_ESTABLISHED |
| PREVIOUS_DETERMINISTIC_MISMATCHES_REMAINING | 0 |
| ALL_SECTION_I_RECOMPUTED_SURFACES_MISMATCHES_REMAINING | 0 |
| CELL_TO_SECTION_I_CARRIER_DIVERGENCES | 0 |
| FIREWALL_VIOLATIONS | 0 |
| SUPPORTCLASS_CHANGED | NO |
| UNCHANGED_LINES_BYTE_IDENTICAL | YES |

The zero mismatch counts cover the eight directly reconstructible field groups on all six Section-I rows. They exclude non-determinable reference-storage authority and supportClass lawfulness. COMPONENTSUPPLY_SCHEMA means shape only. The author's broad authority conclusions therefore do not follow from its mechanical zeros.

## FORCED-FAILURE / VALIDATION

All ten specified in-memory negative controls cause new detections relative to the candidate's empty mechanical issue set:

- revert discriminator: RECOMPUTED:113:discriminatorIds — fired.

- restore stale expression: RECOMPUTED:114:sufficiencyExpression — fired.

- restore A-E023 TRUE: EXPR_RESULT:116 — fired.

- restore old F0024 identity: RECOMPUTED:112:factualPackageIdentity — fired.

- remove typed key: SHAPE:111: — fired.

- inject legacy key: SHAPE:112: — fired.

- alter nested factId: NESTED_FACT:113 — fired.

- alter relationInstanceId: NESTED_COPY_DIVERGENCE:115:relationInstanceId — fired.

- change FB0025 quality: FIREWALL:111:sourceQualityState — fired.

- unexpected ninth changed record: UNEXPECTED_CHANGED_RECORD — fired.

The relationInstance control tests inherited-copy integrity, not canonical-method authority. Expression evaluation, source/fact/M checks, firewall comparison, carrier equality and ninth-record detection are independently implemented. These are local correction-IV predicates, not the official final-regression rerun. No mutating validator, build or browser session is run.

## FIREWALLS / ENVIRONMENT MATH

FB0025 sourceQualityState stays COMPETENT in physical Lane A, both Section-I line 111 and cell 35. COMPETENT versus COMPETENT_SELF_DESCRIPTION_UNCORROBORATED is not adjudicated.

Fact identity/text, case/side, M selection, characteristicity, temporal judgments, sourceQualityState, supportClass, counter/conflict/relevance/absence states, outer join fields and nonExpansionRationale are unchanged. Actual changes are confined to the 27 enumerated paths; the reference representation choice remains the authority issue described above. Cells 9/56 match their Section-I consumers; all 110 available carrier checks have zero divergence.

Root/E9 hash binding and audit-window stability pass. Successor has no Environment/score/ranking/ECS/friction fields. No Environment assignment/candidate/ranking, U-7, OM-1, MD-2 Phi, D2-10, HEDC, RULE FREEZE, 905/18-side replay, Pair, ECS or friction act is performed. Stage-2 measures inputs only; this IV supplies no determination contract or Environment result.

## QUALITY-GATE DISCIPLINE

Relevant AUDITOR portions of [mergevue-agent-quality-gate SKILL](</Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)/skills/mergevue-agent-quality-gate/SKILL.md>) applied. Concrete risks: treating copied references as methodological authority (HF-04); treating passing shape/consistency validators as sufficient lawfulness proof (HF-06). Audit used independent predicates and forced failures, separated source from author claims, and kept component evidence separate from Owner acceptance. No full retrospective, new control package, skill edit or governance write.

## LIMITATIONS / OWNER DECISION FRAME — EVIDENCE LEDGER

ACT: determine whether the exact correction candidate meets the pinned IV criteria.  
ROLE: AUDITOR.

READ: controlling method F.4/J-R/I, M/TT registries, both frozen schema views, field-source matrix, accepted overlays, assembly contract, C34 and census join locator.  
DERIVED: direct provenance, D, expressions, recorded complement, scope and PI-7 values; Boolean OPEN consequences.  
INSPECTED: physical root, branch/HEAD files, candidate 4 members, 116 records, full diff, exact snapshots and all manifest bindings. No clean-state claim.  
ELIMINATED: provenance/D/components/scope questions killed by SOURCE/DERIVATION/REPOSITORY gates; physical invariance resolved in memory; no Owner recall requested.  
UNRESOLVED AFTER SEARCH: canonical nested-reference projection and lawful A-E023 DE-4 supportClass override are not proved by the inspected authorities. A current Owner instruction selecting these choices was not established.  
MATERIALITY: they affect binding authority and admissible measured semantics even when current completion remains OPEN.  
AUTHORITY/NOW: this auditor cannot invent a methodological selector or replacement label; acceptance cannot proceed on missing proof. No representation-choice question is put to the Owner by this IV. The Owner controls only the scope/authorization of a subsequent act; existing authority should be clarified first.

Retrospective candidate-time Git actor attribution and the whole DOWNLOADS digest difference are not fully determinable from aggregate snapshots. Protected data identities and audit-window invariance are independently measured. No sibling-source reopening or 905-fact semantic corpus execution is performed.

## RECOMMENDED NEXT ACTION / OWNER DECISION REQUIRED

Do not adopt successor 3737bd5d... yet. The smallest follow-up is a separately bounded authority clarification of component-versus-target reference storage and retrieval/proof of the DE-4 supportClass override (or a separately authorized field-local assessment). A subsequent deterministic correction/re-IV depends on that evidence. No new act is started and no replacement representation or label is chosen here.

Owner acceptance is a separate transition. ownerAccepted = false; controlling = false. The predecessor remains the controlling view under the current Owner task.

## VERDICT

HOLD — BLOCKING 1 / MAJOR 1 / MINOR 0 / ADVISORY 1.

The correction-IV package is complete. The candidate does not clear deterministic-authority/lawfulness requirements. No final Stage-2 regression closure, implementation acceptance, Git closure or production claim follows. STOP AFTER IV PACKAGE.
