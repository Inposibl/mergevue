# STAGE2_MEASUREMENT_AUTHORITY_CLARIFICATION_1

**Act:** STAGE-2 CORR4 PILOT — MEASUREMENT-AUTHORITY-CLARIFICATION-1
**Actor:** Z-Ai (GLM-5.3) · **Role:** METHODOLOGY / AUTHORITY ANALYST (Owner-assigned)
**Mode:** READ-ONLY BOUNDED AUTHORITY DETERMINATION
**Date:** 2026-10-05
**Repository root:** `/Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)`
**HEAD at act:** `2567223087d99b40bdfd174eed32566be7080e44` (main, read-only; no Git command that mutates state)

This act determines authority only. It repairs, rewrites, materialises and accepts nothing.
It does not accept Claude CORRECTION-1 and does not accept successor effective view
`3737bd5d5aa3b92f7f737fb6b35170ae35e936c2541d8b6fe053f8cb88a816c5`.
The predecessor effective view `a1fcae68939decd0a3c4a39c0a0bc48e8d285bd9cd7ce1928b0d025056244047` remains controlling.

---

## 0. REQUIRED OUTPUT BLOCK

```text
QUESTION_A_VERDICT =
NOT_DETERMINABLE_FROM_CURRENT_AUTHORITY

QUESTION_B_VERDICT =
DIRECT_SUPPORT_NOT_PROVEN_AND_REPLACEMENT_NOT_DETERMINABLE

OWNER_DECISION_REQUIRED_A =
YES

OWNER_DECISION_REQUIRED_B =
YES

CAN_CORRECTION_1_BE_DETERMINISTICALLY_REPAIRED_WITHOUT_NEW_OWNER_METHOD_DECISION =
NO
```

---

## 1. ROLE AND MODE

Z-Ai, Owner-appointed authority analyst, read-only. The act answers exactly the two
authority gaps raised by `STAGE2_FINAL_MEASUREMENT_REGRESSION_1_CORRECTION_1_IV1`
(Codex, HOLD, BLOCKING 1 / MAJOR 1 / MINOR 0 / ADVISORY 1). Neither Claude's
candidate rationales nor Codex's IV opinions are used as authority; both are inspected
and classified as PRIOR AGENT CLAIMS. Every normative statement below is grounded in
text read by this act from hash-identified files.

## 2. TASK / QUESTION

**A (REG-007).** The controlling canonical rule for nested
`componentSupply[].relationInstanceId` / `componentSupply[].organizationalObjectRef`
when the selected M row declares no REL-WITNESS join, the consuming TT row declares
REL-WITNESS, `linkageEvidence.class = NO_LAWFUL_LINKAGE`, and the Section-I record
jointly carries M-level component semantics and TT-level context — representation
A (non-null inherited references) versus representation B (null nested references,
outer TT-context references unchanged).

**B (REG-008).** Whether A-E023 may lawfully retain `supportClass = DIRECT_SUPPORT`
while the accepted/effective states are `planCurrentState = PLAN`,
`evidenceForm = DE-4`, `formalOperativeState = FORMAL_ONLY`, `edgeState = PARTIAL`,
`sufficiencyExpressionResult = OPEN`.

## 3. EVIDENCE INSPECTED (all SHA-256 verified this act)

| # | Artifact | SHA-256 | Classification |
|---|---|---|---|
| E1 | Controlling Stage-2 methodology `STAGE2_PD3_ROLE_BOUNDED_ENTITLEMENT_CLARIFICATION_1_CORR1_CANDIDATE.md` (§A.6/A.8, §B+F join declarations, §C, §D M rows, §E, §F.3/F.4/F.4.1/F.5, §G-5, §H-2/H-8, §I, §Q/F08, §X) | `cb08b51e1c2fbaec7765989a7a4e15db1788c53eb5fec43f2628ecb88c1d6c73` | METHODOLOGY FACT (Owner-pinned by the current task) |
| E2 | `docs/reference/root-definitional-v1.7/contract/CASE-3.4_CONTRACT_v1.3.md` (§6 DE-1..DE-4 + constitutive-rule exception; §13.2; §14) — matches the SHA the methodology itself pins for C34 (dae81438…) | `dae8143899cd4fb7e406b4b410e9730a6f8bf7853989f3ef9757edeec293ae39` | METHODOLOGY FACT (Root definitional authority imported by E1 §A) |
| E3 | Coder-view schema `…CODER_VIEW_SCHEMA_CORR2_CORR1.json` (consumed by the regression) | `0d08c7e1f88a408967be157f73e9bd04c59bee5e977b4efe7b266cfc3ab8278c` | PHYSICAL/FILE FACT (frozen pilot instrument; shape authority only) |
| E4 | Coder-view schema successor `…CORR2_CORR1_CORR2_CORR1.json` (self-declared sole controlling execution view; status field: AUTHOR CORRECTION CANDIDATE — NOT INDEPENDENTLY VERIFIED — NOT OWNER-ACCEPTED) | `0cb5a6b5d2239855eeabe0bfd0e9ceb6c545dc2a86b4b34a90b65187592721b5` | PHYSICAL/FILE FACT |
| E5 | Field-source matrix CORR2 | `1fb84aed8aadeb2b4c2fc85eb6e01cd2ea3849fae5be28a39e0b65ca4e4e2cdd` | PHYSICAL/FILE FACT (frozen pilot instrument) |
| E6 | Predecessor effective view records (116 rec) | `a1fcae68939decd0a3c4a39c0a0bc48e8d285bd9cd7ce1928b0d025056244047` | PHYSICAL/FILE FACT (controlling view per Owner task) |
| E7 | Candidate successor records (Claude CORRECTION-1; NOT accepted) | `3737bd5d5aa3b92f7f737fb6b35170ae35e936c2541d8b6fe053f8cb88a816c5` | PHYSICAL/FILE FACT |
| E8 | IV1 report (Codex HOLD) | `7fa1a13318f6386d2d471b378bab60cbb4ea7c24f91857cfdd19853aa6c60b65` | PRIOR AGENT CLAIM |
| E9 | CORRECTION-1 report (Claude, author) | `ee122a4baf00847c9ff78c8d2fcc2200253ec7f4ac0d35002ff0115f34a329a2` | PRIOR AGENT CLAIM |
| E10 | Final measurement regression report (REG-007/REG-008 origin, Codex) | `9a58d38785b7dba5b6a9164985e5ac9c6fc6ac10115f2229df900e4e68f5f2c3` | PRIOR AGENT CLAIM |
| E11 | Census CORR1 JSON (join-field matrix; ADV-2 note) | `4015f573b7d0ba219a4ee762418826aa4e7964231d8957cbf8d1ac250504f210` | PRIOR AGENT CLAIM (IV'd candidate; not Owner-accepted methodology) |
| E12 | Execution-1 A/B comparison report (J-R7 nested-form parenthetical) | `c1346c2f9353e6f34e55fe1cea529dedb35ed069a9332693fae0971f68c76497` | PRIOR AGENT CLAIM |
| E13 | Effective-view assembly contract 1 | `4e2ff3d00baa05dc82dc4f72318c413b0683cbe0d050ee026bb8b6ad7c6eee66` | PHYSICAL/FILE FACT (assembly act contract; 5-field overlay scope) |
| E14 | FM0205 PLAN/CURRENT overlay (Owner-accepted controlling; 1 field: A-E023 planCurrentState → PLAN) | `64f489d7569a58d86d4996d1e9abf8538580915ac37ef31e542a0f13188660c4` | OWNER FACT (accepted, per state rebase E16) |
| E15 | Co-physical overlay (Owner-accepted controlling; 3 fields: A-E023 evidenceForm DE-2→DE-4, A-E023 formalOperativeState → FORMAL_ONLY, A-E001 evidenceForm DE-3→DE-1) | `3319e912014bfd1e2e5c84da5d141c4e1a329d6095c102f2c081a82dced5f84a` | OWNER FACT (accepted, per state rebase E16) |
| E16 | Post-drift-closure state rebase (accepted-controlling state enumeration) | `763f32df2af694511cb27e92f882f462f4b40ac460ccda0e71c4d725346c2a7b` | OWNER FACT / session-state record |
| E17 | Five-RC rerun Lane A records (controlling pre-Execution-1 carrier; A-E023 line 34) | `0aeb8fceb2dce7bd0ec82bb3f08985a42a89ca91b519ec63aee689f0f55d91bd` | PHYSICAL/FILE FACT |
| E18 | Five-RC rerun Lane B Section-I records (F-M-0205 row) | `f79c7b218406b3af2e3ade0f8aa4b737db19e40062a8a78273e85c5b6f6d6968` | PHYSICAL/FILE FACT |
| E19 | Execution-1 Lane A records (historical base of the effective view) | `8914e745d5df3fbcfc4c4d47be3643ab44a0a3e89fae3d3445b9a94a0b042c71` | PHYSICAL/FILE FACT |
| E20 | Execution-1 Lane A coder report (supportClass derivations) | `69b27ca5a7a2fd0ad65c914291868cf36e54d7c088079c905e9c0f0ac4063484` | PRIOR AGENT CLAIM |
| E21 | Frozen pilot result schema (R-05 join-agreement measurement) | `816f26cc616af20d9f9f54640acb426cbddd7698c1cf1a08c494e5e11674c12c` | PHYSICAL/FILE FACT (frozen instrument) |

Registry facts read directly from E1 (verified this act, not taken from any report):
the four selected M rows — `M-RES-ROLE-CONTROLLED-ACCESS` (§D line 988), `M-ENFORCE-SANCTION`
(966), `M-RECOGNISED-COMMAND-ORDER` (984), `M-RES-CAPABILITY-ADVANTAGE` (944) — carry
**no join segment**; the five consuming TT rows — `TT-STPSTJ-RS` (695), `TT-STPSTJ-PW`
(683), `TT-STPSTJ-ESS` (671), `TT-STJSTP-PW` (539), `TT-NTSTJ-RS` (333) — each declare
`join: REL-WITNESS(…)`.

## 4. SOURCE-OF-TRUTH CLASSIFICATION (summary)

- **OWNER FACT:** this task's role/scope/stopping point; the pinning of E1 as controlling
  methodology; the pinned predecessor (E6) as controlling view; the non-acceptance of
  E7; the accepted status of overlays E14/E15 (as enumerated by E16).
- **METHODOLOGY FACT:** all E1 §F.4/J-R/F.4.1/§I/§E/§H/§G text quoted below; E2 §6/§14 text.
- **PHYSICAL / FILE FACT:** all byte-level observations (record shapes, lane forms,
  hashes, overlay field inventories, schema diffs).
- **PRIOR AGENT CLAIM:** E8, E9, E10, E11, E12, E20 conclusions; Claude's "reading
  invariance" theory; Codex's ten REG-007 answers.
- **INFERENCE:** the level-split construction in §5.4 (labelled as construction);
  the fail-closed burden reading in §6.
- **NOT DETERMINABLE:** the canonical nested-storage selector (Question A); a lawful
  supportClass value for A-E023 under DE-4 (Question B replacement).

---

## 5. QUESTION A — REG-007 CANONICAL COMPONENTSUPPLY REFERENCES

### 5.1 Controlling text (E1, quoted verbatim)

- **F.4 JOIN APPLICABILITY (line 1160):** "Join applicability is declared by the ROW
  ITSELF. Presence of a `join: REL-WITNESS(object)` declaration makes the
  relational-witness requirement binding for that row: completion requires all component
  edges bound to one relationInstanceId over the named object under §F.4.1 and
  J-R1..J-R6. An explicit `join: NONE` declaration — or the absence of any join key —
  means the row's components are atom-local/independent: NO relational witness is
  required and none may be demanded, inferred, or created for that row; its component
  edges are evaluated independently, without relationInstanceId binding."
- **J-R2 (1162):** "Each component edge names the relationInstanceId it supplies;
  components supplied by edges bound to different relationInstances do not compose."
- **J-R3 (1163):** "The relationInstanceId references the organizational object via
  organizationalObjectRef (and decisionRef / resourceFlowRef / participationSystemRef /
  beliefSystemRef as applicable) — reference fields only."
- **J-R5 (1165):** "TT-composite rows (e.g. TT-SFPSFJ-DOC) require one shared
  relationInstanceId across all component leaves, plus any row-specific extra conditions."
- **J-R6 (1166):** "If component edges cannot be lawfully bound to one relationInstance,
  the leaf is OPEN (the relation is NOT_ESTABLISHED_WITHIN_BOUND), never FALSE."
- **J-R7 (1167):** "A coder may neither add a join requirement to a row without a
  REL-WITNESS declaration nor treat a declared REL-WITNESS as optional; … For rows
  without a REL-WITNESS declaration: relationInstanceId, organizationalObjectRef,
  decisionRef, resourceFlowRef, participationSystemRef and beliefSystemRef are recorded
  as null, linkageEvidence is recorded as NO_LAWFUL_LINKAGE without any §F.4.1 test
  having been run (denoting inapplicability of the linkage test, not a failed test), and
  an affirmative linkage record on such a row is voluntary metadata with no effect on any
  edgeState, leaf value, or target state."
- **F.4.1 (1180):** "Coders record the linkage class + identifier or record
  NO_LAWFUL_LINKAGE."
- **§I (1225–1226):** `componentSupply[]` entry shape
  `{mechanismPropositionId, componentId, factIds[], relationInstanceId,
  organizationalObjectRef, linkageEvidence{class, identifier}}`; the same §I record
  separately carries record-level `relationInstanceId · organizationalObjectRef ·
  decisionRef · resourceFlowRef · participationSystemRef · beliefSystemRef`;
  "Relational joins are explicit and reproducible through relationInstanceId +
  organizationalObjectRef + componentSupply."
- **§Q F08 closure (1317):** "§I componentSupply keyed by {M, componentId, factIds,
  relationInstanceId, organizationalObjectRef}."

### 5.2 Required determination 1 — which row's join declaration controls nested storage

**NOT EXPLICITLY SETTLED.** F.4 makes applicability row-scoped ("declared by the ROW
ITSELF") and J-R1..J-R6 are scoped by F.4 to rows *that declare* REL-WITNESS. The
componentSupply entry is M-keyed (`mechanismPropositionId`), which grounds the M-row
reading; but §I also lists record-level reference fields on the same TT-scoped edge
record (edgeId names the TT), and §I's closing sentence names both levels jointly
without assigning the TT-composite join (J-R5) a storage locus. No sentence in E1
assigns the nested reference storage to the M row's or the TT row's declaration when
the two disagree. **This assignment is a construction (see 5.4), not an explicit rule.**

### 5.3 Required determinations 2–4

**2. Does J-R7 govern this exact joint M/TT storage surface?** Not explicitly. J-R7's
subject is "rows without a REL-WITNESS declaration" and its null instruction enumerates
the six §I record-level field names; `relationInstanceId` and `organizationalObjectRef`
are also members of the nested entry shape, so the instruction *can* be read as reaching
the nested fields (the enumerated list is the reference-field vocabulary of §I, not a
level-scoped list), or as record-level-only. Both readings survive the text. Two
project-internal engagements of this exact surface read J-R7 as governing the nested
fields (Lane B's five-RC practice, E18; the Execution-1 A/B comparison's explicit
"mandated form" parenthetical, E12) — both are PRIOR AGENT READINGS, not authority.

**3. Do J-R2/J-R3 require non-null nested references despite M-row no-join? NO.**
J-R2/J-R3 are rendered binding "for that row" only by a row's own REL-WITNESS
declaration (F.4, first sentence of JOIN APPLICABILITY). The four M rows declare
nothing, so no M-local naming obligation exists for their component edges; F.4 states
those edges are "evaluated independently, without relationInstanceId binding" and that
no witness "may be demanded, inferred, or created for that row". The TT-side composite
obligation (J-R5) is genuine and survives (J-R7 clause 1: a declared REL-WITNESS is not
optional), but it is an obligation on the *contributing edges* (the TT's component
leaves are M-propositions supplied by edge records), and the census CORR1 (E11) plus the
regression itself (E10: "Outer record fields are lawful") place that binding at the
record-level fields, which representation B leaves untouched.

**4. Does the voluntary-metadata exception permit the exact Claude representation? NO.**
J-R7's carve-out covers "an **affirmative linkage record**". The candidate's nested
entries carry `linkageEvidence = {class: NO_LAWFUL_LINKAGE, identifier: null}` — the
negative branch of F.4.1's recording dichotomy, definitionally not an affirmative
linkage record. The carve-out therefore does not reach the exact form
(non-null references + NO_LAWFUL_LINKAGE class). This is a facial textual determination,
not a construction. (Physical corroboration, E17/E18: the only historically recorded
non-null nested form on a no-join M — Lane A's five-RC row — carried affirmative L-1
records with identifiers, i.e. inside the carve-out; Lane B recorded null/null +
NO_LAWFUL_LINKAGE. Claude's hybrid matches neither lawful historical form.)

### 5.4 Is there a deterministic canonical selector? (determination 5)

**No explicit selector exists.** Searched: E1 (§A.6, §F.3/F.4/F.4.1/F.5, §I, §Q, §X),
both coder-view schemas E3/E4 (componentSupply definitions character-identical; shape
only — the two schema versions differ only in execution-control bookkeeping, verified by
diff), field-source matrix E5 (nested `relationInstanceId`/`organizationalObjectRef` =
`ASSIGNMENT_TYPE: CODER_JUDGMENT`, authority "§F.4" generally, no null/inherit rule),
frozen result schema E21 (R-05 measures record-level join agreement), accepted overlays
E14/E15 (field inventories exclude componentSupply), assembly contract E13 (authorized
surface = exactly 5 disjoint overlay fields; componentSupply out of scope), census CORR1
E11 (record-level join fields TT-binding; silent on nested storage).

The **best construction** (this act's INFERENCE, presented for the Owner, not as
authority): the two storage levels carry different semantics — nested entries are
M-granular join storage (M-keyed; able to differ per entry per J-R4; part of the F08
component identity keying), record-level fields are the edge/TT-composite binding
(census CORR1's TT-binding treatment; J-R5's across-edge shared id). Under this
level-split construction the nested fields of a no-join M row are governed by J-R7's
null mandate (inapplicability semantics), the outer fields by the TT's declaration
(unchanged, non-null), and **representation B is the canonical form** — harmonizing
J-R7, census CORR1 and both lanes' physical practice simultaneously. But the level
assignment is derived from structure, not stated; a literal field-list scoping of J-R7's
null instruction survives; and an independent verifier reading the same corpus (E8)
declined to derive it. Under §14A GATE 2 this is not a mechanical derivation.

### 5.5 Verdict

- `A_REQUIRED` is **eliminated**: no text mandates non-null nested references on a
  no-join M row; the only non-null pathway (the affirmative-record carve-out) is facially
  inapplicable, and J-R2/J-R3/J-R5 bind only declared rows.
- Representation B is **expressly supported** under the M-scoped reading of J-R7 (and is
  the independent Lane B physical form, E18).
- The exact A-hybrid's lawfulness is **not established** under any reading (prohibited
  under the M-scoped reading; merely unregulated under the literal reading).
- `BOTH_LAWFUL_BUT_NO_CANONICAL_SELECTOR` is therefore false (A's lawfulness is not
  established), and `B_REQUIRED` would require elevating this act's construction into
  authority — which the task forbids ("Do NOT create a new selector unless the existing
  authority already contains one").

```text
QUESTION_A_VERDICT = NOT_DETERMINABLE_FROM_CURRENT_AUTHORITY
```

**Per required determination 6: no deterministic canonical selector exists in current
controlling authority for the nested reference storage on this joint M/TT surface.
An Owner methodology decision is required before CORRECTION-1 can be accepted.**

---

## 6. QUESTION B — A-E023 SUPPORTCLASS UNDER DE-4

### 6.1 Controlling text

- **E2 C34 §6 DE-4:** "Default: `NON-DISCRIMINATING` or `NOT DETERMINABLE`. DE-4 cannot
  become behavioral authority merely because it resembles an Environment description."
- **E2 C34 §6 constitutive-rule exception:** "For the current authority corpus, **no
  known constitutive structural discriminator instance exists**" (version-bound to the
  questionnaires corpus); invocable only with a positively identified and independently
  verified exact current authority anchor, via the mandatory instance test.
- **E1 §A.8:** "No target uses the C34 §6 constitutive-rule exception (CONSTITUTIVE
  EXCEPTION = NOT AVAILABLE, C34 §6)."
- **E1 §E supportClass:** values `DIRECT_SUPPORT · DIRECT_CONTRADICTION ·
  SHARED_NON_UNIQUE · NON_DISCRIMINATING · NOT_DETERMINABLE`; "CASE-1 support classes,
  recorded per edge relative to the Tree target"; authority anchor "A; C34 §14".
- **E1 §E evidenceForm:** "DE-4 cannot establish an OP mechanism; it may establish a
  PRES object or FORMAL_ONLY" — the methodology's own localization of DE-4's Stage-2
  consequence (into `formalOperativeState` and the §F.3 FO-OP/PC-CUR gate failures).
- **E1 FW-3:** "no state implies another except as defined in §F.3/§F.5" (§F.3/F.5
  contain no evidenceForm→supportClass derivation; §F.3's only NON_DISCRIMINATING-forcing
  rule is the PR-* prohibition check, inapplicable here).
- **E1 H-8:** "supportClass is assigned relative to each consuming TT."
- **E2 C34 §14:** reuses the CASE-1 five classes; "Do not invent numeric edge weights."

### 6.2 Override search (determinative negative)

No field-specific override permitting DIRECT_SUPPORT under DE-4 exists in: E1 (§E, §F.3,
§H-8 — an assignment-scope rule, not an override; §A.8 — exception NOT AVAILABLE); E2
(§6 exception empty for the current corpus; §14 vocabulary only); E3/E4/E5 (no rule);
E13 assembly contract (componentSupply/supportClass out of scope); E14/E15 accepted
overlays (field inventories: `planCurrentState`; `evidenceForm` ×2;
`formalOperativeState`; both overlays' deep-diff verification lists explicitly name
`supportClass` among untouched field classes); E16 state rebase (accepted-controlling
state = the enumerated overlay fields only). `DIRECT_SUPPORT_LAWFUL_BY_EXISTING_OVERRIDE`
is eliminated.

### 6.3 Provenance of the current value (physical facts)

- The DE-4 + DIRECT_SUPPORT combination physically exists in the Owner-authorized
  five-RC dual rerun (2026-10-03): Lane A row (E17 line 34) and Lane B row (E18) both
  record `evidenceForm DE-4 / supportClass DIRECT_SUPPORT / FORMAL_ONLY / PLAN /
  PARTIAL / OPEN`. Dual-lane agreement is physical provenance under the pilot's
  agreement-measurement design — agreement is what the pilot measures, not a correctness
  authority; no adjudication of this supportClass value ever occurred (the five-RC
  reconciliation touched only characteristicity record 15; the accepted overlays
  verified supportClass untouched; census CORR1 explicitly left `supportClass` rerun
  outcomes open: "no replacement value may be assigned by a census").
- The accepted DE-4/FORMAL_ONLY/PLAN states arrived later and independently of that
  supportClass value (co-physical determination: physical DE-2/OPERATIVE were drift;
  controlling DE-4/FORMAL_ONLY per E15; PLAN per E14). The project's own determination
  discipline separates control-authority of a value from its methodological correctness.
- Contemporaneous coder practice in the same chain (E20, PRIOR AGENT CLAIM): for DE-4
  rows the Execution-1 coder derived `supportClass = NON_DISCRIMINATING`, citing
  "C34 §6 / §14 / §7.5 / H-8 … the default support class for DE-4 is NON_DISCRIMINATING
  … constitutive-rule exception is NOT AVAILABLE".

### 6.4 Analysis

Two readings of the C34 §6 default's reach survive the text: (i) **C34-global** — the
§6 default binds the recorded support class wherever evidenceForm = DE-4 (corroborated
by E20's derivation and by the vocabulary fit), under which DIRECT_SUPPORT is not lawful
without an override, and none exists; (ii) **Stage-2-local** — supportClass is a distinct
per-TT axis (H-8; FW-3 state independence), DE-4's Stage-2 ceiling manifests through
FORMAL_ONLY and the §F.3 gates, and the §6 default governs downstream discriminator
instantiation rather than this field, under which DIRECT_SUPPORT is simply unadjudicated
coder judgment. **Under both readings, DIRECT_SUPPORT is NOT PROVEN lawful.** Under
reading (i) it is affirmatively defaulted against; under reading (ii) its lawfulness has
never been established by any authority.

Replacement determinism: the §6 default itself offers **two** values
(NON-DISCRIMINATING or NOT DETERMINABLE) with no selector between them; Stage-2 contains
no supportClass-derivation rule (H-8 makes it a per-consumer-TT coder assignment); the
census refuses replacement assignment; the IV (E8) independently found "no unique
automatic replacement among the default classes". Assigning any replacement would be a
new analytical/methodological act, not a deterministic repair — and this act is forbidden
from re-coding.

```text
QUESTION_B_VERDICT = DIRECT_SUPPORT_NOT_PROVEN_AND_REPLACEMENT_NOT_DETERMINABLE
OWNER_DECISION_REQUIRED_B = YES
```

---

## 7. REPAIRABILITY

- Question A: without an Owner decision there is no canonical selector, so no
  deterministic nested-reference repair exists. (If the Owner adopts the level-split
  construction / representation B, the mechanical repair becomes deterministic: null the
  two nested fields in six Section-I entries and mirror in execution cells 9/56 — output
  invariance already independently established by E8.)
- Question B: no deterministic replacement exists; the choice among
  {NON_DISCRIMINATING, NOT_DETERMINABLE, a lawful DIRECT_SUPPORT rule} is normative.

```text
OWNER_DECISION_REQUIRED_A = YES
CAN_CORRECTION_1_BE_DETERMINISTICALLY_REPAIRED_WITHOUT_NEW_OWNER_METHOD_DECISION = NO
```

## 8. OWNER DECISION FRAME — REQUIRED FRAME (AGENTS.md §14A.3)

**DECISION A:** the canonical storage rule for nested
`componentSupply[].relationInstanceId` / `.organizationalObjectRef` on Section-I
surfaces where the M row declares no join and the consuming TT declares REL-WITNESS.

**WHY THIS REQUIRES THE OWNER:** authorities checked by path — E1 §F.4/J-R2/R3/R5/R7,
§F.4.1, §I, §Q; E3/E4; E5; E13; E14/E15; E2 — define both obligations (M-row
inapplicability; TT-composite binding) but contain no explicit level assignment for the
nested storage; the level-split construction that would select B is this act's inference.
Materially different admissible semantics (a failed-test signal versus inapplicability
signal on M-labelled storage) survive; this is normative, not epistemic.

**OPTIONS:**
- **A — confirm representation B** (nested null/null + NO_LAWFUL_LINKAGE as
  inapplicability; outer TT-context references unchanged) as the reading of existing
  J-R7/F.4 authority (or as a one-sentence clarifying rule).
- **B — confirm representation A** (non-null inherited nested references) as lawful for
  join-declaring-consumer surfaces, adding the explicit selector the authority lacks.

**RECOMMENDATION: A (representation B).** Why: it is the only form expressly supported
by the only rule that speaks to reference storage on no-join rows (J-R7's null mandate
with its inapplicability semantics); it preserves J-R7's deliberate
inapplicability-versus-failed-test distinction instead of erasing it at the nested
level; it matches the independent Lane B physical practice under the same rules (E18);
it harmonizes with census CORR1's TT-binding treatment of the outer fields rather than
contradicting it; it is output-invariant (E8); and it adds no new semantics — it
requires only confirming that J-R7's existing null instruction reaches the M-keyed
nested entries. **Consequence if A:** next act stays bounded to a deterministic CORR2
(nulling 12 nested leaves + 2 carrier mirrors) + fresh IV; contracts touched: none
(schema shape unchanged; §I keys already permit null — E18 proves the form). If B: the
authority gap must be closed by a new explicit selector rule (methodology text change),
and CORR1's current representation stands as its execution. **Reversibility:** both are
data-level reversible at 12 leaves; option B additionally fixes a methodological reading
that later generations would inherit.

**DECISION B:** the supportClass rule for DE-4 evidence in the Stage-2 per-TT field —
specifically whether A-E023's DIRECT_SUPPORT is ratified, or replaced (and by which of
the two §6 default values), or re-derived by an authorized analytical act under H-8.

**RECOMMENDATION:** do not ratify DIRECT_SUPPORT by silence. Either (i) adopt the C34
§6 default reading and select one default value for this edge (the record's
`edgeState PARTIAL / FORMAL_ONLY / PLAN / OPEN` profile gives no mechanical selector —
the choice between NON_DISCRIMINATING and NOT_DETERMINABLE is itself the Owner's or a
bounded authorized re-coding's to make), or (ii) authorize a bounded supportClass
re-derivation act under H-8 relative to TT-NTSTJ-RS. The dual-lane agreement is
provenance, not authority; ratifying it would be the first Owner endorsement of a
DE-4+DIRECT_SUPPORT combination that no authority text or adjudication has ever
established.

## 9. LIMITATIONS / NOT DETERMINABLE

- This act did not execute the Final Stage-2 Measurement Regression, any builder, any
  validator, or any A/B tooling; all byte-level observations are direct file reads.
- The Control Tree (v2.1, 2026-09-04, hash-verified by E8) predates the October Stage-2
  chain; the Owner's task pinning governs current authority assignments here.
- Whether J-R7's null instruction reaches nested fields, and whether the C34 §6 default
  binds the Stage-2 supportClass field, are the two scoping questions returned to the
  Owner; everything else in both questions was resolved from inspected text.
- Retrospective intent of rule drafters is not determinable and was not relied on.

## 10. ENVIRONMENT-MATH PRESERVATION GATE

Root Definitional/E9 unchanged (E2 read only; byte-identity to the methodology's pinned
dae81438… verified). Stage-2 measures inputs only. No Environment assignment, U-7,
OM-1, MD-2 Φ, D2-10, HEDC, RULE FREEZE, 905/18-side replay, Pair, ECS or friction act
was performed or implied by this determination. Both verdicts concern Stage-2
measurement-record semantics only and create no determination contract and no
Environment result.

## 11. STATUS BOUNDARY / STOPPING POINT

- Claude CORRECTION-1: **not accepted** (unchanged).
- Successor effective view `3737bd5d…165c5`: **not accepted, not controlling**.
- Predecessor `a1fcae68…4047`: **remains the controlling effective view**.
- No candidate, predecessor, methodology, overlay, or historical record was edited.
  No CORR2 was created. No Git mutation, commit, or push. Exactly the two artifacts of
  this act were written to
  `WORKBENCH/DOWNLOADS/STAGE2_MEASUREMENT_AUTHORITY_CLARIFICATION_1_2026-10-05/`.

**STOP AFTER AUTHORITY CLARIFICATION.**
