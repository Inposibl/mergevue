# STAGE2_FINAL_MEASUREMENT_REGRESSION_1_REPORT

FINAL_STAGE2_MEASUREMENT_REGRESSION = FAIL

Terminal: STAGE2_FINAL_MEASUREMENT_REGRESSION_1_FAIL. Executor-authored local QA evidence. Not independent audit, Owner acceptance or controlling regression closure.

Actor: Codex. Owner-assigned role: STAGE-2 MEASUREMENT REGRESSION EXECUTOR / VERIFICATION ENGINEER. Date: 2026-10-05, America/Asuncion.

The exact accepted input identities pass and the accepted correction targets are physically preserved. The measurement surface is not regression-clean: 19 deterministic SECTION_I mismatches, structural traceability failures and output-affecting carried ADV-2 remain. No input was repaired.

## Required summary

    EFFECTIVE_VIEW_IDENTITY = PASS
    METHODOLOGY_IDENTITY = PASS
    TOTAL_RECORDS = 116
    EXECUTION_CELL_RECORDS = 110
    SECTION_I_RECORDS = 6
    PHYSICAL_SCHEMA_CENSUS = FAIL
    EXECUTION_CELL_REGRESSION = FAIL
    SECTION_I_RECOMPUTATION = FAIL
    SECTION_I_MATCHES = 163
    SECTION_I_MISMATCHES = 19
    SECTION_I_NOT_DETERMINABLE = 100
    ACCEPTED_CORRECTIONS_PRESERVED = YES
    FB0025_REGRESSION_OUTPUT_INVARIANT = YES
    CENSUS_CORR2_ADV2_EFFECT = OUTPUT_AFFECTING
    CROSS_RECORD_CONSISTENCY = FAIL
    DISCRIMINATOR_TO_TREE_TARGET_BRIDGE = FAIL
    REGRESSION_REPLAY_COUNT = 2
    REGRESSION_DETERMINISTIC = YES
    NEGATIVE_CONTROLS_DETECT_CORRUPTION = YES
    UNEXPECTED_EFFECTIVE_DIFFS = 0
    HISTORICAL_PACKAGE_MUTATED = NO
    EFFECTIVE_VIEW_MUTATED = NO
    METHODOLOGY_MUTATED = NO
    GIT_MUTATED = YES
    ENVIRONMENT_MATH_PRESERVED = YES
    FINAL_STAGE2_MEASUREMENT_REGRESSION = FAIL
    STAGE2_MEASUREMENT_LAYER = NOT_CLEAN
    READY_FOR_POST_REGRESSION_SEMANTIC_METHOD_ACT = NO

## Role, scope and authority

Current explicit Owner authorization defines this executor role and the closed four-file write surface. AGENTS_C was read as contextual governance, not used to infer a Coder appointment. No subagent, network/third-party operation, Git command or independent IV was begun.

Physical root: /Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026). HEAD read from .git/HEAD and refs/heads/main: 2567223087d99b40bdfd174eed32566be7080e44 on main. Dirty/staged status was not inferred from filesystem snapshots.

Output directory: /Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)/WORKBENCH/DOWNLOADS/STAGE2_FINAL_MEASUREMENT_REGRESSION_1_2026-10-05. Existing parents were checked for symlinks and root containment; it did not exist before creation.

Only the exact effective inputs and current methodology are expected-result oracles. Previous reports locate historical findings and authority context; they cannot make this result PASS.

Effective view: a1fcae68939decd0a3c4a39c0a0bc48e8d285bd9cd7ce1928b0d025056244047; 104310 bytes; 116 records.

Methodology: cb08b51e1c2fbaec7765989a7a4e15db1788c53eb5fec43f2628ecb88c1d6c73; 344754 bytes. Assembly contract: 4e2ff3d00baa05dc82dc4f72318c413b0683cbe0d050ee026bb8b6ad7c6eee66.

The Owner designates the view as Owner-accepted/independently verified/controlling and the exact current methodology successor for this act. Candidate-era embedded headers do not override that current designation. Physical RC1 -> RC5 -> RC2 -> RC4 -> RC3 -> RC3.CORR1 -> PD3 -> PD3.CORR1 lineage identities were checked. Historical agent/IV reports do not create acceptance. Control Tree v2.1 and September-21 addendum hashes match their sidecars; their old dates do not establish the status of this later Owner-authorized act.

B1/H-2 selection, B2/G-5 competence separation, B3/C emitted D authority, B4/F.4 join applicability, B5/E-T temporal rules, B6/E-P implementation status, B7 relevance and B8/L-5 liveness-only coverage are preserved. RC1/RC5/RC2/RC4/RC3.CORR1/PD3 predicates remain separate. No final full-pilot coverage verdict is synthesized from this bounded aggregate snapshot.

Stage-2 TT-level F.3/F.5 sufficiency is used. Downstream MECHANISM_LANE_SUFFICIENCY_AUTHORITY / U-7 remains NOT_YET_ESTABLISHED and is not a regression failure predicate.

## Physical/schema and execution census

JSON valid 116/116; duplicate JSON keys 0; duplicate record IDs 0; duplicate cell semantic identities 0; duplicate SECTION_I edge IDs 0. 110 censusCellRef values resolve against the frozen 134-entry census union. Fact references resolve in the exact local frozen 30-fact pilot input. Registry inventory: 74 M / 13 D / 62 TT. No 905-fact semantic replay or outcome package was consumed.

Unknown outer fields 0; Environment/outcome/score fields 0; illegal relations 0; orphan negative/conflict references 0. All negative/conflict arrays are empty. Four emitted D bindings are unlawful despite valid D IDs; six expression-leaf occurrences refer to unknown M IDs; superseded provenance is still consumed by F0024 SECTION_I.

All six componentSupply members violate the M-keyed factIds/object/linkageEvidence{class,identifier} schema. Cells 9 and 56 carry that same defect. presentationLaneOnly is lawful under controlling I, despite omission from an older schema display group.

110 execution-cell results: 107 PASS / 3 FAIL (cells 9, 51, 56). Each cell has explicit identity, census, binding, vocabulary, schema/value and consumer checks in RESULTS. Checks apply to the field each sparse wrapper carries; absent wrapper fields are not invented as requirements. Lawful stored NOT_DETERMINABLE values are distinguished from a NOT_DETERMINABLE QA check.

## SECTION_I reconstruction

47 surfaces per edge, 282 comparisons: 163 MATCH / 19 MISMATCH / 100 NOT_DETERMINABLE. All are individually listed in RESULTS and FINDINGS. Carrier MATCH proves propagation, not a new evidence judgment. No ND is coerced to PASS.

Registry formulas, emitted D sets, sourceClass, provenance, recorded component complements, scope-bridge requirements and closed target-state logic were independently reconstructed. Accepted documentary assignments were not recoded.

| Edge | Stored result | Recomputed | Missing from recorded supply | Derived target state |
|---|---|---|---|---|
| A-EXEC1:F-B-0025:M-RES-ROLE-CONTROLLED-ACCESS:TT-STPSTJ-RS | OPEN | OPEN | ["c2", "c3"] | TARGET_NOT_ESTABLISHED_WITHIN_BOUND |
| A-EXEC1:F0024:M-RES-ROLE-CONTROLLED-ACCESS:TT-STPSTJ-RS | OPEN | OPEN | ["c2", "c3"] | TARGET_NOT_ESTABLISHED_WITHIN_BOUND |
| A-RERUN1-CORR1:F-E-0182:M-RECOGNISED-COMMAND-ORDER:TT-STPSTJ-ESS | OPEN | OPEN | ["c2", "c3"] | TARGET_NOT_ESTABLISHED_WITHIN_BOUND |
| A-RERUN1-CORR1:F-E-0182:M-RECOGNISED-COMMAND-ORDER:TT-STPSTJ-PW | OPEN | OPEN | ["c2", "c3"] | TARGET_NOT_ESTABLISHED_WITHIN_BOUND |
| A-E001 | TRUE | OPEN | ["c2"] | TARGET_NOT_ESTABLISHED_WITHIN_BOUND |
| A-E023 | TRUE | OPEN | ["c2", "c3", "c4"] | TARGET_NOT_ESTABLISHED_WITHIN_BOUND |

These are measurement target states only. Missing siblings remain OPEN, never FALSE. No Environment label, candidate, ranking or score is inferred. Component complements are diagnostic from recorded supplied IDs, not claims that a component is absent from reality. Missing component witnesses cannot be invented from prose.

### Every deterministic mismatch

| Edge | Field | Stored | Recomputed |
|---|---|---|---|
| A-EXEC1:F0024:M-RES-ROLE-CONTROLLED-ACCESS:TT-STPSTJ-RS | factualPackageIdentity | 17-key provenance; exact values in RESULTS | 17-key provenance; exact values in RESULTS |
| A-RERUN1-CORR1:F-E-0182:M-RECOGNISED-COMMAND-ORDER:TT-STPSTJ-ESS | discriminatorIds | ["D-01"] | ["D-04"] |
| A-RERUN1-CORR1:F-E-0182:M-RECOGNISED-COMMAND-ORDER:TT-STPSTJ-ESS | sufficiencyExpression | "ALL_OF(M-RECOGNISED-COMMAND-ORDER, M-DISCIPLINARY-ESCALATION, M-SUPERVISORY-DIRECT-AUDIT)" | "ALL_OF(M-EXTERNAL-ADAPTIVE-DEMAND, M-OUTWARD-TACTICAL-DISCRETION, M-RECOGNISED-COMMAND-ORDER, M-INSIDER-OUTSIDER-RULE-ASYMMETRY, M-ORDER-SUSTAINED-FLEXIBILITY)" |
| A-RERUN1-CORR1:F-E-0182:M-RECOGNISED-COMMAND-ORDER:TT-STPSTJ-PW | discriminatorIds | ["D-01"] | ["D-04"] |
| A-RERUN1-CORR1:F-E-0182:M-RECOGNISED-COMMAND-ORDER:TT-STPSTJ-PW | sufficiencyExpression | "ALL_OF(M-RECOGNISED-COMMAND-ORDER, M-FORMAL-PROCEDURAL-APPEAL, M-SANCTION-SYSTEM-AUDIT)" | "ALL_OF(M-RECOGNISED-COMMAND-ORDER, M-ACCESS-BY-LOYALTY-RELIABILITY, M-DELEGATION-HOW-VS-WHAT, M-ENFORCE-RESOURCE-INFORMATION-CONTROL)" |
| A-E001 | discriminatorIds | ["D-02"] | ["D-06"] |
| A-E001 | missingComponents | [] | ["c2"] |
| A-E001 | scopeBridgeState | "NOT_REQUIRED" | "UNRESOLVED_FAIL_CLOSED" |
| A-E001 | sourceClass | "PERIODICAL_PRINT_ARCHIVE" | "OUTSIDE_FROZEN_VOCABULARY" |
| A-E001 | edgeState | "SUPPORTED" | "PARTIAL" |
| A-E001 | sufficiencyExpression | "ALL_OF(M-ENFORCE-SANCTION, M-FORMAL-RULES)" | "ALL_OF(M-AUTH-TOPDOWN-EXPLICIT, M-ENFORCE-STRENGTH, M-ENFORCE-SANCTION, M-ENFORCE-RESOURCE-CONTROL)" |
| A-E001 | sufficiencyExpressionResult | "TRUE" | "OPEN" |
| A-E023 | discriminatorIds | ["D-06"] | ["D-07"] |
| A-E023 | missingComponents | [] | ["c2", "c3", "c4"] |
| A-E023 | scopeBridgeState | "NOT_REQUIRED" | "UNRESOLVED_FAIL_CLOSED" |
| A-E023 | sourceClass | "FORM_10K" | "OUTSIDE_FROZEN_VOCABULARY" |
| A-E023 | edgeState | "SUPPORTED" | "PARTIAL" |
| A-E023 | sufficiencyExpression | "ALL_OF(M-RES-CAPABILITY-ADVANTAGE, M-MARKET-POSITIONING)" | "ALL_OF(M-RES-CAPABILITY-ADVANTAGE, M-CAPABILITY-YIELDS-CONTROL)" |
| A-E023 | sufficiencyExpressionResult | "TRUE" | "OPEN" |

## Findings

### REG-001 — MAJOR — Corrected F0024 provenance is not propagated into its SECTION_I consumer

The corrected 17-key identity is physically present in cell 51. SECTION_I line 112 still consumes 139589 bytes, old SHA, 105 facts and package-level case_id, contrary to the accepted effective cell and frozen sidecar. All 13 untouched keys are preserved.

Effective cell 51 -> SECTION_I factualPackageIdentity -> H-1 / I provenance validity; a physical-consumption defect satisfies the Owner condition for reporting an assembly-boundary defect. No assembly repair performed.

### REG-002 — MAJOR — Four discriminator emissions violate the authoritative M-row binding

F-E-0182 both target copies emit D-01 instead of D-04; A-E001 emits D-02 instead of D-06; A-E023 emits D-06 instead of D-07.

Selected M -> C-1/C-2 authoritative D set -> emitted D -> lawful semantic bridge. No discriminator reclassification judgment is needed.

### REG-003 — MAJOR — Four sufficiency expressions retain superseded or unknown mechanism leaves

Both F-E-0182 formulas, A-E001 and A-E023 disagree with the exact controlling TT-row expressions. Six leaf occurrences reference mechanisms outside the 74-M registry. A-E001 and A-E023 store TRUE where F.3/F.5 necessarily give OPEN.

TT registry mechExpr -> closed Boolean leaf resolution -> sufficiencyExpressionResult -> measurement target state. Missing sibling leaves stay OPEN, never silently TRUE.

### REG-004 — MAJOR — Two SUPPORTED rows have incomplete recorded component coverage

A-E001 supplies only recorded c1 for a two-component M but stores missingComponents=[] and SUPPORTED; A-E023 supplies only c1 for c1..c4 and likewise stores []/SUPPORTED. The diagnostic complements are [c2] and [c2,c3,c4].

Accepted recorded component IDs -> H-3 / H-7 -> PARTIAL rather than all-component SUPPORTED -> F.3 leaf gate. The facts are not recoded; supply that is not recorded cannot be invented.

### REG-005 — MAJOR — Two upward-scope claims incorrectly declare no bridge required

A-E001 observed unit -> claimed enterprise and A-E023 observed program -> claimed enterprise both store NOT_REQUIRED with no scopeBridgeFactIds. Accepted scope rules require a bridge; the recorded surface cannot establish one.

Observed/claimed scope + empty recorded bridge -> C34 section 10 / SC-CLAIM -> UNRESOLVED_FAIL_CLOSED -> no true leaf at enterprise scope.

### REG-006 — MAJOR — Two sourceClass values diverge from the frozen mechanical binding

A-E001 stores PERIODICAL_PRINT_ARCHIVE and A-E023 stores FORM_10K. The corresponding exact PI-7 records both bind OUTSIDE_FROZEN_VOCABULARY; documentary genre does not substitute for that value.

Frozen PI-7 sectionIFill -> I sourceClass -> class-bearing measurement/provenance surface; srcDiv is not applicable to these targets. A bound measurement field still cannot be silently replaced by documentaryIdentity.

### REG-007 — MAJOR — All six componentSupply entries violate the controlling nested traceability shape

Entries contain componentId/status/linkageEvidence string/entailmentBasis rather than the required M-keyed factIds and linkageEvidence{class,identifier} shape. Cells 9 and 56 carry the same defect. Outer record fields are lawful.

I typed component provenance -> F.4 / F.4.1 linkage executability and H-5 supply validation. The defect is structural; it does not authorize reparsing prose as missing component evidence.

### REG-008 — MAJOR — A-E023 still claims operative support after the accepted DE-4 / FORMAL_ONLY / PLAN correction

The corrected values are preserved, but their immutable neighbors still say SUPPORTED, DIRECT_SUPPORT, no missing components and TRUE. E explicitly prohibits DE-4 establishing an OP mechanism. The leaf also fails CURRENT and temporal gates.

Accepted corrections -> E / RC4 + H-7 -> blocked OP support -> F.3 OPEN. This is the output-affecting part of carried Census CORR2 ADV-2, not a recoding of supportClass by preference.

### REG-009 — ADVISORY — Bounded non-determinable assignments are retained explicitly

100 field comparisons cannot be independently re-assigned mechanically from the sparse execution-cell view. These are not PASS and are not new coder judgments.

Preserved analytical controls are consumed as accepted inputs only. Every measured target is already necessarily OPEN through known failed gates / missing siblings. No unresolved qualifier is used to manufacture a true leaf.

### REG-010 — ADVISORY — Observed Git metadata changed outside the executor command stream

{
  "beforeGitDigest": {
    "fileCount": 2933,
    "sha256": "11cf51073c43bd1d260d1c76fb2b6136327b680e5205f594713b6167b670405a"
  },
  "observedGitDigest": {
    "fileCount": 2933,
    "sha256": "54532cf374e17d070e3e331545daccae3a96e79fe42992a79a0eaa18b4668b93"
  },
  "recentFiles": [
    {
      "path": "/Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)/.git/FETCH_HEAD",
      "bytes": 1796,
      "modifiedUTC": "2026-10-05T14:08:05.122468+00:00",
      "sha256": "f00c273944889421e01b63a19d93a6114d584c3b494cf97bb4c40636b91226dc"
    },
    {
      "path": "/Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)/.git/refs/remotes/origin/HEAD",
      "bytes": 30,
      "modifiedUTC": "2026-10-05T14:08:05.839490+00:00",
      "sha256": "2bb6a24aa0fc6c484100f5d51a29bbad841cd2c755f5d93faa204e5dbb4eb2b4"
    },
    {
      "path": "/Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)/.git/logs/refs/remotes/origin/HEAD",
      "bytes": 295602,
      "modifiedUTC": "2026-10-05T14:08:05.842301+00:00",
      "sha256": "6fb11690945c28030e900b4a28e6347ad6a3ae752a2d7f61ccbe70863f9b6dc0"
    }
  ]
}

FETCH_HEAD and origin/HEAD reflog/ref updates are consistent with a background fetch (inference). No executor Git command was issued. HEAD, regression inputs and root/E9 content are unchanged.

## Accepted corrections and downstream consumption

A-E023 PLAN / DE-4 / FORMAL_ONLY and A-E001 DE-1 / CURRENT remain present. F0024 cell 51 equals the corrected complete 17-key object: 61728 bytes; SHA 88b20920149b3fcde03e4e060cf4361e9494fe0137540bbc654c526337fd5f10; 50 facts; record-level case_id. Other 13 keys unchanged. ACCEPTED_CORRECTIONS_PRESERVED=YES is scoped to those exact correction targets.

F0024 SECTION_I line 112 still carries the old four values. The regression reports this concrete consumption defect; it does not reopen assembly because old source artifacts exist. Independent base comparison reproduces exactly eight allowed leaf differences and zero unexpected changes. Exact composition preservation is not proof of downstream consistency.

## F-B-0025 sensitivity

Governance disagreement remains UNADJUDICATED. Physical Lane-A is COMPETENT; scenario B uses COMPETENT_SELF_DESCRIPTION_UNCORROBORATED. No winner selected.

Only cell 35 and its SECTION_I qualifier were varied in memory. Both scenarios give selected M, recorded c1, missing [c2,c3], PARTIAL, leaf OPEN, exact five-leaf ALL_OF OPEN, TARGET_NOT_ESTABLISHED_WITHIN_BOUND, no negative/conflict evidence, unresolved target join and srcDiv NOT_APPLICABLE.

A passes the explicit sourceQualityState=COMPETENT conjunct; B fails it. Other conjuncts independently block both: PARTIAL edge, missing components, unresolved temporal/characteristicity, FORMAL_ONLY and non-CURRENT. Formal c1 remains accepted formal evidence under G-2/G-5; no full OP support follows. Assignment/carriage E/G/H/I, C competence meanings, H-7, F.5 negative/conflict logic and F.3 leaf/Boolean/target/srcDiv consumers were traced. The intentionally varied qualifier carrier is not itself claimed invariant.

FB0025_REGRESSION_OUTPUT_INVARIANT=YES. Complete scenario states/predicate truth tables and consumer graph are in RESULTS. This independently corroborates prior mootness for this fixed view without adjudicating quality.

## Census CORR2 ADV-2

Lane-B stale entailmentBasis is not an accepted Lane-A effective input. Current F-E-0182 decisionRef and entailment prose cannot supply missing components or upgrade formal evidence. Their in-memory removal leaves all derived measurement states unchanged. F.4 J-R7 voluntary metadata cannot impose an undeclared M-row join; declared composite TT joins remain binding and unestablished.

DE-4 + DIRECT_SUPPORT is output-neutral for the two PARTIAL role-access rows. A-E023 additionally stores SUPPORTED, no missing components and TRUE despite accepted FORMAL_ONLY / PLAN, unresolved time and only recorded c1. That current causal path is OUTPUT_AFFECTING under E/H-7/F.3. supportClass has no upgrade rule and was not re-assigned by preference.

CENSUS_CORR2_ADV2_EFFECT=OUTPUT_AFFECTING. Its historical census-scoped advisory classification is not a final-regression oracle.

## Prior MINOR relevance

| Finding | Effect | Current causal path |
|---|---|---|
| P-D3 affected-execution comparison IV1 MINOR | OUTPUT_NEUTRAL | Comparison display/count labels -> historical comparison artifact only. Current regression reconstructs values and target rules without reading those labels as predicates. |
| F-M-0205 determination IV1 MINOR | OUTPUT_NEUTRAL | History-description prose -> no effective assignment consumer. PLAN preservation is checked on physical A-E023 under the accepted overlay; superseded Lane-B history is not an oracle. |
| Co-physical determination CORR2 IV MINOR | OUTPUT_NEUTRAL | Status-token scan accounting -> no measurement input. Regression does not consume manifest token totals. |
| F0024 IV1 MINOR | OUTPUT_NEUTRAL | Negative-proof explanation -> no field assignment. Source map + frozen sidecar mechanically select record-level case_id. The new SECTION_I propagation defect is separate from this old explanatory MINOR. |
| Effective-view assembly CORR1 IV1 MINOR | OUTPUT_NEUTRAL | Assembly explanatory prose -> no measurement predicate. Physical COMPETENT is used in scenario A; governance UNADJUDICATED remains separate. Methodology E does not admit UNADJUDICATED as a sourceQualityState. |

Each old issue was located in the original IV report and traced against current input consumers. They remain output-neutral. The newly found F0024 consumer defect and A-E023 support defect are separate physical findings, not upgrades of old prose MINORs.

## Determinism, negative controls and immutability

Two separate fresh Python processes re-read/re-parsed physical view, methodology and frozen support authorities. Full structures compare equal. Canonical full-structure SHA-256 in both: 58c2080b9d038ce91330fa8af7cf30ebb9d6b1920b9dc238a62e2904ec6b8e37. RESULTS embeds the complete read-only Python harness/reproduction procedure; no fifth helper file is needed.

Four fresh in-memory controls: revert accepted A-E023 PLAN to historical CURRENT; invalid treeTargetId; referenced fact absent from the frozen inventory; SECTION_I missingComponents inconsistent with cells. All detected the expected NEW specific diagnostic. Returning FAIL on an already failing baseline alone was not counted.

Before/after content snapshots cover 2933 .git files, 203 historical Stage-2 files, 17 v1.7 files and 18 E9 files. Historical Stage-2, methodology, effective view and root/E9 content snapshots are unchanged. Material consumed support files are individually hash-bound in MANIFEST. No input or memory file was modified by the executor.

GIT_MUTATED=YES reports observed physical state, not attribution. The aggregate .git content digest changed; recently modified FETCH_HEAD and origin/HEAD ref/reflog are consistent with a background fetch (inference). No Git command was run by this executor; HEAD is unchanged. The first output attempt stopped at its pre-write snapshot assertion and created no files. This external-state discrepancy is disclosed in REG-010 and RESULTS. It was not reset or repaired. Global repository/Git immutability is not falsely claimed.

Frozen provenance includes historical sibling-path locators; their contents were not newly opened. Membership checks use the exact frozen local pilot input/sidecar/source map. This is not a new factual certification or full-corpus audit.

## Author self-check, deviations and limits

Project quality gate was applied as bounded author self-check: correct current Owner role; four-file scope; independent methodology oracle; explicit FAIL/ND; new-diagnostic negative controls; no production or IV claim. No durable skill/governance change or additional evidence layer was created.

RESULTS lists exploratory deviations: a truncated inventory replaced with bounded snapshot digests, a nonexistent assumed glob resolved through the complete current successor, and a development-only presentationLaneOnly schema omission fixed before the final replay pair. No failed probe was counted as a passing final replay.

100 ND field comparisons cannot be independently re-assigned mechanically from this sparse view; every output-relevant instance is explicit. Known failed gates and missing siblings already force OPEN. These bounded unknowns cannot turn the concrete MAJOR failures into a PASS; no undocumented threshold or downstream U-7 gap caused the FAIL.

## Four-file package and terminal boundary

- STAGE2_FINAL_MEASUREMENT_REGRESSION_1_REPORT.md
- STAGE2_FINAL_MEASUREMENT_REGRESSION_1_RESULTS.json
- STAGE2_FINAL_MEASUREMENT_REGRESSION_1_FINDINGS.json
- STAGE2_FINAL_MEASUREMENT_REGRESSION_1_MANIFEST.json

ownerAccepted=false; independentlyVerified=false; controllingRegressionClosure=false. Planned fresh non-author verifier: Claude Opus 5.5 under separate Owner authorization. No independent verification is performed here.

STAGE2_FINAL_MEASUREMENT_REGRESSION_1_FAIL. STOP after this package. No IV, OM-1/U-7, MD-2/D2-10, HEDC authoring, rule freeze, 18-side replay, Pair/ECS or friction/resource-interaction act is begun.
