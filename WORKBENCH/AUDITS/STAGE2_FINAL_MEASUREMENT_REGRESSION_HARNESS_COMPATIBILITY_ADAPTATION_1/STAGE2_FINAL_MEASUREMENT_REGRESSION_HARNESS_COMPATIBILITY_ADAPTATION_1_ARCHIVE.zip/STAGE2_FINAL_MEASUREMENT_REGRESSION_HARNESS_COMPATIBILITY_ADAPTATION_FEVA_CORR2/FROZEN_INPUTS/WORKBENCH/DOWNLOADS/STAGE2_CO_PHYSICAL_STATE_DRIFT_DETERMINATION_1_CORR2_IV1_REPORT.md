# STAGE2_CO_PHYSICAL_STATE_DRIFT_DETERMINATION_1_CORR2_IV1_REPORT

**VERDICT = PASS · BLOCKING = 0 · MAJOR = 0 · MINOR = 1**

Actor: Codex. Role: Owner-appointed AUDITOR, specializing in independent state integrity / provenance. Mode: read-only independent verification; only the three requested IV outputs are authored. Date: 2026-10-04, America/Asuncion.

All three inherited UNAUTHORIZED_PHYSICAL_DRIFT determinations are independently supported. CORR2 corrects the residual live A18 status defect and preserves both predecessor packages and the accepted single-field plan-current firewall. One non-blocking MINOR concerns implicit manifest scan accounting. No finding is repaired.

## 1. Authority, independence, baseline and claim scope

Current direct Owner instruction: /Users/entp_psyche/.codex/attachments/7dfd2cef-3e77-46bd-a9c4-1d54865b6f86/Pasted text.txt. It appoints Codex to this audit and identifies Z-Ai as author of DETERMINATION-1/CORR1/CORR2. This auditor did not author those candidates or their controlling determinations. Adjacent historical Codex IV packages are evidence inputs; their labels alone do not establish this act's results.

Read AGENTS.md, AGENTS_A.md, MERGEVUE_CAUSALITY_PROOF_AND_AGENT_CONTROL.md and skills/mergevue-agent-quality-gate/SKILL.md. The current explicit Owner assignment specializes the AUDITOR mandate and authorizes exactly three artifact writes. Quality hard-fail and independence checks are applied; no retrospective or governance change is authored.

Physical root: /Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026). Branch: main. HEAD: 2567223087d99b40bdfd174eed32566be7080e44. Tracked dirty files: 0. Output parent resolves inside the authorized root and is not a symlink. The sibling workbench carrier paths are read-only dependencies, never write destinations.

Control Tree v2.1 and its 2026-09-21 addendum were found, read for relevant status/preservation rules, hashed against sidecars and compared to HEAD blobs. Latest binding commits inspected: 7792c5e (2026-09-04) and 18daf4c (2026-09-21). No later full Control Tree was found. Those artifacts establish status separation, not October act acceptance. Current direct Owner task §§8,10,12 expressly reaffirms/adopts the F-M-0205 correction as independently verified, Owner-accepted and controlling. This is the acceptance basis; workbench placement or an agent PASS is not used as acceptance.

Physical hashes, values and inventories below are SOURCE/ARTIFACT FACTS; current authorization/acceptance status is OWNER FACT. Prior reports are AGENT CLAIMS until corroborated. Drift classification and common failure explanation are INFERENCES from actual carriers and bounded authorization. Exact internal construction mechanism is NOT DETERMINABLE. No production integration or new methodological determination is claimed.

## 2. Gate A — package identities and successor integrity

All nine SHA-256/byte identities were independently recomputed. CORR2 matches the Owner pins; JSON parses; report/ledger member bindings match in all three manifests. CORR2 predecessor identity bindings match the physical CORR1 and grandparent packages. Net physical immutability is established; transient edits restored before available snapshots cannot be excluded by hashes.

| Physical file in WORKBENCH/DOWNLOADS | Bytes | Recomputed SHA-256 |
|---|---:|---|
| STAGE2_CO_PHYSICAL_STATE_DRIFT_DETERMINATION_1_REPORT.md | 24640 | 346966241ee88315bf738b2b17d1becc9840a7b545c5ffc4d819c3af511d93a6 |
| STAGE2_CO_PHYSICAL_STATE_DRIFT_DETERMINATION_1_LEDGER.json | 25664 | 1108cc92e3a69e7f667b314e9916651b7f97cb77560c48da07fb1f79ba1aaa39 |
| STAGE2_CO_PHYSICAL_STATE_DRIFT_DETERMINATION_1_MANIFEST.json | 11502 | dc0628ef59f93564bf56ac2695ca820ce0d20dd9829ded8f137aa6f640d71ed3 |
| STAGE2_CO_PHYSICAL_STATE_DRIFT_DETERMINATION_1_CORR1_REPORT.md | 33900 | b29bbf5e5a9ee0569d19b913a90b9bf235330e3d4e7adb1fc3e7530b86d6ff77 |
| STAGE2_CO_PHYSICAL_STATE_DRIFT_DETERMINATION_1_CORR1_LEDGER.json | 30056 | 43770fefec49f8241ce7bf95fbd1f8f39174a360f66dd486093c3db9e69320f8 |
| STAGE2_CO_PHYSICAL_STATE_DRIFT_DETERMINATION_1_CORR1_MANIFEST.json | 16202 | 7ccee8e3c9a0c82bb522ab6aa06e0fb68e214766de91f72bc73cb4bddff7ef24 |
| STAGE2_CO_PHYSICAL_STATE_DRIFT_DETERMINATION_1_CORR2_REPORT.md | 9671 | 9b2343b03eb73ec09415d0f6b30b66eb0cd57af79dfb96c2f610ac4c4e451cd1 |
| STAGE2_CO_PHYSICAL_STATE_DRIFT_DETERMINATION_1_CORR2_LEDGER.json | 32328 | c36667c4dedb65454c9e8992c1d09507f4d7dc29f6f4fd100c11efb6c2b77b2e |
| STAGE2_CO_PHYSICAL_STATE_DRIFT_DETERMINATION_1_CORR2_MANIFEST.json | 17952 | fd035b4a5adfd23499995bae2bbe2d652a2ece0242505d04bb54ef8b4356cb16 |

PACKAGE_IDENTITY = PASS. PREDECESSOR_IMMUTABILITY = PASS.

CORR2 ledger adds only corr2StatusContextCorrection and corr2TerminalState; all pre-existing CORR1 keys are deeply identical. CORR1 preserves the original determination keys except the accepted status-context update in preservedContext.F-M-0205_planCurrentState, plus its two new CORR1 keys. summaryDetermination, three chronological ledgers, generation matrix, authorization proof and common-root-cause content remain identical.

## 3. Gates B–D — control states, complete authorization and physical drift

| Surface | Row / fact | Field | G1 control | Execution-1 physical | Field-local authorization | Controlling value |
|---|---|---|---|---|---|---|
| 1 | A-E023 / F-M-0205 | evidenceForm | DE-4 | DE-2 | NONE | DE-4 |
| 2 | A-E023 / F-M-0205 | formalOperativeState | FORMAL_ONLY | OPERATIVE | NONE | FORMAL_ONLY |
| 3 | A-E001 / C-B04 | evidenceForm | DE-1 | DE-3 | NONE | DE-1 |

Each surface is UNAUTHORIZED_PHYSICAL_DRIFT. Each PRE_EXECUTION_CONTROL_STATE = PASS; AUTHORIZED_CELL_FOUND = NO; DRIFT_CONFIRMED = YES.

| Row | Generation | Source ref:line | evidenceForm | formalOperativeState | planCurrentState |
|---|---|---|---|---|---|
| A-E023 | G0_SUPERSEDED | A19:23 | DE-1 | OPERATIVE | PLAN |
| A-E023 | G_EFF_SUPERSEDED | A20:23 | DE-1 | OPERATIVE | PLAN |
| A-E023 | G1_CONTROLLING | A1:34 | DE-4 | FORMAL_ONLY | PLAN |
| A-E023 | G2_EXECUTION1 | A8:116 | DE-2 | OPERATIVE | CURRENT |
| A-E001 | G0_SUPERSEDED | A19:1 | DE-3 | FORMAL_PLUS_OPERATIVE | CURRENT |
| A-E001 | G_EFF_SUPERSEDED | A20:1 | DE-3 | FORMAL_PLUS_OPERATIVE | CURRENT |
| A-E001 | G1_CONTROLLING | A1:31 | DE-1 | FORMAL_PLUS_OPERATIVE | CURRENT |
| A-E001 | G2_EXECUTION1 | A8:115 | DE-3 | FORMAL_PLUS_OPERATIVE | CURRENT |

G0/G-eff are superseded. G1 Lane-A is the controlling carrier cited by CC-127/128/133/134 coder provenance. A1:34 establishes A-E023 DE-4 and FORMAL_ONLY. A1:31 establishes A-E001 DE-1. Five-RC AB stateFieldComparison[4] confirms F-M-0205 FORMAL_ONLY/PLAN agreement; [0] confirms C-B04 CURRENT/FORMAL_PLUS_OPERATIVE agreement.

**evidenceForm is not an AB-compared state field.** Lane B C-B04 A2:5 carries DE-3. No A/B agreement on DE-1 is claimed, and B's DE-3 is not field-local authorization to replace Lane A's DE-1. The controlling carrier is resolved at lane/row identity, not by silently taking a different coder's neighbor field.

Complete census enumeration: parent 112 + CORR1 18 + CORR2 4 = 134 distinct census records. Four UNAFFECTED records are excluded from the 130 counted execution cells. Missing-row A1 grain yields 94 cells on other facts, not an unrestricted whole-row edit permission for these A3 subjects. All 17 reconciliation records and all 110 Lane-A execution-cell records were inspected.

Complete authorized target inventories:

- F-M-0205: CC-128 characteristicityState → EPISODE_ONLY; CC-134 characteristicityFactIds → ["F-M-0205"].
- C-B04: CC-127 characteristicityState → CHARACTERISTIC; CC-133 characteristicityFactIds → ["C-B04"].

Exact factId/field enumeration finds no target evidenceForm or formalOperativeState authorization in parent census, CORR1, CORR2, reconciliation or Execution-1 Lane-A cell records. Reconciliation records 12/15 concern characteristicityState only; 13/14 concern F-E-0182 formalOperativeState only. EvidenceForm CC-113..116 belongs to F-E-0182; CC-048/091 belongs to other facts and is EXISTING_AND_LAWFUL. FormalOperativeState CC-005/006/013/014 belongs to F-E-0182; CC-022/025 is EXISTING_AND_LAWFUL on other facts.

Lane-A 110-cell composition is 94 A1 + 10 A2 + 6 A3. Target A3 cells at A8:107–110 and successor characteristicity values at A8:115/116 agree exactly with the authorized four cells. Those same complete successor rows carry the three non-authorized changes above.

## 4. Gate E — later adoption sweep

A12 has 114 compared field pairs. C-B04 and F-M-0205 each have characteristicityState and characteristicityFactIds pairs only; none of the three drift fields is compared. DE-2 and DE-3 occur zero times. Exact convergence on authorized cells does not adopt an omitted neighbor.

P-D3 CORR1 candidate A13 contains neither target fact/row identity. A14 §5 records the F-M-0205 plan-current discrepancy, confirms CC-128/134 only and adds no affected key; §4 preserves evidenceForm rules byte-identically. A15/A16 contain 4/6 records respectively and zero target fact/row mentions. The protected later P-D3 affected-execution AB artifact likewise contains no adoption of these three target fields.

A17/A17b plan-current determination records the three co-physical observations without adjudication. A18/A18b contains exactly one operative correctionRecord: A-E023 planCurrentState CURRENT → PLAN; scopeBoundary.coPhysicalDriftSurfacesDeliberatelyExcluded explicitly lists all three surfaces as separate unresolved debt, not adjudicated. Correction IV1 A21a/b/c is physically matched, PASS 0/0/0, CO_PHYSICAL_DRIFT_FIREWALL PASS, and records all three fields unchanged.

Current direct Owner task §§8,10,12 expressly establishes/reaffirms that prior single-field correction as Owner-accepted and controlling, with effective PLAN and historical CURRENT, while excluding these three fields. No separate acceptance event is invented from a report. No later accepted act in the inspected chain adopts the three physical drift values. For all surfaces: POST_ACT_ADOPTION_FOUND = NO. This conclusion is bounded to retrieved evidence and current Owner authority, not unavailable private communications.

## 5. Gate F — common root cause, with exact precision limit

COMMON_ROOT_CAUSE = SUPPORTED as a **physical construction-failure inference**. Both rows are Lane-A A3 successor carriers; their authorized characteristicity cells are correct, but non-authorized state neighbors diverge. A-E023 OPERATIVE and A-E001 DE-3 match superseded Lane-A G0/G-eff. A-E023 DE-2 matches no inspected prior Lane-A generation. The separately closed plan-current drift is physically co-located on A8:116 and is preservation context only.

A9 binds six input artifacts and no Section-I row carrier. That proves missing direct carrier binding, not that the author never read a particular file. The 114-pair downstream comparison omits these non-cell neighbors. These observations support a common failure to preserve controlling neighbor values during successor-row construction.

**Exact internal copying/re-derivation/transcription process, exact carrier and internal event count are not established.** No construction log is bound or located in the inspected package. The candidate's “whole rows from an unbound carrier” wording is treated as explanatory inference, not direct proof of an algorithm. Each surface retains its own independent determination.

## 6. Gates G–H — status correction and literal scan accounting

CORR1 manifest inputsVerified[A18].roleInChain physically contains “CORRECTION-1 overlay (READY_FOR_IV): both surfaces marked EXCLUDED — preservation context”, while report C-5 claims the role text was corrected. CORR2's corresponding live A18 field now carries IV1 PASS 0/0/0, Owner-accepted/controlling Stage-2 effective analytical status, the three-field exclusion and historical-row preservation.

RESIDUAL_LIVE_STALE_STATUS_CORRECTED = YES. FM0205_CORRECTION1_STATUS = OWNER_ACCEPTED_AND_CONTROLLING. Effective planCurrentState = PLAN; historical physical row = CURRENT.

Independent case-sensitive literal scan uses one (physical line, token) incidence. For these files that count equals literal occurrence count; it differs from matched-line count:

| Artifact | Line-token hits | Distinct matched lines | Literal occurrences |
|---|---:|---:|---:|
| REPORT | 32 | 19 | 32 |
| LEDGER | 12 | 7 | 12 |
| MANIFEST | 9 | 9 | 9 |

Report+ledger = **44**, reproduced exactly, including class counts A historical quote/scan vocabulary 32; B F0024 parked 6; C CORR2 current terminal 4; predecessor CORR1 terminal 2.

Physical manifest = **9**: two historical before/defect quotations, one F0024 parked status, one current CORR2 terminal, five scan-vocabulary entries. Excluding only liveStatusScan.tokens reproduces the candidate's **4** and its A=2/B=1/C=1 classes. The exclusion is not explicit in its full-text scope description or manifestSelfHitCount. **IV1-MIN-01 — MINOR** records this descriptive scope imprecision. All nine hits are lawful; no live stale reference remains.

SCAN_ACCOUNTING = MINOR_IMPRECISION. LIVE_STALE_FM0205_STATUS_REFERENCES_REMAINING = 0.

Three current chronological-ledger entries say “determination complete, awaiting Owner review”. They are lawful current determination statuses and have zero literal “awaiting acceptance” matches. Their explanatory inclusion in CORR2 report §3 is consistent transparency bookkeeping and is **not a finding**. No Owner acceptance of the present determination is inferred. FINDINGS.json supplies every one of the 53 physical line-token hits with its line and classification.

## 7. Gates I–K and protected boundaries

F-M-0205 plan-current: effective PLAN is CLOSED by separately independently verified and current Owner-reaffirmed accepted correction. CORR2 does not reopen, duplicate, fold or materialise it. Historical A8:116 remains CURRENT. FM0205_PLAN_CURRENT_PRESERVED = YES.

A-E001: G1 A1:31 and G2 A8:115 both carry CURRENT; Five-RC AB [0] agrees CURRENT across lanes and no reconciliation changes it. This lawful neighbor remains outside the future correction. AE001_PLAN_CURRENT_PRESERVED = YES.

Future surface: exactly A-E023 evidenceForm DE-2 → DE-4; A-E023 formalOperativeState OPERATIVE → FORMAL_ONLY; A-E001 evidenceForm DE-3 → DE-1. CORR2 manifest and inherited closed-scoping ledger preserve precisely these three items. They are prospective restoration descriptions, not operative correction records. FUTURE_THREE_FIELD_SURFACE = PASS.

F0024 remains PARKED_READY_FOR_IV. Its correctness is not audited, accepted or materialised; only existing protected inventory hashes are checked. F0024_TOUCHED = NO. F-B-0025 sourceQualityState is not adjudicated; complete census inspection for authorization does not decide that unrelated field. FB0025_TOUCHED = NO.

Root Definitional v1.7, A1–A4, R1–R4, T1 nine-Environment geometry, nine resource formulas, Owner-accepted E9 semantic authority, Historical Environment Determination logic and Pair/ECS/friction mathematics remain unchanged in this audited preservation surface. All 175 previously protected evidence files match their bound hashes; all 474 tracked files and the 1124 pre-existing visible files match the preservation baseline. Candidate changes are status context/prospective descriptions only. No Environment assignment, classifier, outcome use or Pair/ECS/friction computation occurs. ENVIRONMENT_MATH_PRESERVED = YES. This is a no-change check, not fresh theoretical verification or final regression.

## 8. Findings, performed validation and limitations

Only finding: IV1-MIN-01, MINOR, implicit exclusion of five manifest scan-vocabulary entries. No repair. No blocking/major finding changes any controlling value, authorization absence, drift classification, identity, accepted firewall or future surface.

Read-only/in-memory validation: SHA-256/bytes; JSON/JSONL parse; all member/predecessor bindings; deep ledger preservation; four-generation target-row comparison; complete exact-key authorization census, reconciliation and execution inventory; 114-pair adoption sweep; later correction exclusions and IV evidence; literal scan/classification; tracked/pre-existing/protected-source aggregates. No build/test/validator, final regression, METHOD/RULE FREEZE, analytical rerun, 905-fact execution, Git mutation or memory write.

Quality hard-fail scan found no independence breach, source-write crossover, source substitution, validator-as-oracle, method choice or promotion of PASS to Owner acceptance. Production forced-failure and bypass tests do not apply to this documentary audit and are not claimed. No runtime overlay consumer, deployment or production authority is certified. Complete transient author execution history and exact construction algorithm remain unverified.

No Owner decision is required to complete this IV. This PASS is not Owner acceptance, next-act authorization, materialisation or Git closure. Stop after the three-file IV package.

## 9. Required summary

```text
VERDICT = PASS
BLOCKING = 0
MAJOR = 0
MINOR = 1
PACKAGE_IDENTITY = PASS
PREDECESSOR_IMMUTABILITY = PASS
SURFACE_1_CONTROL_STATE = PASS
SURFACE_1_PRE_EXECUTION_CONTROL_STATE = PASS
SURFACE_1_AUTHORIZED_CELL_FOUND = NO
SURFACE_1_DRIFT_CONFIRMED = YES
SURFACE_1_POST_ACT_ADOPTION_FOUND = NO
SURFACE_1_CONTROLLING_VALUE = DE-4
SURFACE_1_DETERMINATION = UNAUTHORIZED_PHYSICAL_DRIFT
SURFACE_2_CONTROL_STATE = PASS
SURFACE_2_PRE_EXECUTION_CONTROL_STATE = PASS
SURFACE_2_AUTHORIZED_CELL_FOUND = NO
SURFACE_2_DRIFT_CONFIRMED = YES
SURFACE_2_POST_ACT_ADOPTION_FOUND = NO
SURFACE_2_CONTROLLING_VALUE = FORMAL_ONLY
SURFACE_2_DETERMINATION = UNAUTHORIZED_PHYSICAL_DRIFT
SURFACE_3_CONTROL_STATE = PASS
SURFACE_3_PRE_EXECUTION_CONTROL_STATE = PASS
SURFACE_3_AUTHORIZED_CELL_FOUND = NO
SURFACE_3_DRIFT_CONFIRMED = YES
SURFACE_3_POST_ACT_ADOPTION_FOUND = NO
SURFACE_3_CONTROLLING_VALUE = DE-1
SURFACE_3_DETERMINATION = UNAUTHORIZED_PHYSICAL_DRIFT
COMMON_ROOT_CAUSE = SUPPORTED
RESIDUAL_LIVE_STALE_STATUS_CORRECTED = YES
FM0205_CORRECTION1_STATUS = OWNER_ACCEPTED_AND_CONTROLLING
LIVE_STALE_FM0205_STATUS_REFERENCES_REMAINING = 0
SCAN_ACCOUNTING = MINOR_IMPRECISION
FM0205_PLAN_CURRENT_PRESERVED = YES
AE001_PLAN_CURRENT_PRESERVED = YES
FUTURE_THREE_FIELD_SURFACE = PASS
F0024_TOUCHED = NO
FB0025_TOUCHED = NO
ENVIRONMENT_MATH_PRESERVED = YES
```

**CO_PHYSICAL_STATE_DRIFT_DETERMINATION_1_CORR2_IV1_PASS**

## 10. Reproducible inputs

A-ref labels are locator conveniences; all **25** candidate input SHA/byte bindings are independently matched. Actual values and authorization inventories were inspected, not inferred from report labels.

- **A1** — /Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A WORKBENCH/03_SOURCE_ARTIFACTS/STAGE2_FIVE_RC_AFFECTED_CELL_CENSUS_AND_DUAL_RERUN_PACKETS_2026-10-03/FUTURE_OUTPUT_A/CODER_A_RERUN_RECORDS.jsonl · 52374 B · SHA-256 0aeb8fceb2dce7bd0ec82bb3f08985a42a89ca91b519ec63aee689f0f55d91bd · independently matched.
- **A2** — /Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A WORKBENCH/03_SOURCE_ARTIFACTS/STAGE2_FIVE_RC_AFFECTED_CELL_CENSUS_AND_DUAL_RERUN_PACKETS_2026-10-03/FUTURE_OUTPUT_B/FIVE_RC_RERUN_B_SECTION_I_RECORDS.jsonl · 47533 B · SHA-256 f79c7b218406b3af2e3ade0f8aa4b737db19e40062a8a78273e85c5b6f6d6968 · independently matched.
- **A3** — /Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)/WORKBENCH/DOWNLOADS/STAGE2_FIVE_RC_RERUN_AB_COMPARISON_2026-10-03/FIVE_RC_RERUN_AB_COMPARISON.json · 39019 B · SHA-256 a956b01a7572ad6bb4222761896a080b9935e51942493e1dcb4b310c0817f32e · independently matched.
- **A4** — /Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)/WORKBENCH/DOWNLOADS/STAGE2_FIVE_RC_RERUN_RECONCILIATION_1_CORR1_2026-10-03/FIVE_RC_RERUN_RECONCILIATION_1_CORR1.json · 51523 B · SHA-256 c05fe63c8469f52e8175b8e161190ec8e57ba8d59c6849f5011c4865860d9948 · independently matched.
- **A5** — /Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)/WORKBENCH/DOWNLOADS/STAGE2_POST_RECONCILIATION_DOWNSTREAM_CONSEQUENCE_CENSUS_1_2026-10-03/STAGE2_POST_RECONCILIATION_DOWNSTREAM_CONSEQUENCE_CENSUS_1.json · 207469 B · SHA-256 76473325c04b428741ddd66c3d55f6961066f1bdd269d59bbc460a0d94325688 · independently matched.
- **A6** — /Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)/WORKBENCH/DOWNLOADS/STAGE2_POST_RECONCILIATION_DOWNSTREAM_CONSEQUENCE_CENSUS_1_CORR1_2026-10-04/STAGE2_POST_RECONCILIATION_DOWNSTREAM_CONSEQUENCE_CENSUS_1_CORR1.json · 73983 B · SHA-256 4015f573b7d0ba219a4ee762418826aa4e7964231d8957cbf8d1ac250504f210 · independently matched.
- **A7** — /Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)/WORKBENCH/DOWNLOADS/STAGE2_POST_RECONCILIATION_DOWNSTREAM_CONSEQUENCE_CENSUS_1_CORR2_2026-10-04/STAGE2_POST_RECONCILIATION_DOWNSTREAM_CONSEQUENCE_CENSUS_1_CORR2.json · 31649 B · SHA-256 383350fb7c90fe7824ce191eca42edfd3232816f4d56de8e6fc1fbb9f20e5a9a · independently matched.
- **A8** — /Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)/WORKBENCH/DOWNLOADS/STAGE2_POST_RECONCILIATION_EXECUTION_1_CODER_A_2026-10-04/STAGE2_POST_RECONCILIATION_EXECUTION_1_CODER_A_RECORDS.jsonl · 104314 B · SHA-256 8914e745d5df3fbcfc4c4d47be3643ab44a0a3e89fae3d3445b9a94a0b042c71 · independently matched.
- **A9** — /Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)/WORKBENCH/DOWNLOADS/STAGE2_POST_RECONCILIATION_EXECUTION_1_CODER_A_2026-10-04/STAGE2_POST_RECONCILIATION_EXECUTION_1_CODER_A_MANIFEST.json · 3069 B · SHA-256 f396aea6bef6a4ff4eeb6610a319c650440b6c5f9035633d15aef58a9d636fa9 · independently matched.
- **A10** — /Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)/WORKBENCH/DOWNLOADS/STAGE2_POST_RECONCILIATION_EXECUTION_1_CODER_A_2026-10-04/STAGE2_POST_RECONCILIATION_EXECUTION_1_CODER_A_REPORT.md · 11532 B · SHA-256 69b27ca5a7a2fd0ad65c914291868cf36e54d7c088079c905e9c0f0ac4063484 · independently matched.
- **A11** — /Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)/WORKBENCH/DOWNLOADS/STAGE2_POST_RECONCILIATION_EXECUTION_1_CODER_B_2026-10-04/STAGE2_POST_RECONCILIATION_EXECUTION_1_CODER_B_RECORDS.jsonl · 76833 B · SHA-256 8ab5ac2b55370479d45fb7f351d428fc1d34856675e25ac86da0b87905419d98 · independently matched.
- **A12** — /Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)/WORKBENCH/DOWNLOADS/STAGE2_POST_RECONCILIATION_EXECUTION_1_AB_COMPARISON_2026-10-04/STAGE2_POST_RECONCILIATION_EXECUTION_1_AB_COMPARISON.json · 87506 B · SHA-256 2e8256657225f36612dd00e79a69e755b5fc0d96631ce1523949e57cd49f1f20 · independently matched.
- **A13** — /Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)/WORKBENCH/DOWNLOADS/STAGE2_PD3_ROLE_BOUNDED_ENTITLEMENT_CLARIFICATION_1_CORR1_2026-10-04/STAGE2_PD3_ROLE_BOUNDED_ENTITLEMENT_CLARIFICATION_1_CORR1_CANDIDATE.md · 344754 B · SHA-256 cb08b51e1c2fbaec7765989a7a4e15db1788c53eb5fec43f2628ecb88c1d6c73 · independently matched.
- **A14** — /Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)/WORKBENCH/DOWNLOADS/STAGE2_PD3_ROLE_BOUNDED_ENTITLEMENT_CLARIFICATION_1_CORR1_2026-10-04/STAGE2_PD3_ROLE_BOUNDED_ENTITLEMENT_CLARIFICATION_1_CORR1_DELTA_LEDGER.md · 14170 B · SHA-256 a9aa2ebbf529b85ded52f8620ad392cf7652da53f9c202e50c7fac25744e4947 · independently matched.
- **A15** — /Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)/WORKBENCH/DOWNLOADS/STAGE2_PD3_CORR1_AFFECTED_EXECUTION_1_CODER_A_2026-10-04/STAGE2_PD3_CORR1_AFFECTED_EXECUTION_1_CODER_A_RECORDS.jsonl · 14491 B · SHA-256 c1580db689a02ffba1acecc67aa0ddb2a19b98edb3dd831a0f0ad08fc425e075 · independently matched.
- **A16** — /Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)/WORKBENCH/DOWNLOADS/STAGE2_PD3_CORR1_AFFECTED_EXECUTION_1_CODER_B_2026-10-04/STAGE2_PD3_CORR1_AFFECTED_EXECUTION_1_CODER_B_RECORDS.jsonl · 26057 B · SHA-256 7554edc28e97fd2bf951934b9ef536edea959c2038c2f257cff62b3c926ec681 · independently matched.
- **A17** — /Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)/WORKBENCH/DOWNLOADS/STAGE2_FM0205_PLAN_CURRENT_DRIFT_DETERMINATION_1_REPORT.md · 22345 B · SHA-256 03e3e5bbaa12e456be9090ec87f51a5b7c4cd0f5db386a437841dff5e50083db · independently matched.
- **A17b** — /Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)/WORKBENCH/DOWNLOADS/STAGE2_FM0205_PLAN_CURRENT_DRIFT_DETERMINATION_1_LEDGER.json · 15469 B · SHA-256 e23140c63f52eab4c46506f5ff9b5a278585dd602aa0b9ef6fda9e28cbda8686 · independently matched.
- **A18** — /Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)/WORKBENCH/DOWNLOADS/STAGE2_FM0205_PLAN_CURRENT_DRIFT_CORRECTION_1_2026-10-04/STAGE2_FM0205_PLAN_CURRENT_DRIFT_CORRECTION_1.json · 11015 B · SHA-256 64f489d7569a58d86d4996d1e9abf8538580915ac37ef31e542a0f13188660c4 · independently matched.
- **A18b** — /Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)/WORKBENCH/DOWNLOADS/STAGE2_FM0205_PLAN_CURRENT_DRIFT_CORRECTION_1_2026-10-04/STAGE2_FM0205_PLAN_CURRENT_DRIFT_CORRECTION_1_REPORT.md · 10993 B · SHA-256 025a0484a9d08475f4c429614a9685721432917ed950502228b4cb1ae76f7948 · independently matched.
- **A19** — /Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A WORKBENCH/03_SOURCE_ARTIFACTS/STAGE2_AB_PACKET_PREFREEZE_2026-10-02/FUTURE_OUTPUT_A/STAGE2_CORR4_PILOT_ANALYTICAL_CODER_A_SECTION_I_RECORDS.jsonl · 141563 B · SHA-256 f399423557ca82359454743213cdaf977b065ecc5dd015cd10452ef73d7ed2b0 · independently matched.
- **A20** — /Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A WORKBENCH/03_SOURCE_ARTIFACTS/STAGE2_POST_PILOT_AFFECTED_CELL_RECONCILIATION_CORR2_2026-10-02/STAGE2_POST_PILOT_CURRENT_EFFECTIVE_CODER_A.jsonl · 132061 B · SHA-256 6b8a37ea6646806cf41adfaaaa56fbe576966765747d401f4524e7a2a046d1dd · independently matched.
- **A21a** — /Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)/WORKBENCH/DOWNLOADS/STAGE2_FM0205_PLAN_CURRENT_DRIFT_CORRECTION_1_IV1_REPORT.md · 20143 B · SHA-256 ff2d43d3d8eaa19dec1665a9b3dbb5e0d4340f915d3d607d7faabea9917b8d5a · independently matched.
- **A21b** — /Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)/WORKBENCH/DOWNLOADS/STAGE2_FM0205_PLAN_CURRENT_DRIFT_CORRECTION_1_IV1_FINDINGS.json · 3652 B · SHA-256 30dcb079f0d46961f797f5dd80e3f31b79a5d6016e82f52ec9a21638cbe7ffca · independently matched.
- **A21c** — /Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)/WORKBENCH/DOWNLOADS/STAGE2_FM0205_PLAN_CURRENT_DRIFT_CORRECTION_1_IV1_MANIFEST.json · 12257 B · SHA-256 09ebb1fdd8a45d703d41b67f0b7594c424c3826894a88bc06a7512dc77f9354d · independently matched.

Additional source/protection identities are in the manifest, including Five-RC delta/consolidated IV reports, the prior 175-file protected inventory and accepted plan-current correction manifest. Workbench placement is evidence location, never acceptance authority.
