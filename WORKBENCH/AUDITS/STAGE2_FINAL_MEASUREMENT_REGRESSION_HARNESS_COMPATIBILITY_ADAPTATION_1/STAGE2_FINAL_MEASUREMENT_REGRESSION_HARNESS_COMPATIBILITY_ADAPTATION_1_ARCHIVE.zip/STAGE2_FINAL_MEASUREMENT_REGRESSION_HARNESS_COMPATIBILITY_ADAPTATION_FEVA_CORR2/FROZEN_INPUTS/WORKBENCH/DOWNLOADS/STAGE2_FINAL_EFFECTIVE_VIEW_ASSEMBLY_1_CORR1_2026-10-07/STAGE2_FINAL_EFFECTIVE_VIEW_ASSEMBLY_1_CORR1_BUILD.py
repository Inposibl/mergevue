#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1.CORR1 — deterministic build (CODER act, Z-Ai, 2026-10-07).

Corrects exactly the defects identified by STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1.IV1
(Codex, 2026-10-07, VERDICT FAIL) while preserving the verified F0024 identity
reconciliation, the accepted A-E001 semantics, the immutable predecessor a1fcae68…,
and the 114 unrelated records:

  F01 (CRITICAL/BLOCKING): SEP-I-4 (CORR1 02505e92… §6.3) / SEP-BC-2 / SEP-BC-3 — the
      migrated A-E001 successor record carries NO `supportClass` key. The legacy
      classification DIRECT_SUPPORT and its provenance move to the separate
      CORR1 MIGRATION_LEDGER (deliverable 3). The immutable predecessor is untouched.
  F02 (MAJOR): `projectionClass` and `legacySupportClass` are migration-ledger
      metadata, not SECTION_I record fields (SEP-BC-2: successor records write the
      three SEP fields; SEP-BC-5: exactly three new record fields). Both live only
      in the migration ledger now, with the migration-scoped `migrationRuleId`,
      `successorTriple` and `holdCode` alongside them.
  F03 (MINOR): DELTA provenance distinguishes ABSENT from explicit JSON null
      ({"presence": "ABSENT"} vs {"presence": "PRESENT", "value": …}).
  F04 (MINOR): the manifest pins every other output member (SHA-256 + bytes) and
      documents its self-hash policy; no circular self-hash.

The successor §I record therefore carries exactly: the three SEP fields
(`bearingEvaluability`, `bearingIndeterminacyReasons`, `supportBearing`) plus the
machinery input `prOnlyBasis` (accepted bearing decision
`recordedPrOnlyBasisForMaterialization`; required on the record — without it the
as-frozen replay returns HOLD-T and SEP-I-11 would invalidate the successor
artifact; explicitly allowed by IV1 F02 table). B-1b fires before B-3; T(r)/W(f)
not required and not materialized (SEP-BC-2).

Every gate is fail-closed. All artifact bytes are fully constructed and verified
in memory before the bounded publication procedure runs. No Git mutation, no
historical-input mutation, no final regression. The failed v1 candidate package
is preserved untouched as IV1 evidence.
"""

import copy
import hashlib
import importlib.util
import json
import os
import subprocess
import sys

sys.dont_write_bytecode = True

REPO = ("/Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/"
        "MergeVue-M&A (August 2026)")
PKG = os.path.join(REPO, "WORKBENCH/DOWNLOADS/STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_2026-10-07")

EXPECTED_HEAD = "3d7b7779903cc04a43929a9e8f6f2b371d9be377"
F0024_BIND_COMMIT = "fcbcf86fbaafe7711caf4ab76d0c8d852f243d5a"
AE001_BIND_COMMIT = "3d7b7779903cc04a43929a9e8f6f2b371d9be377"
CORR10_BIND_COMMIT = "9b1545e"

FAILED_PKG = "WORKBENCH/DOWNLOADS/STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1_2026-10-07"
FAILED_RECORDS_SHA = "ea0de2f072f0b13f15d36ff053ef047128de15b529d31cefeb1a3337462f6f0a"
FAILED_PACKAGE_PINS = {
    "STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1_RECORDS.jsonl":
        "ea0de2f072f0b13f15d36ff053ef047128de15b529d31cefeb1a3337462f6f0a",
    "STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1_MANIFEST.json":
        "06488461f472fa7d20e07a706e672ce0b222f45306716035be1bed022bca1785",
    "STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1_DELTA_PROVENANCE.json":
        "b0cc0252c6e63edfb3b18d0697017d3dba20e952e998ce003442235c147772a3",
    "STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1_BUILD.py":
        "9f8372cc6ca9a0b04fc4079079909afa65e3be7d9054d54267db07d253309798",
    "STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1_REPORT.md":
        "62e2f06b2abbd946bc2056bde763589ca084e98d5a55a42b23052cf3e453d15d",
}

PREDECESSOR_REL = ("WORKBENCH/DOWNLOADS/STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_2026-10-05/"
                   "STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_RECORDS.jsonl")
PREDECESSOR_SHA = "a1fcae68939decd0a3c4a39c0a0bc48e8d285bd9cd7ce1928b0d025056244047"
PREDECESSOR_BYTES = 104310
PREDECESSOR_RECORDS = 116

SEP_CORR1_REL = ("WORKBENCH/DOWNLOADS/STAGE2_SUPPORTCLASS_EVALUABILITY_SEMANTIC_SEPARATION_1_CORR1_2026-10-05/"
                 "STAGE2_SUPPORTCLASS_EVALUABILITY_SEMANTIC_SEPARATION_1_CORR1_CANDIDATE.md")
SEP_CORR1_SHA = "02505e92fd018439f9aba7d4b551fe5542c1be92c7bbb7d4f63994dc1dfa51e9"

SEP_DIR = ("WORKBENCH/DOWNLOADS/STAGE2_SUPPORTCLASS_EVALUABILITY_SEMANTIC_SEPARATION_1"
           "_CORR2_CORR1_CORR1_CORR1_CORR1_2026-10-05")
SEP_CANDIDATE_REL = SEP_DIR + "/STAGE2_SUPPORTCLASS_EVALUABILITY_SEMANTIC_SEPARATION_1_CORR2_CORR1_CORR1_CORR1_CORR1_CANDIDATE.md"
SEP_CANDIDATE_SHA = "2f595ab5ddecc7e8149f751c661470bbae1fa3abfb1fb207b2b65c4c4565d6c8"
SEP_IMPACT_CENSUS_REL = SEP_DIR + "/STAGE2_SUPPORTCLASS_EVALUABILITY_SEMANTIC_SEPARATION_1_CORR2_CORR1_CORR1_CORR1_CORR1_IMPACT_CENSUS.json"
SEP_IMPACT_CENSUS_SHA = "3133b758b77da2fa3f0270f4a3818b6d91f1ed6d0b38f6d89500d40bf10fc721"
SEP_MANIFEST_REL = SEP_DIR + "/STAGE2_SUPPORTCLASS_EVALUABILITY_SEMANTIC_SEPARATION_1_CORR2_CORR1_CORR1_CORR1_CORR1_MANIFEST.json"
SEP_MANIFEST_SHA = "f068e31c6b609a3f0e01b0975eb5b0986e9bd1140438513ef18c7ce0a8b276dc"

CORR10_DIR = ("WORKBENCH/DOWNLOADS/STAGE2_SUPPORTCLASS_EVALUABILITY_SEMANTIC_SEPARATION_1"
              "_IMPLEMENTATION_1_CORR10_2026-10-07")
BUILDER_REL = CORR10_DIR + "/STAGE2_SUPPORTCLASS_EVALUABILITY_SEMANTIC_SEPARATION_1_IMPLEMENTATION_1_CORR10_SUCCESSOR_VIEW_BUILDER.py"
BUILDER_SHA = "4fabec820660e9399ece1314142e5bdc99a3196c9794fa71a3dc5ddb80551cc9"
CORR10_MODEL_REL = CORR10_DIR + "/STAGE2_SUPPORTCLASS_EVALUABILITY_SEMANTIC_SEPARATION_1_IMPLEMENTATION_1_CORR10_CONTRACT_MODEL.json"

PATCH_REL = ("WORKBENCH/DOWNLOADS/AOL_F0024_RECONCILIATION_1_2026-10-07/"
             "AOL_F0024_RECONCILIATION_1_PROVENANCE_PATCH.json")
F0024_IV1_REPORT_REL = ("WORKBENCH/DOWNLOADS/AOL_F0024_RECONCILIATION_1_IV1_2026-10-07/"
                        "AOL_F0024_RECONCILIATION_1_IV1_REPORT.md")
AE001_SCOPE_DECISION_REL = ("WORKBENCH/DOWNLOADS/A_E001_SCOPE_DISPOSITION_READJUDICATION_1_2026-10-07/"
                            "A_E001_SCOPE_DISPOSITION_READJUDICATION_1_DECISION.json")
AE001_BEARING_DECISION_REL = ("WORKBENCH/DOWNLOADS/A_E001_BEARING_DIRECTIONALITY_READJUDICATION_1_2026-10-07/"
                              "A_E001_BEARING_DIRECTIONALITY_READJUDICATION_1_DECISION.json")
AE001_IV1_REPORT_REL = ("WORKBENCH/DOWNLOADS/A_E001_SEMANTIC_READJUDICATION_1_IV1_2026-10-07/"
                        "A_E001_SEMANTIC_READJUDICATION_1_IV1_REPORT.md")

REGISTRY_REL = ("WORKBENCH/DOWNLOADS/STAGE2_PD3_ROLE_BOUNDED_ENTITLEMENT_CLARIFICATION_1_CORR1_2026-10-04/"
                "STAGE2_PD3_ROLE_BOUNDED_ENTITLEMENT_CLARIFICATION_1_CORR1_CANDIDATE.md")
REGISTRY_SHA = "cb08b51e1c2fbaec7765989a7a4e15db1788c53eb5fec43f2628ecb88c1d6c73"

PI3_SIDECAR_REL = "WORKBENCH/DOWNLOADS/STAGE2_CORR4_PILOT_ANALYTICAL_PROVENANCE_SIDECAR_CORR1.jsonl"
PI3_SIDECAR_SHA = "84ab83d23209eae9f775844502676d462490ca8954f8d7a135d28acf5234d6af"
SOURCE_MAP_REL = "WORKBENCH/DOWNLOADS/STAGE2_CORR4_PILOT_STAGE1_SOURCE_MAP.json"
SOURCE_MAP_SHA = "665aac81c2e0127d08f0406186891959255391cb99ec34611a972209565f4a7f"
VIEW_SCHEMA_REL = "WORKBENCH/DOWNLOADS/STAGE2_CORR4_PILOT_ANALYTICAL_CODER_VIEW_SCHEMA_CORR2_CORR1_CORR2_CORR1.json"
VIEW_SCHEMA_SHA = "0cb5a6b5d2239855eeabe0bfd0e9ceb6c545dc2a86b4b34a90b65187592721b5"

LIVE_PACKAGE = ("/Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A WORKBENCH/"
                "02_CASE_RESEARCH/aol-time-warner/01_T0_PRE_T0_BASELINE/candidate/06_FACTS.json")
LIVE_PACKAGE_BYTES = 61728
LIVE_PACKAGE_SHA = "88b20920149b3fcde03e4e060cf4361e9494fe0137540bbc654c526337fd5f10"

OUT_RECORDS = "STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_RECORDS.jsonl"
OUT_DELTA = "STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_DELTA_PROVENANCE.json"
OUT_LEDGER = "STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_MIGRATION_LEDGER.json"
OUT_MANIFEST = "STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_MANIFEST.json"
OUT_BUILD = "STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_BUILD.py"
OUT_REPORT = "STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_REPORT.md"

ABSENT = {"presence": "ABSENT"}


def present(v):
    return {"presence": "PRESENT", "value": v}


class GateFailure(Exception):
    """Fail-closed condition. No output publication occurs."""


def sha256_file(path):
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def sha256_bytes(b):
    return hashlib.sha256(b).hexdigest()


def require(cond, msg):
    if not cond:
        raise GateFailure(msg)


def dumps(record):
    return json.dumps(record, ensure_ascii=True, separators=(", ", ": "))


def git(*args):
    return subprocess.run(["git", "-C", REPO, *args], capture_output=True, text=True, check=True).stdout


# ---------------------------------------------------------------------------
# Exact-type structural comparison (CORR1 resilience fix: True != 1, 1 != 1.0)
# ---------------------------------------------------------------------------

def exact_eq(a, b):
    if isinstance(a, bool) or isinstance(b, bool):
        return isinstance(a, bool) and isinstance(b, bool) and a == b
    if isinstance(a, (int, float)) or isinstance(b, (int, float)):
        if not (isinstance(a, (int, float)) and isinstance(b, (int, float))):
            return False
        return type(a) is type(b) and a == b
    if isinstance(a, dict) and isinstance(b, dict):
        return set(a) == set(b) and all(exact_eq(a[k], b[k]) for k in a)
    if isinstance(a, list) and isinstance(b, list):
        return len(a) == len(b) and all(exact_eq(x, y) for x, y in zip(a, b))
    if a is None or b is None:
        return a is None and b is None
    return type(a) is type(b) and a == b


ABSENT_SENTINEL = object()


def structural_diff(a, b, path="", expand_containers=False):
    """Path-exact diff between PRESENT structures. Removed/added keys and
    absent-vs-null are distinct. With expand_containers, added/removed dicts and
    lists are expanded to terminal leaf paths (terminal-leaf count)."""
    diffs = []
    a_abs = a is ABSENT_SENTINEL
    b_abs = b is ABSENT_SENTINEL
    if a_abs or b_abs:
        if a_abs and b_abs:
            return diffs
        side = b if a_abs else a
        if expand_containers and isinstance(side, dict):
            for k in side:
                diffs += structural_diff(ABSENT_SENTINEL, side[k], path + "." + k, True)
        elif expand_containers and isinstance(side, list):
            for i, v in enumerate(side):
                diffs += structural_diff(ABSENT_SENTINEL, v, path + "[%d]" % i, True)
        else:
            diffs.append((path, ABSENT if a_abs else present(a), ABSENT if b_abs else present(b)))
        return diffs
    if isinstance(a, dict) and isinstance(b, dict):
        for k in sorted(set(a) | set(b)):
            diffs += structural_diff(a.get(k, ABSENT_SENTINEL), b.get(k, ABSENT_SENTINEL),
                                     path + "." + k if path else k, expand_containers)
        return diffs
    if isinstance(a, list) and isinstance(b, list) and len(a) == len(b):
        for i, (x, y) in enumerate(zip(a, b)):
            diffs += structural_diff(x, y, path + "[%d]" % i, expand_containers)
        return diffs
    if not exact_eq(a, b):
        diffs.append((path, present(a), present(b)))
    return diffs


# ---------------------------------------------------------------------------
# F0024 selector + certification
# ---------------------------------------------------------------------------

def resolve_f0024(records, patch):
    sel = patch["correctionRecords"][0]["targetSelector"]
    require(sel["recordType"] == "SECTION_I_RECORD", "selector recordType")
    hits = []
    for i, r in enumerate(records):
        if (
            r.get("recordType") == "SECTION_I_RECORD"
            and r.get("edgeId") == sel["edgeId"]
            and r.get("caseId") == sel["caseId"]
            and r.get("side") == sel["side"]
            and sel["factIds"][0] in (r.get("factIds") or [])
            and sel["mechanismPropositionIds"][0] in (r.get("mechanismPropositionIds") or [])
            and sel["treeTargetIds"][0] in (r.get("treeTargetIds") or [])
            and isinstance(r.get("factualPackageIdentity"), dict)
        ):
            hits.append(i)
    require(len(hits) == 1, "F0024 selector resolved %d records, require exactly 1" % len(hits))
    return hits[0]


def apply_f0024(record, patch):
    cr = patch["correctionRecords"][0]
    require(cr["field"] == "factualPackageIdentity", "patch field must be factualPackageIdentity")
    require(patch.get("deltaClassification") == "IDENTITY_ONLY_DELTA", "patch must be identity-only")
    fpi = record["factualPackageIdentity"]
    require(exact_eq(fpi, cr["oldValue"]), "F0024 old-value precondition failed (type-exact deep equality)")
    corrected = cr["correctedValue"]
    allowed = set(cr["changedFields"])
    require(allowed == {"caseIdLocator", "packageFactCount", "recordFileBytes", "recordFileSha256"},
            "unexpected changedFields set: %r" % allowed)
    require(set(corrected.keys()) == set(fpi.keys()), "correctedValue member set must equal oldValue member set")
    for k in fpi:
        if k in allowed:
            continue
        require(exact_eq(corrected[k], fpi[k]), "identity member %s must be unchanged" % k)
    out = copy.deepcopy(record)
    for k in sorted(allowed):
        out["factualPackageIdentity"][k] = corrected[k]
    require(exact_eq(out["factualPackageIdentity"], corrected), "post-application identity must equal correctedValue")
    return out


# ---------------------------------------------------------------------------
# A-E001 successor machinery (closed CORR10 builder)
# ---------------------------------------------------------------------------

def load_builder():
    path = os.path.join(REPO, BUILDER_REL)
    require(sha256_file(path) == BUILDER_SHA, "builder identity mismatch")
    spec = importlib.util.spec_from_file_location("corr10_builder_feva_corr1", path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules["corr10_builder_feva_corr1"] = mod
    spec.loader.exec_module(mod)
    return mod


PR_ONLY_BASIS = {
    "ttId": "TT-STJSTP-PW",
    "prohibId": "PR-STJSTP",
    "criterion": "one hard rule",
    "authority": "E9/07 §12 (OWNER-CORR2-STJSTP); cb08b51e §F.3 l.1157; SEP-B-1b",
    "basisFactIds": ["C-B04"],
    "basisComponents": ["c1"],
    "adjudicatedBy": "A_E001_BEARING_DIRECTIONALITY_READJUDICATION_1",
}

EXPECTED_AE001_OUTCOME = {
    "admission": "ADMITTED",
    "holdCode": None,
    "partition": {"c1": "SUPPLIED", "c2": "ORDINARY_MISSING_ASSESSABLE"},
    "failingGates": [],
    "bearingEvaluability": "EVALUABLE",
    "bearingIndeterminacyReasons": None,
    "supportBearing": "NON_DISCRIMINATING",
    "capFired": "B-1b",
    "b3RecordVerdict": None,
}
EXPECTED_AE001_MIGRATION = {
    "migrationRuleId": "SEP-MIG-6a",
    "projectionClass": "MECHANICAL_VALUE_CHANGE",
    "successorTriple": ["EVALUABLE", None, "NON_DISCRIMINATING"],
    "holdCode": None,
}


def run_machinery(builder, record, registry, registry_sha):
    ctx = {"traces": {}, "witness": {}, "coderOutput": {}}
    outcome = builder.evaluate(copy.deepcopy(record), registry, ctx, registry_sha=registry_sha)
    migration = builder.migration_classify(copy.deepcopy(record), outcome, registry)
    return outcome, migration


def require_outcome_matches(outcome, expected, label):
    for k, v in expected.items():
        require(k in outcome and exact_eq(outcome[k], v),
                "%s machinery mismatch on %r: %r != %r" % (label, k, outcome.get(k), v))


def ae001_identity_gates(r):
    require(r.get("recordType") == "SECTION_I_RECORD" and r.get("edgeId") == "A-E001", "A-E001 identity")
    require(r.get("caseId") == "CASE-3.5" and r.get("side") == "CHRYSLER", "A-E001 case/side")
    require(r.get("factIds") == ["C-B04"], "A-E001 factIds")
    require(r.get("mechanismPropositionIds") == ["M-ENFORCE-SANCTION"], "A-E001 M")
    require(r.get("treeTargetIds") == ["TT-STJSTP-PW"], "A-E001 TT")
    require(r.get("evidenceForm") == "DE-1", "A-E001 evidenceForm must remain DE-1 (frozen)")
    require(r.get("supportClass") == "DIRECT_SUPPORT", "A-E001 legacy supportClass precondition")
    require(r.get("relevanceState") == "ANALYTICAL_MAPPED", "A-E001 relevanceState")
    require(r.get("relation") == "SUPPORTS_LEAF", "A-E001 relation")
    require(r.get("observedScope") == "unit" and r.get("claimedScope") == "enterprise", "A-E001 scope fields preserved")
    require(r.get("scopeBridgeFactIds") == [], "A-E001 scopeBridgeFactIds")
    require(r.get("temporalState") == "PRE_T0_CONTINUITY_UNRESOLVED", "A-E001 temporal continuity preserved")
    require(r.get("characteristicityState") == "CHARACTERISTIC", "A-E001 characteristicity preserved")
    require(r.get("abstention") is None and r.get("ambiguity") is None, "A-E001 abstention/ambiguity")
    supplies = r.get("componentSupply") or []
    require(len(supplies) == 1 and supplies[0].get("componentId") == "c1"
            and supplies[0].get("status") == "SUPPLIED", "A-E001 frozen supply input: exactly c1 SUPPLIED")
    require(r.get("scopeBridgeState") == "NOT_REQUIRED", "A-E001 old scopeBridgeState precondition")
    require(r.get("edgeState") == "SUPPORTED", "A-E001 old edgeState precondition")
    require(r.get("sufficiencyExpressionResult") == "TRUE", "A-E001 old sufficiencyExpressionResult precondition")
    require(r.get("missingComponents") == [], "A-E001 old missingComponents precondition")
    require(not any(k in r for k in ("prOnlyBasis", "supportBearing", "holdCode",
                                     "bearingEvaluability", "successorTriple", "migrationRuleId",
                                     "projectionClass", "legacySupportClass")),
            "A-E001 must not already carry successor-axis or ledger keys")


def apply_ae001(record):
    """Materialize the accepted successor state under the CORR1 schema contract:
    legacy `supportClass` REMOVED (SEP-I-4; value preserved in the migration
    ledger); exactly three SEP fields added (SEP-BC-5); `prOnlyBasis` carried as
    the accepted machinery input; establishment/scope fields per the accepted
    scope decision. Ledger-only keys (legacySupportClass, migrationRuleId,
    projectionClass, successorTriple, holdCode) are NOT written to the record."""
    out = copy.deepcopy(record)
    out["scopeBridgeState"] = "UNRESOLVED_FAIL_CLOSED"
    out["missingComponents"] = ["c2"]
    out["edgeState"] = "PARTIAL"
    out["sufficiencyExpressionResult"] = "OPEN"
    del out["supportClass"]
    for k, v in (
        ("prOnlyBasis", PR_ONLY_BASIS),
        ("bearingEvaluability", "EVALUABLE"),
        ("bearingIndeterminacyReasons", None),
        ("supportBearing", "NON_DISCRIMINATING"),
    ):
        require(k not in out, "key collision on %s" % k)
        out[k] = v
    return out


SUCCESSOR_NEW_KEYS = ["prOnlyBasis", "bearingEvaluability", "bearingIndeterminacyReasons", "supportBearing"]
FORBIDDEN_SUCCESSOR_KEYS = ["supportClass", "legacySupportClass", "projectionClass",
                            "migrationRuleId", "successorTriple", "holdCode"]


def assert_successor_schema(rec, builder):
    """SEP-I-4 / SEP-BC-2 / SEP-BC-5 conformance for the migrated record."""
    require("supportClass" not in rec, "SEP-I-4 violation: successor record carries supportClass")
    for k in FORBIDDEN_SUCCESSOR_KEYS:
        require(k not in rec, "forbidden successor-record key %s (SEP-BC-2/BC-5; Owner F01/F02)" % k)
    for k in SUCCESSOR_NEW_KEYS:
        require(k in rec, "missing successor field %s" % k)
    banned = builder.assert_environment_safe(rec)
    require(not banned, "forbidden output keys on successor record: %r" % banned)
    require(rec["bearingEvaluability"] == "EVALUABLE", "SEP-I-1/3: EVALUABLE")
    require(rec["bearingIndeterminacyReasons"] is None, "SEP-I-2: reasons null iff EVALUABLE")
    require(rec["supportBearing"] == "NON_DISCRIMINATING", "successor bearing value")
    assert_scope_fail_closed(rec)


def assert_scope_fail_closed(rec):
    require(rec.get("observedScope") == "unit", "observedScope must remain unit (no upward promotion)")
    require(rec.get("claimedScope") == "enterprise", "claimedScope unchanged")
    require(rec.get("scopeBridgeState") == "UNRESOLVED_FAIL_CLOSED", "scopeBridgeState fail-closed")
    require(rec.get("scopeBridgeFactIds") == [], "no scope bridge facts")


def assert_no_dual_representation(records):
    for i, r in enumerate(records):
        require(not ("supportClass" in r and "supportBearing" in r),
                "dual representation on line %d (SEP-BC-2 no-dual-write)" % (i + 1))


# ---------------------------------------------------------------------------
# Negative controls (forced failure through the REAL paths)
# ---------------------------------------------------------------------------

def negative_controls(records, patch, f0024_idx, builder, registry, reg_sha,
                      ae001_pre, ae001_final, authority, corrected_identity, f0024_proposition):
    nc = {}

    # NC-1: old-value precondition must reject a tampered identity member (real apply path).
    tampered = copy.deepcopy(records[f0024_idx])
    tampered["factualPackageIdentity"]["packageFactCount"] = 51
    try:
        apply_f0024(tampered, patch)
        raise GateFailure("NC-1 did not fire")
    except GateFailure as e:
        nc["NC1_oldValuePreconditionRejected"] = str(e) != "NC-1 did not fire"

    # NC-2a/2b: selector must reject zero and multiple matches (real resolver).
    reduced = [r for i, r in enumerate(records) if i != f0024_idx]
    try:
        resolve_f0024(reduced, patch)
        raise GateFailure("NC-2a did not fire")
    except GateFailure as e:
        nc["NC2a_selectorRejectsZeroMatches"] = str(e) != "NC-2a did not fire"
    duplicated = list(records) + [copy.deepcopy(records[f0024_idx])]
    try:
        resolve_f0024(duplicated, patch)
        raise GateFailure("NC-2b did not fire")
    except GateFailure as e:
        nc["NC2b_selectorRejectsMultipleMatches"] = str(e) != "NC-2b did not fire"

    # NC-3: REAL ProductionPackageAuthority.certify() path (not an artificial digest check).
    stale_identity = copy.deepcopy(corrected_identity)
    stale_identity["recordFileSha256"] = "4b686b245e412a83424168da6c87db9b392b4ea16eeadff48c0b62e49c7198bb"
    stale_identity["recordFileBytes"] = 139589
    stale_identity["packageFactCount"] = 105
    stale_identity["caseIdLocator"] = "package-level key 'case_id'"
    nc["NC3a_staleIdentityRejectedByCertify"] = authority.certify(
        stale_identity, "F0024", "aol-time-warner", "AOL") is None
    nc["NC3b_wrongSideRejectedByCertify"] = authority.certify(
        corrected_identity, "F0024", "aol-time-warner", "TIME_WARNER") is None
    tampered_count = copy.deepcopy(corrected_identity)
    tampered_count["packageFactCount"] = 51
    nc["NC3c_tamperedAssertionRejectedByCertify"] = authority.certify(
        tampered_count, "F0024", "aol-time-warner", "AOL") is None
    other = authority.certify(corrected_identity, "F0023", "aol-time-warner", "AOL")
    nc["NC3d_otherFactBindsOwnTextOnly"] = bool(
        other is not None and other.fact_id == "F0023"
        and other.proposition and other.proposition != f0024_proposition)
    require(f0024_proposition == authority.certify(
        corrected_identity, "F0024", "aol-time-warner", "AOL").proposition,
        "certified F0024 proposition must be stable")

    # NC-4: as-frozen A-E001 (no recorded basis) reproduces the superseded HOLD-T routing.
    o_frozen, m_frozen = run_machinery(builder, ae001_pre, registry, reg_sha)
    nc["NC4_asFrozenHoldTReproduced"] = bool(
        o_frozen.get("admission") == "HELD" and o_frozen.get("holdCode") == "HOLD-T"
        and m_frozen.get("migrationRuleId") == "SEP-MIG-6c"
        and m_frozen.get("projectionClass") == "RE_ADJUDICATION"
        and m_frozen.get("successorTriple") == [None, None, None])

    # NC-5: altered successor result must be rejected by the persisted-vs-computed gate.
    try:
        computed = {"supportBearing": "NON_DISCRIMINATING"}
        persisted = {"supportBearing": "DIRECT_SUPPORT"}
        require(exact_eq(persisted["supportBearing"], computed["supportBearing"]),
                "persisted successor value must equal computed machinery value")
        raise GateFailure("NC-5 did not fire")
    except GateFailure as e:
        nc["NC5_alteredSuccessorResultRejected"] = str(e) != "NC-5 did not fire"

    # NC-6: scope promotion must be rejected (real scope gate).
    promoted = copy.deepcopy(ae001_final)
    promoted["observedScope"] = "enterprise"
    try:
        assert_scope_fail_closed(promoted)
        raise GateFailure("NC-6 did not fire")
    except GateFailure as e:
        nc["NC6_scopePromotionRejected"] = str(e) != "NC-6 did not fire"

    # NC-7: forbidden schema keys / dual representation must be rejected.
    dual = copy.deepcopy(ae001_final)
    dual["supportClass"] = "DIRECT_SUPPORT"
    try:
        assert_successor_schema(dual, builder)
        raise GateFailure("NC-7a did not fire")
    except GateFailure as e:
        nc["NC7a_dualWriteRejected"] = str(e) != "NC-7a did not fire"
    ledger_keyed = copy.deepcopy(ae001_final)
    ledger_keyed["projectionClass"] = "MECHANICAL_VALUE_CHANGE"
    try:
        assert_successor_schema(ledger_keyed, builder)
        raise GateFailure("NC-7b did not fire")
    except GateFailure as e:
        nc["NC7b_ledgerKeyOnRecordRejected"] = str(e) != "NC-7b did not fire"

    require(all(v is True for k, v in nc.items()), "negative controls failed: %r" % nc)
    return nc, o_frozen, m_frozen


# ---------------------------------------------------------------------------
# Bounded safe publication (F04/independent-check resilience)
# ---------------------------------------------------------------------------

def publish(artifacts):
    """All bytes are fully constructed and every gate has already passed.
    Per-file atomic via temp+fsync+os.replace, then re-read verification.
    Remaining limitation (disclosed): publication is atomic per FILE, not as a
    six-file set; bounded by pre-checked nonexistence of all targets."""
    published = []
    tmp_files = []
    try:
        for name, blob in artifacts:
            final = os.path.join(PKG, name)
            require(not os.path.exists(final), "refusing to overwrite existing %s" % name)
        for name, blob in artifacts:
            final = os.path.join(PKG, name)
            tmp = final + ".publishing-tmp"
            tmp_files.append(tmp)
            with open(tmp, "wb") as f:
                f.write(blob)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, final)
            tmp_files.remove(tmp)
            published.append(name)
        for name, blob in artifacts:
            with open(os.path.join(PKG, name), "rb") as f:
                require(f.read() == blob, "post-publication byte verification failed for %s" % name)
        return published
    except Exception:
        for t in tmp_files:
            try:
                os.remove(t)
            except OSError:
                pass
        raise


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    # --- baseline + immutable inputs -----------------------------------------
    head = git("rev-parse", "HEAD").strip()
    require(head == EXPECTED_HEAD, "HEAD %s != expected %s" % (head, EXPECTED_HEAD))
    status_lines = git("status", "--porcelain=v1").splitlines()
    tracked_dirty = [l for l in status_lines if not l.startswith("??")]
    require(not tracked_dirty, "tracked dirty state present: %r" % tracked_dirty)
    staged = git("diff", "--cached", "--name-only").splitlines()
    require(not staged, "staged paths present: %r" % staged)

    pins = {}
    for rel, expected in (
        (PREDECESSOR_REL, PREDECESSOR_SHA),
        (SEP_CORR1_REL, SEP_CORR1_SHA),
        (SEP_CANDIDATE_REL, SEP_CANDIDATE_SHA),
        (SEP_IMPACT_CENSUS_REL, SEP_IMPACT_CENSUS_SHA),
        (SEP_MANIFEST_REL, SEP_MANIFEST_SHA),
        (BUILDER_REL, BUILDER_SHA),
        (REGISTRY_REL, REGISTRY_SHA),
        (PI3_SIDECAR_REL, PI3_SIDECAR_SHA),
        (SOURCE_MAP_REL, SOURCE_MAP_SHA),
        (VIEW_SCHEMA_REL, VIEW_SCHEMA_SHA),
    ):
        got = sha256_file(os.path.join(REPO, rel))
        require(got == expected, "input identity mismatch %s: %s != %s" % (rel, got, expected))
        pins[rel] = got
    for name, expected in FAILED_PACKAGE_PINS.items():
        got = sha256_file(os.path.join(REPO, FAILED_PKG, name))
        require(got == expected, "failed-candidate evidence mutated: %s" % name)

    require(not os.path.exists(os.path.join(PKG, OUT_RECORDS)), "CORR1 package must be empty of prior outputs")

    patch = json.load(open(os.path.join(REPO, PATCH_REL), encoding="utf-8"))
    raw = open(os.path.join(REPO, PREDECESSOR_REL), "rb").read()
    require(len(raw) == PREDECESSOR_BYTES, "predecessor bytes mismatch")
    lines = raw.decode("ascii").split("\n")[:-1]
    require(len(lines) == PREDECESSOR_RECORDS, "predecessor record count mismatch")
    records = [json.loads(l) for l in lines]

    # --- F0024 chain (unchanged from verified assembly) -----------------------
    f0024_idx = resolve_f0024(records, patch)
    require(f0024_idx == 111, "F0024 SECTION_I record expected at line 112")
    cr = patch["correctionRecords"][0]
    sidecar_lines = open(os.path.join(REPO, PI3_SIDECAR_REL), encoding="utf-8").read().splitlines()
    require(len(sidecar_lines) == 30, "PI-3 sidecar line count")
    r9 = json.loads(sidecar_lines[8])
    require((r9.get("caseId"), r9.get("sideId"), r9.get("factId")) == ("aol-time-warner", "AOL", "F0024"),
            "PI-3 sidecar line 9 identity")
    require(exact_eq(r9["factualPackageIdentity"], cr["correctedValue"]),
            "PI-3 corrected identity != patch correctedValue")
    live = open(LIVE_PACKAGE, "rb").read()
    require(len(live) == LIVE_PACKAGE_BYTES and sha256_bytes(live) == LIVE_PACKAGE_SHA,
            "live factual package identity")
    data = json.loads(live)
    facts = data["facts"]
    require(len(facts) == 50, "live fact count")
    sides = {}
    for f in facts:
        sides[f.get("side")] = sides.get(f.get("side"), 0) + 1
    require(sides == {"AOL": 25, "TIME_WARNER": 25}, "live sides %r" % sides)
    require(all(f.get("case_id") == "aol-time-warner" for f in facts), "record-level case_id")

    f0024_pre = records[f0024_idx]
    f0024_post = apply_f0024(f0024_pre, patch)

    # --- A-E001 chain ----------------------------------------------------------
    ae001_pre = records[114]
    ae001_identity_gates(ae001_pre)

    builder = load_builder()
    meth_bytes = open(os.path.join(REPO, REGISTRY_REL), "rb").read()
    require(sha256_bytes(meth_bytes) == REGISTRY_SHA, "registry identity")
    registry = builder.parse_registry(meth_bytes.decode("utf-8"))
    reg_sha = builder.registry_identity(meth_bytes)
    require(reg_sha == REGISTRY_SHA, "parsed registry identity")
    registry_counts = {"mechanisms": len(registry["m"]), "treeTargets": len(registry["tt"])}

    r_with_basis = copy.deepcopy(ae001_pre)
    r_with_basis["prOnlyBasis"] = PR_ONLY_BASIS
    outcome, migration = run_machinery(builder, r_with_basis, registry, reg_sha)
    require_outcome_matches(outcome, EXPECTED_AE001_OUTCOME, "A-E001 adjudicated")
    for k, v in EXPECTED_AE001_MIGRATION.items():
        require(k in migration and exact_eq(migration[k], v), "A-E001 migration mismatch %r" % k)

    ae001_final = apply_ae001(ae001_pre)

    # Machinery on the FINAL record: outcome must reproduce without supportClass.
    o_final, _ = run_machinery(builder, ae001_final, registry, reg_sha)
    require_outcome_matches(o_final, EXPECTED_AE001_OUTCOME, "A-E001 final replay")

    # F0024 edge projection non-regression (IV §9, unchanged obligation).
    o_pre112, _ = run_machinery(builder, f0024_pre, registry, reg_sha)
    o_post112, m_post112 = run_machinery(builder, f0024_post, registry, reg_sha)
    require(json.dumps(o_pre112, sort_keys=True) == json.dumps(o_post112, sort_keys=True),
            "F0024 Stage-2 projection changed by identity-only patch")
    require(o_post112.get("bearingEvaluability") == "EVALUABLE"
            and o_post112.get("holdCode") is None
            and o_post112.get("supportBearing") == "NON_DISCRIMINATING"
            and o_post112.get("capFired") == "B-1a (SEP-DE4)"
            and m_post112.get("migrationRuleId") == "SEP-MIG-6a"
            and m_post112.get("projectionClass") == "MECHANICAL_VALUE_CHANGE"
            and m_post112.get("successorTriple") == ["EVALUABLE", None, "NON_DISCRIMINATING"],
            "F0024 edge projection != IV §9 values")

    # Real PI-3 certification through the accepted ProductionPackageAuthority.
    authority = builder.ProductionPackageAuthority(REPO)
    corrected_identity = f0024_post["factualPackageIdentity"]
    certified = authority.certify(corrected_identity, "F0024", "aol-time-warner", "AOL")
    require(certified is not None, "ProductionPackageAuthority.certify failed for F0024/AOL")
    require(certified.package_digest == LIVE_PACKAGE_SHA, "certified package digest")
    require(bool(certified.proposition), "certified proposition empty")
    f0024_proposition = certified.proposition
    certification = {
        "instrument": "CORR10 ProductionPackageAuthority.certify()",
        "identityAuthority": certified.authority,
        "subject": "F0024 / aol-time-warner / AOL",
        "certifiedPackageDigest": certified.package_digest,
        "certifiedPropositionSha256": sha256_bytes(certified.proposition.encode("utf-8")),
        "pi3Sidecar": {"path": PI3_SIDECAR_REL, "sha256": PI3_SIDECAR_SHA, "line": 9,
                       "line9Identity": "aol-time-warner / AOL / F0024",
                       "correctedIdentityEqualsPatch": True},
        "sourceMapSha256": SOURCE_MAP_SHA,
        "livePackageBytes": LIVE_PACKAGE_BYTES,
        "result": "PASS",
    }

    # --- assembly + order independence -----------------------------------------
    def build(order):
        out_lines = list(lines)
        for idx, rec in order:
            out_lines[idx] = dumps(rec)
        return out_lines

    final_lines = build([(f0024_idx, f0024_post), (114, ae001_final)])
    perm_lines = build([(114, ae001_final), (f0024_idx, f0024_post)])
    require(final_lines == perm_lines, "order independence violated")

    # --- serialization gates ------------------------------------------------------
    unchanged_idx = [i for i in range(116) if i not in (f0024_idx, 114)]
    for i in unchanged_idx:
        require(final_lines[i] == lines[i], "unchanged line %d mutated" % (i + 1))
        require(dumps(json.loads(lines[i])) == lines[i], "round-trip convention broken at line %d" % (i + 1))
    for i in (f0024_idx, 114):
        require(dumps(json.loads(final_lines[i])) == final_lines[i], "changed line %d not dumps-stable" % (i + 1))
    blob = "\n".join(final_lines) + "\n"
    require(all(ord(c) < 128 for c in blob), "output must be pure ASCII")
    require(blob.endswith("\n") and not blob.endswith("\n\n"), "exactly one trailing newline")
    require(blob.count("\n") == 116, "exactly 116 records")

    final_records = [json.loads(l) for l in final_lines]

    # --- schema + representation gates (F01/F02) -----------------------------------
    assert_successor_schema(final_records[114], builder)
    assert_no_dual_representation(final_records)
    require("supportClass" not in final_records[114], "supportClass must be absent from successor record")
    require(list(final_records[114].keys())[-4:] == SUCCESSOR_NEW_KEYS, "successor keys must be appended in fixed order")

    # --- exact structural delta (type-exact; absent != null) ------------------------
    expected_112 = {"factualPackageIdentity.recordFileBytes", "factualPackageIdentity.recordFileSha256",
                    "factualPackageIdentity.packageFactCount", "factualPackageIdentity.caseIdLocator"}
    expected_115_paths = {"scopeBridgeState", "missingComponents", "edgeState", "sufficiencyExpressionResult",
                          "supportClass", "prOnlyBasis", "bearingEvaluability",
                          "bearingIndeterminacyReasons", "supportBearing"}
    changed = []
    all_paths = {}
    for i in range(116):
        d = structural_diff(records[i], final_records[i])
        if d:
            changed.append(i)
            all_paths[i] = d
            got = set(p for p, _, _ in d)
            exp = expected_112 if i == 111 else expected_115_paths
            require(got == exp, "diff-path mismatch on line %d: extra=%r missing=%r"
                    % (i + 1, sorted(got - exp), sorted(exp - got)))
    require(changed == [111, 114], "changed records %r" % changed)
    terminal_112 = structural_diff(records[111], final_records[111], expand_containers=True)
    terminal_115 = structural_diff(records[114], final_records[114], expand_containers=True)

    # --- persisted-vs-computed binding (resilience fix) ------------------------------
    fr = final_records[114]
    for k in ("bearingEvaluability", "bearingIndeterminacyReasons", "supportBearing"):
        require(exact_eq(fr[k], o_final[k]), "persisted %s != computed machinery value" % k)
    require(exact_eq(fr["prOnlyBasis"], PR_ONLY_BASIS), "persisted prOnlyBasis != accepted decision value")

    # --- identity preservation ---------------------------------------------------------
    def identity(r):
        if r.get("recordType") == "SECTION_I_RECORD":
            return ("SECTION_I_RECORD", r.get("edgeId"), r.get("caseId"), r.get("side"), tuple(r.get("factIds") or []))
        return ("CELL", r.get("cellIndex"), r.get("factId"), r.get("mechanismPropositionId"),
                r.get("targetId"), r.get("field"), r.get("side"))

    pre_ids = [identity(r) for r in records]
    post_ids = [identity(r) for r in final_records]
    require(pre_ids == post_ids, "record identities/order changed")
    require(len(set(post_ids)) == 116, "duplicate record identities")

    # --- firewalls -----------------------------------------------------------------------
    for i in (110, 112, 113, 115):
        require(final_lines[i] == lines[i], "firewall violated on line %d" % (i + 1))
    require(records[110].get("factIds") == ["F-B-0025"], "F-B-0025 position")
    require(final_records[110].get("sourceQualityState") == records[110].get("sourceQualityState"),
            "F-B-0025 sourceQualityState untouched")

    # --- negative controls (real paths) ----------------------------------------------------
    nc, o_frozen, m_frozen = negative_controls(
        records, patch, f0024_idx, builder, registry, reg_sha,
        ae001_pre, ae001_final, authority, corrected_identity, f0024_proposition)

    # --- post-act immutability ---------------------------------------------------------------
    immut_ok = True
    for rel, expected in ((PREDECESSOR_REL, PREDECESSOR_SHA), (PATCH_REL, None),
                          (AE001_SCOPE_DECISION_REL, None), (AE001_BEARING_DECISION_REL, None),
                          (AE001_IV1_REPORT_REL, None), (F0024_IV1_REPORT_REL, None),
                          (REGISTRY_REL, REGISTRY_SHA), (BUILDER_REL, BUILDER_SHA),
                          (PI3_SIDECAR_REL, PI3_SIDECAR_SHA), (SOURCE_MAP_REL, SOURCE_MAP_SHA)):
        now = sha256_file(os.path.join(REPO, rel))
        if expected is not None and now != expected:
            immut_ok = False
    for name, expected in FAILED_PACKAGE_PINS.items():
        if sha256_file(os.path.join(REPO, FAILED_PKG, name)) != expected:
            immut_ok = False
    if sha256_file(LIVE_PACKAGE) != LIVE_PACKAGE_SHA:
        immut_ok = False
    post_status = git("status", "--porcelain=v1").splitlines()
    post_tracked_dirty = [l for l in post_status if not l.startswith("??")]
    require(immut_ok and not post_tracked_dirty, "immutability or git-state violation")

    # --- artifact construction (F01 ledger, F03 delta, F04 manifest) ---------------------------
    a_scope_sha = sha256_file(os.path.join(REPO, AE001_SCOPE_DECISION_REL))
    a_bearing_sha = sha256_file(os.path.join(REPO, AE001_BEARING_DECISION_REL))
    a_iv1_sha = sha256_file(os.path.join(REPO, AE001_IV1_REPORT_REL))
    f_iv1_sha = sha256_file(os.path.join(REPO, F0024_IV1_REPORT_REL))
    patch_sha = sha256_file(os.path.join(REPO, PATCH_REL))
    sep_corr1_path = os.path.join(REPO, SEP_CORR1_REL)

    build_sha = sha256_file(os.path.abspath(__file__))
    build_bytes = os.path.getsize(os.path.abspath(__file__))

    ledger = {
        "ledgerType": "STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_MIGRATION_LEDGER",
        "act": "STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1.CORR1",
        "actor": "Z-Ai",
        "role": "CODER",
        "date": "2026-10-07",
        "purpose": ("Carries the migration-scoped metadata removed from the migrated A-E001 "
                    "successor SECTION_I record per SEP-I-4 / SEP-BC-2 / SEP-BC-5 (CORR1 "
                    "candidate 02505e92…) and Owner findings F01/F02. The immutable "
                    "predecessor record is untouched; this ledger preserves the legacy "
                    "classification and its provenance for SEP-MIG consumption."),
        "schemaAuthority": {
            "successorRecordFields": "exactly bearingEvaluability, bearingIndeterminacyReasons, supportBearing (SEP-BC-5; §6.1)",
            "successorWriteSet": "three SEP fields + abstention under §6.4 codes + companion W(f)/T(r) where required (SEP-BC-2)",
            "supportClassRule": "SEP-I-4: a successor record carries no supportClass key; SEP-BC-3: deprecated for writing",
            "candidate": {"path": SEP_CORR1_REL, "sha256": SEP_CORR1_SHA},
            "acceptedCandidateChain": {"path": SEP_CANDIDATE_REL, "sha256": SEP_CANDIDATE_SHA},
            "implementation": {"builder": BUILDER_REL, "builderSha256": BUILDER_SHA},
        },
        "entries": [
            {
                "edgeId": "A-E001",
                "caseId": "CASE-3.5",
                "side": "CHRYSLER",
                "factIds": ["C-B04"],
                "mechanismPropositionId": "M-ENFORCE-SANCTION",
                "treeTargetId": "TT-STJSTP-PW",
                "evidenceForm": "DE-1",
                "legacySupportClass": migration.get("legacySupportClass"),
                "legacySupportClassSource": "predecessor a1fcae68… line 115 supportClass (read by migration_classify; removed from the successor record per SEP-I-4)",
                "migrationRuleId": migration.get("migrationRuleId"),
                "projectionClass": migration.get("projectionClass"),
                "successorTriple": migration.get("successorTriple"),
                "holdCode": migration.get("holdCode"),
                "notes": migration.get("notes") or [],
                "machineryInput": {"prOnlyBasis": PR_ONLY_BASIS,
                                   "carriedOnSuccessorRecord": True,
                                   "authority": AE001_BEARING_DECISION_REL + "#/recordedPrOnlyBasisForMaterialization"},
                "machineryEvidence": {
                    "registryIdentity": reg_sha,
                    "registryCounts": registry_counts,
                    "adjudicatedOutcome": {k: outcome.get(k) for k in sorted(outcome)},
                    "asFrozenSupersededState": {"admission": o_frozen.get("admission"),
                                                "holdCode": o_frozen.get("holdCode"),
                                                "migrationRuleId": m_frozen.get("migrationRuleId"),
                                                "projectionClass": m_frozen.get("projectionClass"),
                                                "successorTriple": m_frozen.get("successorTriple")},
                    "finalRecordReplayAdmission": o_final.get("admission"),
                },
                "authority": {
                    "ownerAcceptedGitClosedCommit": AE001_BIND_COMMIT,
                    "scopeDecisionSha256": a_scope_sha,
                    "bearingDecisionSha256": a_bearing_sha,
                    "independentVerification": "A_E001_SEMANTIC_READJUDICATION_1.IV1 VERDICT PASS (BLOCKING 0 / CRITICAL 0 / MAJOR 0 / MINOR 0)",
                    "ivReportSha256": a_iv1_sha,
                    "sepI4AndBcRules": SEP_CORR1_REL + " (sha256 " + SEP_CORR1_SHA + ") §6.1–§6.3, §15",
                },
            }
        ],
    }
    ledger_banned = builder.assert_environment_safe(ledger)
    require(not ledger_banned, "forbidden keys in ledger: %r" % ledger_banned)

    delta = {
        "act": "STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1.CORR1",
        "predecessorSha256": PREDECESSOR_SHA,
        "successorSha256": None,  # filled after serialization
        "valueSemanticsLegend": {
            "presence": "'presence' distinguishes ABSENT (key not carried) from PRESENT (key carried with 'value'); "
                        "an explicit JSON null value is PRESENT with value null (F03 fix)",
        },
        "changedRecordCount": 2,
        "unchangedRecordCount": 114,
        "changedRecords": [
            {
                "line": 112,
                "recordIdentity": {"recordType": "SECTION_I_RECORD", "edgeId": records[111]["edgeId"],
                                   "caseId": "aol-time-warner", "side": "AOL", "factIds": ["F0024"]},
                "authority": {
                    "act": "AOL_F0024_RECONCILIATION_1",
                    "ownerAcceptedGitClosedCommit": F0024_BIND_COMMIT,
                    "patchPath": PATCH_REL, "patchSha256": patch_sha,
                    "independentVerification": "AOL_F0024_RECONCILIATION_1_IV1 VERDICT PASS (PI3_F0024 PASS, FOUR_FIELD_PATCH_SURFACE PASS)",
                    "ivReportSha256": f_iv1_sha,
                    "thisActCertification": "ProductionPackageAuthority.certify() PASS (see manifest f0024Certification)",
                },
                "changedFields": [
                    {"field": "factualPackageIdentity.recordFileBytes",
                     "oldValue": present(139589), "newValue": present(61728),
                     "authorityPath": PATCH_REL + "#/correctionRecords[0]/correctedValue/recordFileBytes"},
                    {"field": "factualPackageIdentity.recordFileSha256",
                     "oldValue": present("4b686b245e412a83424168da6c87db9b392b4ea16eeadff48c0b62e49c7198bb"),
                     "newValue": present("88b20920149b3fcde03e4e060cf4361e9494fe0137540bbc654c526337fd5f10"),
                     "authorityPath": PATCH_REL + "#/correctionRecords[0]/correctedValue/recordFileSha256"},
                    {"field": "factualPackageIdentity.packageFactCount",
                     "oldValue": present(105), "newValue": present(50),
                     "authorityPath": PATCH_REL + "#/correctionRecords[0]/correctedValue/packageFactCount"},
                    {"field": "factualPackageIdentity.caseIdLocator",
                     "oldValue": present("package-level key 'case_id'"),
                     "newValue": present("record-level key 'case_id'"),
                     "authorityPath": PATCH_REL + "#/correctionRecords[0]/correctedValue/caseIdLocator"},
                ],
                "unchangedIdentityMembersVerified": 13,
                "analyticalProjectionUnchanged": True,
            },
            {
                "line": 115,
                "recordIdentity": {"recordType": "SECTION_I_RECORD", "edgeId": "A-E001",
                                   "caseId": "CASE-3.5", "side": "CHRYSLER", "factIds": ["C-B04"]},
                "authority": {
                    "acts": ["A_E001_SCOPE_DISPOSITION_READJUDICATION_1",
                             "A_E001_BEARING_DIRECTIONALITY_READJUDICATION_1"],
                    "ownerAcceptedGitClosedCommit": AE001_BIND_COMMIT,
                    "scopeDecisionSha256": a_scope_sha,
                    "bearingDecisionSha256": a_bearing_sha,
                    "independentVerification": "A_E001_SEMANTIC_READJUDICATION_1.IV1 VERDICT PASS (0/0/0/0)",
                    "ivReportSha256": a_iv1_sha,
                },
                "changedFields": [
                    {"field": "scopeBridgeState", "oldValue": present("NOT_REQUIRED"),
                     "newValue": present("UNRESOLVED_FAIL_CLOSED"),
                     "authorityPath": AE001_SCOPE_DECISION_REL + "#/answers/Q4/exactVocabulary/scopeBridgeState"},
                    {"field": "missingComponents", "oldValue": present([]),
                     "newValue": present(["c2"]),
                     "authorityPath": AE001_SCOPE_DECISION_REL + "#/answers/Q2 (REQUIRED [c1,c2] / MISSING [c2]); Owner-frozen partition"},
                    {"field": "edgeState", "oldValue": present("SUPPORTED"), "newValue": present("PARTIAL"),
                     "authorityPath": AE001_SCOPE_DECISION_REL + "#/FINAL_CURRENT_STAGE2_DISPOSITION/establishment/edgeState"},
                    {"field": "sufficiencyExpressionResult", "oldValue": present("TRUE"),
                     "newValue": present("OPEN"),
                     "authorityPath": AE001_SCOPE_DECISION_REL + "#/FINAL_CURRENT_STAGE2_DISPOSITION/establishment (leafValue OPEN)"},
                    {"field": "supportClass", "oldValue": present("DIRECT_SUPPORT"), "newValue": ABSENT,
                     "disposition": "legacy classification + provenance preserved in "
                                    + OUT_LEDGER + " (SEP-I-4; SEP-BC-2/BC-3; Owner finding F01)"},
                    {"field": "prOnlyBasis", "oldValue": ABSENT, "newValue": present(PR_ONLY_BASIS),
                     "authorityPath": AE001_BEARING_DECISION_REL + "#/recordedPrOnlyBasisForMaterialization"},
                    {"field": "bearingEvaluability", "oldValue": ABSENT, "newValue": present("EVALUABLE"),
                     "authorityPath": AE001_BEARING_DECISION_REL + "#/BEARING_EVALUABILITY (SEP-BC-5 authorized field)"},
                    {"field": "bearingIndeterminacyReasons", "oldValue": ABSENT, "newValue": present(None),
                     "authorityPath": AE001_BEARING_DECISION_REL + "#/stepA_admissionEvaluability/bearingIndeterminacyReasons (explicit null; EVALUABLE)"},
                    {"field": "supportBearing", "oldValue": ABSENT, "newValue": present("NON_DISCRIMINATING"),
                     "authorityPath": AE001_BEARING_DECISION_REL + "#/SUPPORT_BEARING (SEP-BC-5 authorized field)"},
                ],
                "migrationLedgerFields": {
                    "movedToLedger": ["legacySupportClass", "migrationRuleId", "projectionClass",
                                      "successorTriple", "holdCode"],
                    "ledgerPath": OUT_LEDGER,
                    "authorityPath": "Owner findings F01/F02; SEP-BC-2/BC-5; CORR10 migration-ledger vocabulary",
                },
                "preservedFields": ["observedScope", "claimedScope", "factualPackageIdentity", "sourceRefs",
                                    "componentSupply (c1 SUPPLIED, certified content)", "organizationalObjectRef",
                                    "characteristicityState/FactIds", "temporalState/continuityBridgeFactIds",
                                    "sufficiencyExpression", "evidenceForm DE-1", "relation/relevanceState",
                                    "discriminatorIds", "treeTargetIds", "coderIdentity/vocabularyVersion/contractIdentity"],
            },
        ],
    }

    # Serialize candidate outputs (records first — its identity feeds delta/ledger/report)
    records_bytes = blob.encode("ascii")
    delta["successorSha256"] = sha256_bytes(records_bytes)
    delta_bytes = json.dumps(delta, indent=1, ensure_ascii=True, sort_keys=True).encode("utf-8") + b"\n"
    ledger_bytes = json.dumps(ledger, indent=1, ensure_ascii=True, sort_keys=True).encode("utf-8") + b"\n"

    diff_paths_total = sum(len(v) for v in all_paths.values())
    report_text = render_report(
        head=head, registry_counts=registry_counts, outcome=outcome, migration=migration,
        o_final=o_final, o_frozen=o_frozen, m_frozen=m_frozen, nc=nc,
        certification=certification, delta=delta, ledger=ledger,
        records_sha=delta["successorSha256"], records_bytes=len(records_bytes),
        delta_sha=sha256_bytes(delta_bytes), delta_bytes=len(delta_bytes),
        ledger_sha=sha256_bytes(ledger_bytes), ledger_bytes=len(ledger_bytes),
        build_sha=build_sha, build_bytes=build_bytes,
        diff_paths_total=diff_paths_total,
        terminal_112=len(terminal_112), terminal_115=len(terminal_115),
        pins=pins, tracked_dirty_count=len(post_tracked_dirty),
    )
    report_bytes = report_text.encode("utf-8")

    manifest = {
        "act": "STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1.CORR1",
        "actor": "Z-Ai",
        "role": "CODER",
        "date": "2026-10-07",
        "repositoryRoot": REPO,
        "branch": "main",
        "baseHead": head,
        "trackedDirtyBeforeAndAfter": 0,
        "allowedWriteDirectory": os.path.relpath(PKG, REPO),
        "mode": "BOUNDED DETERMINISTIC ASSEMBLY CORR1 (fail-closed; safe publication)",
        "parentAct": {"act": "STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1",
                      "iv1": "STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1.IV1 (Codex, 2026-10-07) VERDICT FAIL",
                      "failedCandidateRecordsSha256": FAILED_RECORDS_SHA,
                      "failedCandidatePreservedUnchanged": True},
        "controllingMethodology": {
            "separationCandidate": {"path": SEP_CANDIDATE_REL, "sha256": SEP_CANDIDATE_SHA},
            "corr1Incorporation": {"path": SEP_CORR1_REL, "sha256": SEP_CORR1_SHA},
            "implementation": "STAGE2_SUPPORTCLASS_EVALUABILITY_SEPARATION_1.IMPLEMENTATION-1.CORR10 (closed)",
            "builderSha256": BUILDER_SHA,
            "f0024BindingCommit": F0024_BIND_COMMIT,
            "ae001BindingCommit": AE001_BIND_COMMIT,
        },
        "inputs": [],
        "outputs": {
            OUT_RECORDS: {"sha256": delta["successorSha256"], "bytes": len(records_bytes), "records": 116},
            OUT_DELTA: {"sha256": sha256_bytes(delta_bytes), "bytes": len(delta_bytes)},
            OUT_LEDGER: {"sha256": sha256_bytes(ledger_bytes), "bytes": len(ledger_bytes)},
            OUT_BUILD: {"sha256": build_sha, "bytes": build_bytes},
            OUT_REPORT: {"sha256": sha256_bytes(report_bytes), "bytes": len(report_bytes)},
        },
        "manifestSelfHashPolicy": ("This manifest pins every other output member by SHA-256 and byte count. "
                                   "It does NOT include its own digest (circular self-hash forbidden). Its "
                                   "identity is established post-write by external hashing; the CORR1 report "
                                   "documents this policy as the package's external identity anchor."),
        "changeInventory": delta,
        "migrationLedgerSummary": {"file": OUT_LEDGER, "entries": 1,
                                   "edgeId": "A-E001",
                                   "legacySupportClass": ledger["entries"][0]["legacySupportClass"],
                                   "migrationRuleId": ledger["entries"][0]["migrationRuleId"]},
        "f0024Certification": certification,
        "machineryEvidence": {
            "registryIdentity": reg_sha, "registryCounts": registry_counts,
            "ae001AdjudicatedOutcome": {k: outcome.get(k) for k in sorted(outcome)},
            "ae001FinalRecordReplay": {k: o_final.get(k) for k in sorted(o_final)},
            "persistedValuesEqualsComputedValues": True,
            "f0024ProjectionNonRegression": {"beforeEqualsAfter": True,
                                             "capFired": o_post112.get("capFired"),
                                             "migrationRuleId": m_post112.get("migrationRuleId"),
                                             "successorTriple": m_post112.get("successorTriple")},
            "supersededAsFrozenState": {"admission": o_frozen.get("admission"),
                                        "holdCode": o_frozen.get("holdCode"),
                                        "migrationRuleId": m_frozen.get("migrationRuleId"),
                                        "projectionClass": m_frozen.get("projectionClass"),
                                        "successorTriple": m_frozen.get("successorTriple")},
        },
        "schemaConformance": {
            "successorRecordCarriesNoSupportClass": True,
            "successorRecordNewKeys": SUCCESSOR_NEW_KEYS,
            "noMigrationOnlyFieldsOnRecord": True,
            "legacyPreservedInLedger": OUT_LEDGER,
            "noDualRepresentationAnywhereInView": True,
            "builderForbiddenKeyGuardOnSuccessorRecordAndLedger": "PASS",
            "sepBC5ExactlyThreeNewRecordFieldsPlusMachineryInput": True,
        },
        "diffExactness": {"typeAware": True, "boolIntDistinct": True, "intFloatDistinct": True,
                          "absentVsNullDistinct": True,
                          "changedDiffPaths": diff_paths_total,
                          "terminalLeafExpansion": {"line112": terminal_112, "line115": terminal_115}},
        "orderIndependence": "PASS (F0024->A-E001 == A-E001->F0024, byte-identical)",
        "serialization": {"convention": "json.dumps(ensure_ascii=True, separators=(', ', ': ')); LF; exactly one trailing newline",
                          "unchangedLinesEmittedVerbatim": 114, "pureAscii": True},
        "negativeControls": nc,
        "publication": {"procedure": "all bytes constructed + all gates passed before any write; per-file tmp+fsync+os.replace; post-write re-read verification",
                        "remainingLimitation": "atomic per file, not as a six-file set (POSIX)"},
        "firewalls": {
            "FB0025_TOUCHED": False,
            "A_E023_LINE116_BYTE_IDENTICAL": True,
            "F_E_0182_LINES_BYTE_IDENTICAL": True,
            "ENVIRONMENT_FIELDS_ALTERED": False,
            "HISTORICAL_PACKAGE_MUTATED": False,
            "FAILED_CANDIDATE_PACKAGE_MUTATED": False,
            "noUnacceptedCandidatePromoted": True,
            "measurementViewPromoted": False,
        },
        "selfValidation": {
            "predecessorShaAndCountExact": True,
            "successorRecords116SameIdentitiesAndOrder": True,
            "onlyAuthorizedChangesF0024AndAe001": True,
            "other114RecordsByteIdentical": True,
            "noSupportClassInMigratedRecord": True,
            "noMigrationOnlyFieldsOnRecord": True,
            "legacyPreservedInSeparateLedger": True,
            "noInconsistentDualRepresentation": True,
            "provenanceDistinguishesAbsentFromNull": True,
            "f0024CertificationActuallyExecutedPass": True,
            "ae001SuccessorValuesReproducedThroughCorr10Machinery": True,
            "exactTypeAwareStructuralDiff": True,
            "negativeControlsCoverRealPaths": True,
            "everyArtifactHasVerifiableOutputIdentity": True,
            "sourcePredecessorAndFailedCandidateUnchanged": True,
            "noMethodologyChange": True,
            "noFinalMeasurementRegression": True,
            "gitMutation": False,
        },
        "status": "READY_FOR_INDEPENDENT_VERIFICATION",
        "ownerAccepted": False,
        "independentlyVerified": False,
        "gitClosed": False,
        "finalRegressionExecuted": False,
        "stoppingPoint": "CORR1 candidate assembly + self-validation complete. No CORR1.IV1 started.",
    }
    manifest["selfValidation"]["noFinalMeasurementRegression"] = True
    manifest["selfValidation"]["gitMutation"] = False

    # Pin the manifest's own inputs table (paths + identities), built from runtime hashes.
    def inp(role, rel, note=""):
        p = os.path.join(REPO, rel)
        return {"role": role, "path": rel, "sha256": sha256_file(p), "bytes": os.path.getsize(p), "note": note}

    manifest["inputs"] = [
        inp("IMMUTABLE_PREDECESSOR", PREDECESSOR_REL),
        inp("SEPARATION_CORR1_INCORPORATION", SEP_CORR1_REL, "SEP-I-4 / SEP-BC schema authority"),
        inp("SEPARATION_ACCEPTED_CANDIDATE", SEP_CANDIDATE_REL),
        inp("SEPARATION_IMPACT_CENSUS", SEP_IMPACT_CENSUS_REL),
        inp("SEPARATION_MANIFEST", SEP_MANIFEST_REL),
        inp("CORR10_BUILDER", BUILDER_REL),
        inp("CORR10_CONTRACT_MODEL", CORR10_MODEL_REL),
        inp("F0024_ACCEPTED_PATCH", PATCH_REL),
        inp("F0024_IV1_REPORT", F0024_IV1_REPORT_REL),
        inp("A_E001_SCOPE_DECISION", AE001_SCOPE_DECISION_REL),
        inp("A_E001_BEARING_DECISION", AE001_BEARING_DECISION_REL),
        inp("A_E001_IV1_REPORT", AE001_IV1_REPORT_REL),
        inp("REGISTRY_METHODOLOGY", REGISTRY_REL),
        inp("PI3_PROVENANCE_SIDECAR", PI3_SIDECAR_REL),
        inp("STAGE1_SOURCE_MAP", SOURCE_MAP_REL),
        inp("VIEW_SCHEMA", VIEW_SCHEMA_REL),
        {"role": "LIVE_AUTHORITATIVE_FACTUAL_PACKAGE", "path": LIVE_PACKAGE,
         "sha256": LIVE_PACKAGE_SHA, "bytes": LIVE_PACKAGE_BYTES},
        {"role": "FAILED_V1_CANDIDATE_EVIDENCE", "path": FAILED_PKG,
         "sha256": None, "bytes": None, "note": "five member SHAs pinned in failedPackagePins and re-verified unchanged"},
    ]

    manifest_bytes = json.dumps(manifest, indent=1, ensure_ascii=True, sort_keys=True).encode("utf-8") + b"\n"

    published = publish([
        (OUT_RECORDS, records_bytes),
        (OUT_DELTA, delta_bytes),
        (OUT_LEDGER, ledger_bytes),
        (OUT_REPORT, report_bytes),
        (OUT_MANIFEST, manifest_bytes),
    ])
    require(published == [OUT_RECORDS, OUT_DELTA, OUT_LEDGER, OUT_REPORT, OUT_MANIFEST],
            "publication order/set mismatch")

    print(json.dumps({
        "recordsSha256": delta["successorSha256"],
        "recordsBytes": len(records_bytes),
        "records": 116,
        "changedLines": [112, 115],
        "diffPaths": diff_paths_total,
        "terminalLeaves": {"line112": terminal_112, "line115": terminal_115},
        "successorRecordNewKeys": SUCCESSOR_NEW_KEYS,
        "supportClassRemovedFromRecord": True,
        "ledger": {"file": OUT_LEDGER, "legacySupportClass": ledger["entries"][0]["legacySupportClass"],
                   "migrationRuleId": ledger["entries"][0]["migrationRuleId"],
                   "projectionClass": ledger["entries"][0]["projectionClass"]},
        "certification": certification["result"],
        "negativeControls": {k: v for k, v in nc.items()},
        "manifest": os.path.join(PKG, OUT_MANIFEST),
        "status": manifest["status"],
    }, indent=1, ensure_ascii=True))


def render_report(**kw):
    return """# STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1.CORR1 — Implementation Report

**ROLE AND AUTHORIZATION.** CODER (Z-Ai, GLM-5.3 Flash), Owner act `STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1.CORR1`, 2026-10-07, correcting the `STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1.IV1` FAIL verdict (Codex, 2026-10-07). Stopping point: CORR1 implementation + self-validation only; CORR1.IV1 not started (Codex is the designated independent auditor in a separate act).

**BASELINE.** Repository `{repo}`, branch `main`, HEAD `{head}` (== expected `3d7b777…`). Tracked dirty 0, staged 0, before and after. Failed v1 candidate package `WORKBENCH/DOWNLOADS/STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1_2026-10-07/` re-hashed before and after: all five members byte-identical to the IV1-pinned identities (RECORDS `ea0de2f0…`), preserved unchanged as IV1 evidence. Immutable predecessor `a1fcae68…` (104,310 bytes, 116 records) re-hashed unchanged. Control Tree v2.1 (digest `360bafa2…` = sidecar) has no node for this 2026-10 act (the tree predates the Stage-2 pilot chain); its Stage-2 status was not used as current state — the binding commits `fcbcf86…` (F0024), `3d7b777…` (A-E001), `9b1545e…` (CORR10) and the Owner task are the controlling authorization. Blocking parent: `STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1.IV1` FAIL. Downstream consumer: the final Stage-2 measurement regression (still blocked pending IV + Owner acceptance).

## 1. Findings disposition (exact)

| Finding | Disposition |
|---|---|
| F01 CRITICAL/BLOCKING — dual `supportClass=DIRECT_SUPPORT` + `supportBearing=NON_DISCRIMINATING` on line 115 violates SEP-I-4/SEP-BC-2 | **FIXED.** `supportClass` REMOVED from the migrated A-E001 successor record (SEP-I-4, CORR1 `02505e92…` §6.3; key also on the builder's own forbidden-output list). Legacy classification DIRECT_SUPPORT + full provenance preserved in `{ledger_file}`. Predecessor untouched. |
| F02 MAJOR — `projectionClass`, `legacySupportClass` are ledger metadata, not record fields | **FIXED.** Both removed from the record and placed in the migration ledger together with the migration-scoped `migrationRuleId`, `successorTriple`, `holdCode`. Schema authority verified before materializing: SEP-BC-2 (successor records write the three SEP fields + abstention + companion W/T where required), SEP-BC-5 (exactly three new record fields). `prOnlyBasis` stays on the record: it is the machinery input consumed by the closed CORR10 builder (`b1b_cap_fires`), it is the accepted bearing decision's `recordedPrOnlyBasisForMaterialization`, IV1-F0024 PASSed it, and without it the as-frozen replay returns HOLD-T which would invalidate the successor artifact under SEP-I-11. No new schema invented. |
| F03 MINOR — absent vs null conflated in delta | **FIXED.** Every old/new value is `{{"presence": "ABSENT"}}` or `{{"presence": "PRESENT", "value": …}}`; `bearingIndeterminacyReasons` is PRESENT with explicit JSON null (EVALUABLE), `holdCode` is not on the record at all (ledger). Legend in the delta artifact. |
| F04 MINOR — outputs not all pinned | **FIXED.** The manifest pins RECORDS, DELTA, MIGRATION_LEDGER, BUILD, REPORT with exact SHA-256 + bytes. `manifestSelfHashPolicy` documented in the manifest and here: the manifest does not self-hash; it is the package's externally anchored member (hash the file post-write). No circular self-hash. |

Resilience items: type-exact structural diff (bool vs int and int vs float compare unequal — `exact_eq`); persisted successor values gate-compared against the accepted computed machinery results (and the final record replays through `evaluate` to the accepted outcome); negative controls exercise the REAL paths — resolver, precondition apply, `ProductionPackageAuthority.certify()` (stale identity / wrong side / tampered assertion rejected; other-fact query binds its own text only), as-frozen HOLD-T discrimination, altered-successor-result rejection, scope-promotion rejection, dual-write and ledger-key-on-record rejection; publication is all-bytes-constructed-then-per-file `tmp + fsync + os.replace` with post-write re-read verification (remaining limitation: atomic per file, not as a six-file set).

## 2. Output identities (package `{pkg}`)

| Artifact | SHA-256 | Bytes |
|---|---|---|
| `{records_file}` | `{records_sha}` | {records_bytes} |
| `{delta_file}` | `{delta_sha}` | {delta_bytes} |
| `{ledger_file}` | `{ledger_sha}` | {ledger_bytes} |
| `{build_file}` | `{build_sha}` | {build_bytes} |
| `{report_file}` | this file (pinned by the manifest) | — |
| `{manifest_file}` | written last; does not self-hash (see manifestSelfHashPolicy) | — |

## 3. A-E001 successor record (line 115) — exact state

Changed existing fields (accepted scope decision `b3900383…`, Owner-frozen partition): `scopeBridgeState` NOT_REQUIRED→UNRESOLVED_FAIL_CLOSED; `missingComponents` []→["c2"]; `edgeState` SUPPORTED→PARTIAL; `sufficiencyExpressionResult` TRUE→OPEN. Removed: `supportClass` (→ ledger). Added (exactly four keys, appended in fixed order): `prOnlyBasis` (verbatim accepted bearing decision `e7624316…` block), `bearingEvaluability` "EVALUABLE", `bearingIndeterminacyReasons` null, `supportBearing` "NON_DISCRIMINATING". Preserved: certified fact content (c1 SUPPLIED), observedScope unit, claimedScope enterprise, organizationalObjectRef, characteristicity, temporal continuity, sufficiencyExpression, evidenceForm DE-1, factualPackageIdentity, sourceRefs, discriminatorIds, treeTargetIds, coderIdentity/vocabulary/contract identity.

Migration ledger entry (bound to computed machinery values, not literals): legacySupportClass `{legacy}`; migrationRuleId `{mig}`; projectionClass `{proj}`; successorTriple `{triple}`; holdCode `{hold}`; machinery input prOnlyBasis; superseded as-frozen state {frozen_admission}/{frozen_hold}/{frozen_mig}.

## 4. Machinery + certification evidence

Registry `cb08b51e…` ({regm} M rows / {regtt} TT rows). Adjudicated evaluation (pre-record + accepted basis) and final-record replay both EXACT-match the accepted decision: admission ADMITTED, holdCode null, partition {{c1 SUPPLIED, c2 ORDINARY_MISSING_ASSESSABLE}}, capFired B-1b, bearingEvaluability EVALUABLE, supportBearing NON_DISCRIMINATING; SEP-MIG-6a / MECHANICAL_VALUE_CHANGE. B-1a not fired (DE-1); B-3 not used; no T(r), no W(f). F0024 edge projection before/after the identity patch canonically identical (cap B-1a SEP-DE4; recorded only, not materialized).

F0024 certification actually executed through the accepted CORR10 `ProductionPackageAuthority.certify()`: subject F0024/aol-time-warner/AOL, authority `{certauth}`, certified package digest `88b20920…`, proposition sha256 `{certprop}`. PI-3 sidecar `84ab83d2…` line 9 == patch correctedValue; live package 61,728 bytes (AOL 25 / TIME_WARNER 25); source map `665aac81…`.

## 5. Diff geometry (type-exact; absent ≠ null)

Exactly 2 changed lines (112, 115); 114 byte-verbatim; {paths} diff paths total — line 112: {t112} terminal leaves (four identity subfields); line 115: {t115} terminal leaves (4 changed + 1 removal + 4 additions with the prOnlyBasis container expanded to its 7 members). Serialization `json.dumps(ensure_ascii=True, separators=(", ", ": "))`, LF, one trailing newline, pure ASCII; order independence PASS.

## 6. Negative controls (all fired; real paths)

{nc_table}

## 7. Deviations / limitations

1. The three establishment fields (`edgeState`, `sufficiencyExpressionResult`, `missingComponents`) and `scopeBridgeState` remain as in the v1 candidate — IV1-verified as supported by the accepted scope decision; unchanged here.
2. `prOnlyBasis` on the successor record is this act's documented schema-conformance judgment (machinery input requirement + SEP-I-11 artifact validity + IV1 allowance); if the Owner prefers it ledger-side too, that is a one-key change with a consequential evaluate() replay gate update.
3. Publication atomicity is per file (disclosed).
4. This is a CANDIDATE: NOT independently verified, NOT Owner-accepted, NOT Git-closed, no final measurement regression. NO_UPWARD_PROMOTION holds; NON_DISCRIMINATING is not negative evidence, not enterprise evidence, not an Environment classification; c2 not re-adjudicated; no methodology change; no Environment math; no Git mutation.

**STATUS: COMPLETE** (bounded CORR1 implementation + self-validation). **STOP.** CORR1.IV1 (Codex) is the next, separately authorized act.
""".format(
        repo=REPO, head=kw["head"],
        pkg=os.path.relpath(PKG, REPO),
        ledger_file=OUT_LEDGER, records_file=OUT_RECORDS, delta_file=OUT_DELTA,
        build_file=OUT_BUILD, report_file=OUT_REPORT, manifest_file=OUT_MANIFEST,
        records_sha=kw["records_sha"], records_bytes=kw["records_bytes"],
        delta_sha=kw["delta_sha"], delta_bytes=kw["delta_bytes"],
        ledger_sha=kw["ledger_sha"], ledger_bytes=kw["ledger_bytes"],
        build_sha=kw["build_sha"], build_bytes=kw["build_bytes"],
        legacy=kw["migration"].get("legacySupportClass"),
        mig=kw["migration"].get("migrationRuleId"),
        proj=kw["migration"].get("projectionClass"),
        triple=json.dumps(kw["migration"].get("successorTriple")),
        hold=json.dumps(kw["migration"].get("holdCode")),
        frozen_admission=kw["o_frozen"].get("admission"),
        frozen_hold=kw["o_frozen"].get("holdCode"),
        frozen_mig=kw["m_frozen"].get("migrationRuleId"),
        regm=kw["registry_counts"]["mechanisms"], regtt=kw["registry_counts"]["treeTargets"],
        certauth=kw["certification"]["identityAuthority"],
        certprop=kw["certification"]["certifiedPropositionSha256"],
        paths=kw["diff_paths_total"], t112=kw["terminal_112"], t115=kw["terminal_115"],
        nc_table="\n".join("| %s | %s |" % (k, "FIRED (rejected as required)" if v else "NOT FIRED")
                           for k, v in sorted(kw["nc"].items())),
        pins="", tracked_dirty_count=kw["tracked_dirty_count"],
    )


if __name__ == "__main__":
    main()
