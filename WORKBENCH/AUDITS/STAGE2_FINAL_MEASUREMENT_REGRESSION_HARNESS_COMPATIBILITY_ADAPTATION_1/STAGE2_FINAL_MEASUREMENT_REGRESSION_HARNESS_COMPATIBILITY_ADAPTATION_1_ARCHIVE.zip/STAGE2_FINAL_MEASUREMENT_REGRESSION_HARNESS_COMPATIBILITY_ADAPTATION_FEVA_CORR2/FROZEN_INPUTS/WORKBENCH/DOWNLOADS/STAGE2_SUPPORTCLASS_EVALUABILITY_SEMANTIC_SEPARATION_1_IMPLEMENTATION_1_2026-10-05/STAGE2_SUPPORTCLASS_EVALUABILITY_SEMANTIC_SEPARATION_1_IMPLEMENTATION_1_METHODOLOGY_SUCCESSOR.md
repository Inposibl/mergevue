# STAGE2_SUPPORTCLASS_EVALUABILITY_SEMANTIC_SEPARATION_1.IMPLEMENTATION-1 — METHODOLOGY SUCCESSOR (PHYSICAL IMPLEMENTATION BINDING)

- **Act:** MERGEVUE — STAGE-2 — STAGE2_SUPPORTCLASS_EVALUABILITY_SEMANTIC_SEPARATION_1.IMPLEMENTATION-1
- **Actor:** Z-Ai
- **Role:** CODER (Owner-assigned; `AGENTS_C.md` mandate)
- **Date:** 2026-10-05
- **Repository root:** `/Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)`
- **Branch / HEAD:** `main` / `2567223087d99b40bdfd174eed32566be7080e44` (read-only Git; no mutation in this act)
- **Implementation status:** IMPLEMENTED + SELF-VALIDATED ONLY. `independentlyVerified = false`, `ownerAccepted = false`, `controlling = false`, `gitClosed = false`.

---

## 0. PURPOSE AND STATUS SEPARATION

This document physically binds the Owner-accepted and independently verified SupportClass / Evaluability Semantic Separation successor as a standalone Stage-2 **implementation methodology successor**. It exists so that the successor schema, field-source matrix, validators and migration machinery of this implementation act have one explicit physical methodology surface.

Two statuses that must never be merged:

| Status | Value |
|---|---|
| Owner acceptance of the four methodology choices (Architecture C; direction-only bearing on incomplete content; conservative DE-4 ceiling; U-3 proven sharing only) | **ACCEPTED — controlling Owner inputs** (accepted-candidate §14 Owner Decision Ledger) |
| Implementation status of this physical candidate | **IMPLEMENTED + SELF-VALIDATED. NOT independently verified. NOT Owner-accepted. NOT Git-closed.** |

The independent verification of the methodology package this implementation implements:

```text
ACT      = STAGE2_SUPPORTCLASS_EVALUABILITY_SEMANTIC_SEPARATION_1.CORR2.CORR1.CORR1.CORR1.CORR1.IV1
AUDITOR  = CODEX
VERDICT  = PASS
SEVERITY = BLOCKING 0 / MAJOR 0 / MINOR 0 / ADVISORY 0
IV report SHA-256   = 8a9742b135258faa1ccef6bb2efc3512b79a0a682d993eaffae1de322ebd11df
IV findings SHA-256 = f1fac11fcb607edb88940e962bd15d349752f66e78f0559f0c8dff8ee9596011
```

Implementation evidence is not independent verification and is not Owner acceptance (Owner task brief §1; `AGENTS_C.md` §13A).

---

## 1. PROVENANCE (exact identities)

| Artifact | SHA-256 | Bytes | Role in this act |
|---|---|---:|---|
| Accepted methodology successor candidate `…_CORR2_CORR1_CORR1_CORR1_CORR1_CANDIDATE.md` | `2f595ab5ddecc7e8149f751c661470bbae1fa3abfb1fb207b2b65c4c4565d6c8` | 111635 | **The semantic authority for this implementation** (byte-verified in this act) |
| Accepted impact census `…_CORR2_CORR1_CORR1_CORR1_CORR1_IMPACT_CENSUS.json` | `3133b758b77da2fa3f0270f4a3818b6d91f1ed6d0b38f6d89500d40bf10fc721` | 187602 | Census evidence + positive control + registry-facts cross-check oracle (byte-verified) |
| Accepted manifest `…_CORR2_CORR1_CORR1_CORR1_CORR1_MANIFEST.json` | `f068e31c6b609a3f0e01b0975eb5b0986e9bd1140438513ef18c7ce0a8b276dc` | 9131 | Package identity (byte-verified) |
| Predecessor Stage-2 methodology `STAGE2_PD3_…_CORR1_CANDIDATE.md` | `cb08b51e1c2fbaec7765989a7a4e15db1788c53eb5fec43f2628ecb88c1d6c73` | 344754 | READ ONLY. Registry `R` parse source (§B TT blocks, §C, §D M rows) |
| Predecessor coder-view schema `…_CODER_VIEW_SCHEMA_CORR2_CORR1_CORR2_CORR1.json` | `0cb5a6b5d2239855eeabe0bfd0e9ceb6c545dc2a86b4b34a90b65187592721b5` | 28839 | READ ONLY. Derivation base of the successor schema |
| Predecessor field-source matrix `…_FIELD_SOURCE_MATRIX_CORR2.json` | `1fb84aed8aadeb2b4c2fc85eb6e01cd2ea3849fae5be28a39e0b65ca4e4e2cdd` | 21176 | READ ONLY. Derivation base of the successor matrix |
| Predecessor controlling effective view `…_EFFECTIVE_VIEW_ASSEMBLY_1_RECORDS.jsonl` | `a1fcae68939decd0a3c4a39c0a0bc48e8d285bd9cd7ce1928b0d025056244047` | 104310 | READ ONLY. Migration input (6 SECTION_I_RECORD rows + 110 execution cells) |
| CASE-3.4 Root-Definitional contract `CASE-3.4_CONTRACT_v1.3.md` | `dae8143899cd4fb7e406b4b410e9730a6f8bf7853989f3ef9757edeec293ae39` | 27762 | READ ONLY. Root Definitional / E9 boundary (unchanged) |

Incorporated-by-reference methodology sections of CORR1 (`02505e92fd018439f9aba7d4b551fe5542c1be92c7bbb7d4f63994dc1dfa51e9`) that the accepted candidate carries forward (accepted candidate §4): §5 preserved core; §6.1–§6.2 record fields and grain; §6.5 W(f); §6.6 T(r); SEP-AV-1/2/4/5; §7.1 EV-1/EV-2/EV-4; §8 reason taxonomy; §9.1–§9.4 (B-1a, B-1b, B-2, B-3); SEP-U-X/U-0/U-1/U-2; §10 SD-1/SD-2/SD-4/SD-5; §11 O-1(a)–(i); §13 SEP-DE4; §14 migration rules and counts; §15 backward compatibility; §17 A-E001; SEP-FW-1..FW-25.

---

## 2. ARCHITECTURE C — THE SUCCESSOR FIELD CONTRACT (Owner Decision 1, ACCEPTED)

`supportClass` is **legacy/predecessor representation**. Successor records use the Architecture-C representation: two typed axes and three successor fields on the §I record, recorded per (edge × consuming TT), the H-8 grain.

| Field | Value space | Meaning |
|---|---|---|
| `bearingEvaluability` | `EVALUABLE` · `INDETERMINATE` · `null` | Whether the target-relative bearing of this edge can be lawfully assessed (§5) |
| `bearingIndeterminacyReasons` | ordered non-empty array · `null` | Every failing evaluability gate, in gate order (§6) |
| `supportBearing` | `DIRECT_SUPPORT` · `DIRECT_CONTRADICTION` · `SHARED_NON_UNIQUE` · `NON_DISCRIMINATING` · `null` | Directional / discriminating bearing of the entailed content relative to the consuming TT (§7) |

- Legacy `NOT_DETERMINABLE` is **not** a successor `supportBearing` value. It remains readable on legacy records only, through the migration layer (SEP-BC-1/BC-3, SEP-MIG).
- No dual write of `supportClass` and `supportBearing` (SEP-I-4: a successor record carries no `supportClass` key).
- Historical source artifacts remain immutable; compatibility is provided through the migration layer, never historical mutation (SEP-MIG-0, SEP-BC-6).

### 2.1 Invariants (SEP-I; CORR1 §6.3 as corrected by the accepted candidate §7.2)

- **SEP-I-1** `bearingEvaluability = null` ⟺ `relevanceState ≠ ANALYTICAL_MAPPED` or the TT is not in `treeTargetIds[]`. In that case all three fields are null.
- **SEP-I-2** `bearingIndeterminacyReasons ≠ null` ⟺ INDETERMINATE. The array is non-empty, duplicate-free, ordered EV-1 → EV-4 and equal to the failing-gate set.
- **SEP-I-3 [CORR2]** `supportBearing ≠ null ⇒ EVALUABLE`. For EVALUABLE records: `supportBearing = null ⟺ UNIQUENESS_UNRESOLVED` (T(r) basis `UNIQUENESS_UNRESOLVED`). This is the only EVALUABLE-null case; a consumer distinguishes it from INDETERMINATE by `bearingEvaluability` alone.
- **SEP-I-4** A successor record carries no `supportClass` key.
- **SEP-I-5** `evidenceForm = DE-4` ∧ admitted ∧ EVALUABLE ⇒ `NON_DISCRIMINATING`, while the C34 §6 constitutive exception is NOT AVAILABLE for the TT (SEP-DE4; Owner Decision 3).
- **SEP-I-6** `DIRECT_CONTRADICTION` ⇒ `relation ∈ {NEGATES_LEAF, COUNTER_M}`. If NEGATES_LEAF, also `absenceEvidenceState = COMPETENT_AFFIRMATIVE_ABSENCE`.
- **SEP-I-7** `DIRECT_SUPPORT` or `SHARED_NON_UNIQUE` ⇒ `relation = SUPPORTS_LEAF` ∧ `componentSupply` non-empty ∧ T(r) complete with record verdict DIRECTIONAL.
- **SEP-I-8 [CORR2]** `DIRECT_SUPPORT` ⇒ W(f) closed ∧ uniqueness basis U-0/U-1. `SHARED_NON_UNIQUE` ⇒ W(f) closed ∧ uniqueness basis U-2.
- **SEP-I-9** No successor field, `abstention` code, W(f) or T(r) is read by §F.3 or §F.5. targetState, leaf values and sufficiencyExpressionResult are computed exactly as today.
- **SEP-I-10** For an admitted record, (`bearingEvaluability`, `bearingIndeterminacyReasons`) is a function of EV_INPUT_SIGNATURE exactly (§4). `edgeState` is not an argument.
- **SEP-I-11** A successor artifact that contains a held record is invalid and may not be materialized. (Exception under the accepted candidate §7.1: `UNIQUENESS_UNRESOLVED` is a truthful materializable terminal pipeline state, not a hold.)

### 2.2 Companion inputs

- **`selectionCensusWitness` W(f)** — one per (coder output, fact f with ≥1 ANALYTICAL_MAPPED record): identity + one entry per registry M (74): `disposition ∈ {SELECTED, NOT_SELECTABLE}`, entailed componentIds for SELECTED. Closure W-1 (coverage: exactly the 74 M ids, each once), W-2 (identity), W-3 (materialization: every SELECTED M has a SUPPORTS_LEAF record of f whose treeTargetIds cover every registry-consuming TT of M; no NOT_SELECTABLE M has such a record), W-4 (consistency: CO_ENTAILS targets ⊆ SELECTED; componentSupply ≡ witness entry).
- **`directionalityTrace` T(r)** — one per record reaching SEP-B-3, keyed `edgeId` + `treeTargetId`: T-1 universe (Cmp⁺(r) = Cmp(M) ∪ Sel_other(f), registry identity), T-2 component entries (basis, MD-2, MD-3 dispositions), T-3 verdict rules (DISTINGUISHING iff MD-2 NOT_TRIGGERED and every M′ NO_CO_ENTAILMENT), T-4 record verdict (DIRECTIONAL iff ≥1 DISTINGUISHING component; NON_DIRECTIONAL iff every supplied component NON_DISTINGUISHING with witness), T-5 provenance + mechanically derived `uniqueness` section with basis U-0/U-1/U-2/U-3/U-X and the alternative list.

### 2.3 Record-level linkage (witness coupling requirement)

Where the accepted successor contract requires establishment coupling (O-1(b), SD-2 conditions 1–7), a DIRECT_SUPPORT / SHARED_NON_UNIQUE record may contribute to separation only when coupled to a qualified establishing witness referring to the same: M/leaf; organizational object (`organizationalObjectRef` / `relationInstanceId`); claimed scope (bridged); T0 time; lawful relation instance (§F.4.1); and including the fact(s) supplying the record's DISTINGUISHING component. Bearing alone never reconstructs instantiation. No HEDC is authored in this act.

---

## 3. THE FOUR OWNER METHODOLOGY DECISIONS (verbatim binding; accepted-candidate §14)

1. **ARCHITECTURE C — ACCEPTED.** Separate `bearingEvaluability` from `supportBearing`; legacy `NOT_DETERMINABLE` is not a successor bearing value. Two typed axes; INDETERMINATE gives null bearing with reasons; evaluability never reads edgeState.
2. **DIRECTION ON INCOMPLETE CONTENT — ACCEPTED.** A PARTIAL / OPEN record may carry directional bearing if and only if direction is lawfully established under the accepted witness / comparator / trace rules. PARTIAL alone creates NO direction. Directional bearing alone does NOT establish a mechanism, Tree Target, Environment, Pair, ECS, friction or a downstream outcome.
3. **DE-4 CONSERVATIVE CEILING — ACCEPTED.** For an admitted record with `bearingEvaluability = EVALUABLE` and `evidenceForm = DE-4`, while the constitutive exception is unavailable: `supportBearing = NON_DISCRIMINATING`. DE-4 is NOT an evaluability failure and never by itself produces INDETERMINATE.
4. **U-3 PROVEN-SHARING-ONLY — ACCEPTED.** `SHARED_NON_UNIQUE` requires proven directional bearing to more than one lawful Environment alternative. An INDETERMINATE alternative is not positive evidence for that alternative. For directional X + an unresolved/INDETERMINATE alternative + no proven directional alternative, the lawful successor state is: `bearingEvaluability = EVALUABLE`, `supportBearing = null`, directionality trace for X retained, pipeline state `UNIQUENESS_UNRESOLVED`, `DIRECT_SUPPORT` forbidden, `SHARED_NON_UNIQUE` forbidden. `UNIQUENESS_UNRESOLVED` is NOT added to the `supportBearing` enum.

There are ZERO open Owner methodology surfaces in this act. No methodology decision may be requested or taken by an implementing agent here.

---

## 4. AXIS 1 — EVALUABILITY: EXACT AND CLOSED INPUT SIGNATURE

```text
EV_INPUT_SIGNATURE (closed) = ⟨
  sourceQualityState,
  ambiguity.{competing M-ids, resolutionState},
  abstention.declarations[{code, mechanismPropositionId, componentId}],
  componentSupply[].componentId   (entries for the record's leaf/counter M),
  mechanismPropositionIds,
  treeTargetIds,
  R = { TT rows: verdict, docStatus, mechExpr; §C.0 C-3 status;
        §D rows: requiredComponents; SEP-NACR clause list; registry identity } ⟩

ADMISSION_INPUT_SIGNATURE = EV_INPUT_SIGNATURE ∪ ⟨ edgeState ⟩
  edgeState is read ONLY by SEP-AV-1 / AV-2 consistency checks.
  An admission failure yields a HOLD and never an evaluability value.
```

Nothing outside EV_INPUT_SIGNATURE is read by EV-1..EV-4. Nothing in it is a bearing output, W(f) or T(r). **Invariance:** for two admitted records that differ only in `edgeState`, the evaluability value is identical. A change of `componentSupply` alone can change only admission (HOLD-NA under AV-6) or the partition between SUPPLIED and ORDINARY_MISSING_ASSESSABLE — never EV-3, because EV-3 fires only on NON_ASSESSABLE.

### 4.1 Component partition (PART(r, c)) — no precedence rule

Defined only for admitted records; for each required component c of the record's M:

| State | Condition |
|---|---|
| `SUPPLIED` | c ∈ componentSupply[].componentId |
| `NON_ASSESSABLE` | an admitted `NACR-k` declaration names c, and clause k is on c |
| `ORDINARY_MISSING_ASSESSABLE` | neither |

Exactly one state per component. CORR1's "SUPPLIED over NON_ASSESSABLE" precedence is **deleted**; a contradiction is held (AV-6), never interpreted. `missingComponents` is not read by EV; it remains an §F.3 input. A legacy inconsistency between componentSupply and missingComponents (e.g. A-E001) is establishment-side and outside EV, routed by migration.

### 4.2 Gates

- **SEP-EV-0 Applicability.** `relevanceState = ANALYTICAL_MAPPED` ∧ the TT ∈ `treeTargetIds[]`. Otherwise all three fields are null (MIG-1).
- **SEP-EV-1 SOURCE_CONTENT_INACCESSIBLE.** Fails iff `sourceQualityState = CONTENT_INACCESSIBLE`.
- **SEP-EV-2 MECHANISM_READING_AMBIGUOUS.** Fails iff the record's `ambiguity` names ≥1 competing M-id and its resolution state is not RESOLVED (§F.5 E-R7). edgeState AMBIGUOUS must agree; a mismatch is SEP-AV-2.
- **SEP-EV-3 COMPONENT_NOT_ASSESSABLE.** Fails iff ∃ c: PART(r, c) = NON_ASSESSABLE (an admitted `NACR-k` declaration naming a component of the record's M that carries clause k and is not in componentSupply).
- **SEP-EV-4 TARGET_BINDING_UNRESOLVED.** Fails iff the registry route binding the edge's M to the consuming TT is not executable: TT verdict not EXACT; or docStatus not DOCUMENTARY_COMPLETE_CANDIDATE; or the TT's mechExpr does not consume the M; or an open §C.0 C-3 DISCRIMINATOR_SURFACE_INCONSISTENT condition lies on the connecting D route. A record-side binding error is a correction item, not INDETERMINATE.

### 4.3 SEP-NACR — Non-Assessability Clause Registry

- **Definition.** A requiredComponent may be method-declared non-assessable only if its own §D registry row declares a mandatory-abstention / NOT_DETERMINABLE clause for that component.
- **Current list (mechanically extracted from §D, registry `cb08b51e…`): exactly one clause.** NACR-1 — M-RES-ASYMMETRIC-RETENTION c3. Trigger: contribution and return channels identified, channels heterogeneous, and no LAWFUL comparison basis ((a) the participation system's own records valuing both sides in one common unit, or (b) a competent record that itself performs and states or arithmetically entails the comparison). Authority: §D l.997; TT-SFPSFJ-RES l.766; §C D-07 dispatch l.900; §G-7 l.1206; §F.3 l.1121–1122.
- **GENERIC_H7_TO_NACR_REDUCTION = PROVEN (Class B derivation; accepted candidate §5).** On the frozen registry, every lawful current-authority instance of the generic §C/§E/H-7 route reduces to NACR-1 (component side) or EV-1 (source side). GENERIC_H7_ROUTE_EXISTS_OUTSIDE_NACR = NO. A declaration outside NACR-1 is invalid **as a derived consequence** (SEP-NACR-1) and routes to HOLD-NA.
- **SEP-NACR-V (version binding).** The reduction is bound to registry `cb08b51e…`. Any registry change that adds or alters a requiredComponent must re-establish the reduction for the changed rows; until then records under the unverified registry identity are HOLD-NA.
- Explicit NACR clause count on the frozen registry = 1 (M-RES-ASYMMETRIC-RETENTION c3).

### 4.4 Abstention declaration codes (closed list, successor refinement of the existing view-schema `abstention` field)

| Code family | Evaluability effect |
|---|---|
| `NACR-k` (one per SEP-NACR clause) | EV-3 fails → COMPONENT_NOT_ASSESSABLE |
| `NACR-k:CONDITION_NOT_MET` | none |
| `SRC-INACCESSIBLE` | none by itself; must coincide with `sourceQualityState = CONTENT_INACCESSIBLE` (else AV-3) |
| `EST-CHAR`, `EST-PLAN`, `EST-SILENCE` | none (SEP-FW-20; establishment-side) |

Any other declaration is inadmissible and holds the record (SEP-AV-3).

### 4.5 Admission rules (holds are correctable defect states, not field values, not materializable)

| Rule | Condition | Hold |
|---|---|---|
| SEP-AV-1 | `edgeState = NOT_DETERMINABLE` with no EV-1 cause and no NACR declaration | HOLD-ND |
| SEP-AV-2 | `edgeState = AMBIGUOUS` inconsistent with the ambiguity record, or the reverse | HOLD-AMB |
| SEP-AV-3 | invalid abstention code (SEP-NACR-1); NACR-domain record whose clause component is not SUPPLIED and carries no explicit `NACR-k`/`NACR-k:CONDITION_NOT_MET` disposition; `SRC-INACCESSIBLE` without CONTENT_INACCESSIBLE; registry identity not covered by SEP-NACR-V | HOLD-NA |
| SEP-AV-4 | the record needs SEP-B-3 and T(r) is absent or fails T-1/T-4 | HOLD-T |
| SEP-AV-5 | DIRECTIONAL SUPPORTS_LEAF record and W(f) fails W-1..W-4, or any alternative is held | HOLD-U |
| SEP-AV-6 | a component is both SUPPLIED and NACR-declared on the same record | HOLD-NA (contradiction) |

### 4.6 Reason taxonomy (gate order)

`SOURCE_CONTENT_INACCESSIBLE` (EV-1) · `MECHANISM_READING_AMBIGUOUS` (EV-2) · `COMPONENT_NOT_ASSESSABLE` (EV-3) · `TARGET_BINDING_UNRESOLVED` (EV-4). No generic UNKNOWN bucket exists.

---

## 5. AXIS 2 — BEARING PROCEDURE (ordered; first rule that fires decides; admissible EVALUABLE records only)

- **SEP-B-1a — DE-4 cap (Owner Decision 3).** `evidenceForm = DE-4` ∧ the C34 §6 constitutive exception NOT AVAILABLE for the TT → `NON_DISCRIMINATING`. Under the cap a DE-4 record needs no T(r) and no W(f) (B-3/SEP-U are not reached). The cap binds in every direction; it sets or alters no edgeState, formalOperativeState, planCurrentState, characteristicityState, leaf value, sufficiencyExpressionResult or targetState.
- **SEP-B-1b — Prohibited-criterion cap (Class A).** The edge's only basis is a criterion in the TT row's `prohib` → `NON_DISCRIMINATING`.
- **SEP-B-2 — Counter.** `relation ∈ {NEGATES_LEAF, COUNTER_M}` → `DIRECT_CONTRADICTION` iff (i) NEGATES_LEAF with `absenceEvidenceState = COMPETENT_AFFIRMATIVE_ABSENCE` at matched scope/time for a leaf M of the TT, or (ii) COUNTER_M with a registry-listed incompatible counter of a leaf M deciding the same organizational question at matched scope/time, **and** the counter content DIRECTIONAL under SEP-B-3; otherwise `NON_DISCRIMINATING`. DIRECT_CONTRADICTION never by itself makes a leaf FALSE or CONFLICTED; only §F.3/§F.5 do that.
- **SEP-B-3 — Directionality (operationalized).** Applies when `relation = SUPPORTS_LEAF` (and to counter content under B-2(ii)). B3-1 comparator universe: `Cmp(M) = { M′ ≠ M : Env(M′) ≠ Env(M) ∧ ( Dset(M′) ∩ Dset(M) ≠ ∅ ∨ M′ named in M's alt/counter cell or the reverse ) }` (mechanical; over-inclusion is fail-closed); record part `Cmp⁺(r) = Cmp(M) ∪ Sel_other(f)`. B3-2 component correspondence by recorded basis entailment (never by ID). B3-3 MD-1 (supply, existing H-3 judgment), MD-2 (bounded negative test against `explicitNonMeaning`; sufficient negative check only), MD-3 (per-M′ disposition: NO_CO_ENTAILMENT / CO_ENTAILS c′ / UNRESOLVED). Verdicts: c DISTINGUISHING iff MD-2 NOT_TRIGGERED ∧ every MD-3 NO_CO_ENTAILMENT; record DIRECTIONAL iff ≥1 supplied component DISTINGUISHING. B3-6 fail-closed: UNRESOLVED → NON_DISTINGUISHING; incomplete trace → HOLD-T, never DIRECTIONAL; a fully supplied M still needs a DISTINGUISHING component (SEP-FW-22); the deleted mechanical shortcuts are not restored. B3-7: the parent's "mechanical sufficient condition for DIRECTIONAL" is deleted; MD-2 is judgment.
- **SEP-B-4 / SEP-U — Uniqueness (Owner Decision 4).** DIRECTIONAL SUPPORTS_LEAF records only. `Alt(r)` = all SUPPORTS_LEAF records r′ of f in the same coder output with M′ SELECTED in W(f) and Env(M′) ≠ X (E-R7 competitors included; counter-relation records are not alternatives). Alternative status taken over its records: DIRECTIONAL (any record EVALUABLE, uncapped, DIRECTIONAL) → else INDETERMINATE (any record INDETERMINATE) → else HELD → else NON_DIRECTIONAL.

| ID | Condition | Result | Basis |
|---|---|---|---|
| SEP-U-X | W(f) fails W-1..W-4, or any alternative HELD | **HOLD-U** (defect; never DIRECT) | INCOMPLETE_ENUMERATION |
| SEP-U-2 | ≥1 alternative DIRECTIONAL | `SHARED_NON_UNIQUE` | PROVEN_DIRECTIONAL_ALTERNATIVE |
| SEP-U-3 | none DIRECTIONAL ∧ ≥1 INDETERMINATE | **UNIQUENESS_UNRESOLVED**: EVALUABLE, `bearingIndeterminacyReasons = null`, `supportBearing = null`, X's DIRECTIONAL trace retained, uniqueness basis `UNIQUENESS_UNRESOLVED`, the INDETERMINATE alternatives listed; no DIRECT, no SHARED; materializable truthful terminal state; recomputed by S7 whenever an alternative's evaluability or directionality changes | UNIQUENESS_UNRESOLVED |
| SEP-U-0 | Alt(r) = ∅ | `DIRECT_SUPPORT` | ZERO_ALTERNATIVES |
| SEP-U-1 | every alternative NON_DIRECTIONAL | `DIRECT_SUPPORT` | SOLE_DIRECTIONAL_TARGET |

SEP-FW-26: UNIQUENESS_UNRESOLVED ⇏ SHARED, DIRECT, any direction for the unresolved alternative; an INDETERMINATE alternative ⇏ positive evidence for that alternative. SEP-FW-27: a null `supportBearing` on an EVALUABLE record ⇏ NON_DISCRIMINATING. O-1(g): SHARED never separates. O-1(j): UNIQUENESS_UNRESOLVED is non-establishing and non-separating; a consumer may report it only as "directional for X; uniqueness unresolved".

### 5.1 Evaluation order — state machine

```text
S0  INPUT    r; bound R (incl. SEP-NACR, registry identity); K; W(f); T(r); r.abstention.
S1  APPLY    SEP-EV-0. Not applicable → (null, null, null); STOP.
S2  ADMIT    SEP-AV-1, AV-2, AV-3, AV-6 over ADMISSION_INPUT_SIGNATURE. Fail → HOLD; STOP.
             Compute PART(r, c) for every required component.
S3  GATES    F := failing gates among EV-1..EV-4. Reads EXACTLY EV_INPUT_SIGNATURE:
             no edgeState, no bearing output, no W, no T.
S4  INDET    F ≠ ∅ → (INDETERMINATE, F, null); STOP.
S5  EVAL     EVALUABLE; reasons null.
S6  PASS-1   B-1a | B-1b | B-2 | B-3.
S7  PASS-2   DIRECTIONAL SUPPORTS_LEAF only: AV-5, then SEP-U-X / U-2 / U-3 / U-0 / U-1
             → HOLD-U | SHARED_NON_UNIQUE | UNIQUENESS_UNRESOLVED (bearing null) | DIRECT_SUPPORT.
S8  OUTPUT   triple, plus the T(r) uniqueness basis. §F.3/§F.5 unchanged; consumers bound by O-1(a)–(j).
```

The graph S2 → S3 → S6 → S7 is acyclic; S7 reads the S4/S6 outcomes of *other* records only; W(f), T(r) and `abstention` are coder-produced inputs, never derived from a bearing output.

---

## 6. MIGRATION (SEP-MIG; projection only; never a write into a legacy artifact)

| ID | Legacy condition | Successor projection | Kind |
|---|---|---|---|
| SEP-MIG-0 | any | No legacy artifact is rewritten. Projections exist only in a new, separately authorized successor artifact, with a per-record ledger: legacy value and provenance, successor triple, rule ID, hold code if any, inputs read, registry and contract identity | rule |
| SEP-MIG-1 | `relevanceState ≠ ANALYTICAL_MAPPED` | (null, null, null) | MECHANICAL |
| SEP-MIG-2 | any ANALYTICAL_MAPPED record | EV recomputed from the record's own states. No NACR clause on the M: EV-3 mechanical PASS when legacy `abstention` is null, `declared:false`, or declares only an establishment-side reason. NACR clause on the M with clause component unsupplied: mechanical only if the legacy declaration cites §G-7 or the clause; else RECOMPUTE. EV-1/EV-2/EV-4 mechanical from recorded states and the registry. Admission defects → RECOMPUTE | MECHANICAL where stated |
| SEP-MIG-3 | legacy NOT_DETERMINABLE ∧ ≥1 EV gate fails mechanically | (INDETERMINATE, failing gates, null) | MECHANICAL |
| SEP-MIG-4 | legacy NOT_DETERMINABLE ∧ EVALUABLE | Bearing by S6–S7. MECHANICAL only if B-1a fires (SEP-DE4) or B-2 fails mechanically on recorded counter states. Otherwise RECOMPUTE / RE-ADJUDICATION; DIRECT or SHARED additionally need T(r) and W(f). The legacy label is never carried | mixed |
| ~~SEP-MIG-5~~ | — | **DELETED** (IV1-F05) | — |
| SEP-MIG-5A | legacy ND ∧ EVALUABLE ∧ a successor cap fires on recorded states | (EVALUABLE, null, NON_DISCRIMINATING); legacy value in the ledger. The cap is B-1a (SEP-DE4) or B-1b only where the PR basis is recorded | MECHANICAL (conditional) |
| SEP-MIG-5B | legacy ND ∧ EVALUABLE ∧ successor nondirectionality independently established from bound inputs (a B-2 counter record that mechanically fails lawful-counter conditions, or a complete successor T(r) with NON_DIRECTIONAL verdict) | (EVALUABLE, null, NON_DISCRIMINATING) | MECHANICAL |
| SEP-MIG-5C | legacy ND ∧ EVALUABLE ∧ neither 5A nor 5B | RECOMPUTE / FIELD-LOCAL RE-ADJUDICATION. Label agreement is insufficient | judgment |
| SEP-MIG-6a | legacy DIRECT / SHARED / CONTRA ∧ EVALUABLE ∧ cap fires | (EVALUABLE, null, NON_DISCRIMINATING); value change | MECHANICAL (conditional on SEP-DE4 for B-1a) |
| ~~SEP-MIG-6b~~ | — | **DELETED** (inherited the deleted B-3 shortcut and the B-4 completeness defect) | — |
| SEP-MIG-6c | legacy DIRECT / SHARED / CONTRA ∧ EVALUABLE ∧ no cap | RECOMPUTE / RE-ADJUDICATION (needs T(r), and W(f) for DIRECT/SHARED) | judgment |
| SEP-MIG-7 | any other legacy label ∧ ≥1 EV gate fails | (INDETERMINATE, failing gates, null); legacy label in the ledger only | MECHANICAL |
| SEP-MIG-8 | legacy multi-TT row | split per TT; then MIG-1..7 per copy | MECHANICAL |

Mechanical migration and semantic re-adjudication remain separate classes. Any record that cannot be mechanically migrated remains explicitly unresolved / re-adjudication-required. No legacy label is silently coerced into a successor bearing. No record count or majority logic manufactures uniqueness. Every projected value identifies the migration rule that produced it. The six preservation classes are distinct: mechanical preservation; mechanical value change; recompute; re-adjudication; HOLD; uniqueness unresolved.

### 6.1 Census evidence to reproduce (never hard-code)

Section-I records = 6; execution cells = 110; candidate mechanical projections = 5; re-adjudication = 1; candidate value changes = 3; historical mapped (byte-deduplicated) = 122; historical DE-4 mechanical projections = 68; historical recompute = 54; supportClass record objects = 377; normalized walk = 2082. These counts are recomputed from the physical inputs by this implementation's validator (V-53); the derivation method (roots, extensions, non-JSON-content exclusion, package-own-output exclusion, homonym/quotation exclusions, mapped predicate, byte-deduplication) is bound in the migration contract.

---

## 7. BACKWARD COMPATIBILITY AND FIREWALLS

- **SEP-BC-1** Legacy records carrying `supportClass` are read under the predecessor §E import and their own contract identity. **SEP-BC-2** Successor records write the three SEP fields, an `abstention` value under §4.4 codes and, where required, companion W(f)/T(r); they never write `supportClass`. **SEP-BC-3** `supportClass` is deprecated for writing; `NOT_DETERMINABLE` deprecated as a bearing value only. **SEP-BC-5** Exactly three new record fields; a closed abstention code list; two companion artifacts; no score/weight/rationale field is added to the §I record. **SEP-BC-6** The adapter is read-only; historical data mutation required = NO. **SEP-BC-8** No consumer combines `supportClass` and `supportBearing` without SEP-MIG.
- **SEP-FW** (selected load-bearing): FW-3 missing content is not negative evidence; FW-4 derived target states never feed per-edge EV; FW-5/6 PLAN/FORMAL_ONLY/planCurrent/characteristicity have no bearing meaning; FW-20 establishment determinations have no EV effect; FW-22 full supply ≠ DIRECTIONAL; FW-23 explicitNonMeaning silence never establishes distinguishing content; FW-26/27 (U-3, §5 above).
- **O-1 minimum future-consumer obligation** (deferred; no HEDC authored here): (a) bearing never establishes; (b) DIRECT/SHARED contribute to separation only with the qualified establishing witness (§2.3); (c) a completed ANY_OF sibling never establishes another branch's content; (d) DIRECT_CONTRADICTION only with lawful negative/counter establishment; (e) srcDiv, PRES-lane non-consumability, actual-alternative exclusion, contradiction review and CASE-1 §18 A–H preserved; (f) INDETERMINATE and held records are non-establishing, non-separating, non-contradicting; (g) SHARED never separates; (h) legacy supportClass read only through SEP-MIG; (i) partial directional bearing alone is non-sufficient for Environment determination; (j) UNIQUENESS_UNRESOLVED non-establishing, non-separating.

---

## 8. A-E023 AND A-E001

**A-E023 (F-M-0205 × M-RES-CAPABILITY-ADVANTAGE × TT-NTSTJ-RS).** Fixed accepted relevant inputs: planCurrentState PLAN; evidenceForm DE-4; formalOperativeState FORMAL_ONLY; edgeState PARTIAL; missingComponents [c2, c3, c4]; sufficiencyExpressionResult OPEN. Required successor result, produced by this implementation **through the general DE-4 migration path only** (no A-E023-specific exception exists in the machinery): admission clean (no NACR clause on the M; abstention null; no AV-6 conflict; PARTIAL triggers no hold); PART = c1 SUPPLIED, c2/c3/c4 ORDINARY_MISSING_ASSESSABLE; EV-1..EV-4 pass → `bearingEvaluability = EVALUABLE`, `bearingIndeterminacyReasons = null`; B-1a → `supportBearing = NON_DISCRIMINATING` (constitutive exception NOT AVAILABLE). U-3 is never reached. The physical row in `a1fcae68…` is unchanged; the projection is a candidate successor projection in the migration ledger (MIG-6a; value change), not a materialized controlling value. All three DE-4 encodings (stale physical row; fixed inputs; five-RC lane A row) give the same projection because B-1a reads only evidenceForm once EV and admission pass.

**A-E001 — HARD STOP.** `A_E001_REQUIRES_READJUDICATION = YES`. Its componentSupply / missingComponents inconsistency (`edgeState = SUPPORTED`, `missingComponents = []`, componentSupply only c1 of M-ENFORCE-SANCTION {c1, c2}) is establishment-side, outside EV, and requires a later, separately Owner-authorized semantic re-adjudication act (assigned to Claude). This implementation: preserves A-E001 as requiring re-adjudication; routes it deterministically to the lawful successor unresolved / re-adjudication state (MIG-6c); retains all predecessor provenance required for the later act; does NOT guess a supportBearing; does NOT repair its semantic content; does NOT infer a result from A-E023; does NOT use old supportClass as the answer. Any implementation path that silently turns A-E001 into a final successor bearing is a FAIL.

---

## 9. ENVIRONMENT-MATH PRESERVATION GATE (verbatim, controlling)

```text
ENVIRONMENT-MATH PRESERVATION GATE

Root Definitional/E9 unchanged → Stage-2 measures inputs only → no Environment assignment before frozen determination contract → ECS only after two lawful Environment determinations.
```

Therefore this act produces no Environment assignment, candidate Environment, Environment ranking, HEDC, RULE FREEZE, 905-fact / 18-side replay, Pair, ECS or friction. Directional bearing is not Environment establishment. `ENVIRONMENT_OUTCOME_PRESERVATION = NOT_YET_PROVEN` and is not claimed here.

---

## 10. SUPERSESSION MAP AND WHAT IS *NOT* CLAIMED

### 10.1 Supersession map

| Predecessor surface (identity) | Status under this successor |
|---|---|
| §E `supportClass` row + §H-8 sentence (inside `cb08b51e…`) | Legacy representation; superseded for **writing** by Architecture C; readable via SEP-BC-1/SEP-MIG |
| Predecessor coder-view schema `0cb5a6b5…` | Unmutated; successor schema derived from it (separate artifact) |
| Predecessor field-source matrix `1fb84aed…` | Unmutated; successor matrix derived from it (separate artifact) |
| Controlling effective view `a1fcae68…` | IMMUTABLE controlling predecessor input; stays controlling until a separately authorized, verified and accepted successor view |
| CORR1 §6.4 precedence rule | DELETED (replaced by PART + AV-6) |
| CORR1 §9.5 SEP-U-3 (SHARED for unresolved alternative) | SUPERSEDED by the Owner-accepted U-3: UNIQUENESS_UNRESOLVED, proven sharing only |
| SEP-MIG-5, SEP-MIG-6b | DELETED |
| Parent "mechanical sufficient condition for DIRECTIONAL" | DELETED (SEP-FW-22) |
| CASE-1 §13–§15, §22; C34 §5–§16; Root Definitional/E9 | Physically unchanged; successor readings per SEP-SD-1..SD-5 |

Non-superseded Stage-2 semantics of `cb08b51e…` remain in force: this successor changes only the supportClass/bearing representation surface described here, through the migration layer.

### 10.2 Not claimed by this implementation

- Final Effective View closed — NO (forbidden; §16 of the brief).
- Final Stage-2 Measurement Regression run or closed — NO (forbidden; §17).
- Environment determination implemented, HEDC authored, Pair or ECS produced — NO (§18).
- Independent verification — NO (Codex will perform IMPLEMENTATION-1.IV1 as a separate act).
- Owner acceptance — NO.
- Git closure — NO (Antigravity, separate act).
- Any change to report-product semantics, Mode-D semantics, package dependencies, Root Definitional / E9 — NO.

```text
IMPLEMENTED              = YES
SELF_VALIDATED           = YES
INDEPENDENTLY_VERIFIED   = NO
OWNER_ACCEPTED           = NO
A_E001_REQUIRES_READJUDICATION = YES
ENVIRONMENT_ASSIGNMENT_PERFORMED = false
GIT_MUTATION_PERFORMED   = false
```
