# STAGE2_FINAL_MEASUREMENT_REGRESSION_1_CORRECTION_1_REPORT

Terminal: `STAGE2_FINAL_MEASUREMENT_REGRESSION_1_CORRECTION_1_READY_FOR_IV`

This is an author correction candidate. It has not been independently verified, the Owner has not accepted it, and it does not control. The predecessor effective view `a1fcae68…` stays controlling until a fresh non-author verifier and a separate Owner acceptance.

Actor: Claude Opus 5.5 (`claude-opus-5-5`). Role: CODER, Owner-assigned for this act. Specialization: Stage-2 effective-view measurement-consistency correction author. Date: 2026-10-05.

## Required terminal summary

```
REG001 = CLOSED_CANDIDATE
REG002 = CLOSED_CANDIDATE
REG003 = CLOSED_CANDIDATE
REG004 = CLOSED_CANDIDATE
REG005 = CLOSED_CANDIDATE
REG006 = CLOSED_CANDIDATE
REG007 = CLOSED_CANDIDATE
REG008 = CLOSED_CANDIDATE

REG009 = PRESERVED_ADVISORY
REG010 = PRESERVED_ADVISORY

PREVIOUS_DETERMINISTIC_MISMATCHES_REMAINING = 0

HISTORICAL_PACKAGE_MUTATED = NO
PREDECESSOR_EFFECTIVE_VIEW_MUTATED = NO
METHODOLOGY_MUTATED = NO
FB0025_SOURCE_QUALITY_CHANGED = NO
NEW_ANALYTICAL_JUDGMENTS = 0
ENVIRONMENT_MATH_PRESERVED = YES

SUCCESSOR_EFFECTIVE_VIEW_SHA256 =
3737bd5d5aa3b92f7f737fb6b35170ae35e936c2541d8b6fe053f8cb88a816c5

TERMINAL:
STAGE2_FINAL_MEASUREMENT_REGRESSION_1_CORRECTION_1_READY_FOR_IV
```

## 1. Role and authorization

The current explicit Owner instruction appoints Claude Opus 5.5 as CODER for this act. `AGENTS_C.md` lists Grok, Z-Ai and Codex as eligible Coder actors. Under `AGENTS.md` §3, a current explicit Owner instruction ranks first, and only the Owner changes role assignments. I followed the Owner's assignment and did not infer the role. I record the eligibility-list divergence here.

Independence: Codex authored the failed regression. Claude did not author it. This package is Claude-authored, so Claude cannot be its independent verifier.

## 2. Root and write surface

- Authorized root: `/Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)`. HEAD `2567223087d99b40bdfd174eed32566be7080e44` on `main`, read from `.git/HEAD` and `.git/refs/heads/main`.
- Output directory: `WORKBENCH/DOWNLOADS/STAGE2_FINAL_MEASUREMENT_REGRESSION_1_CORRECTION_1_2026-10-05/`. It did not exist before the act. The parents are not symlinks, and the directory sits inside the root.
- Files written: exactly the four required outputs.

## 3. Inputs (identities verified before and after)

| Input | SHA-256 | Bytes |
|---|---|---|
| Predecessor effective view `STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_RECORDS.jsonl` (116 records) | `a1fcae68939decd0a3c4a39c0a0bc48e8d285bd9cd7ce1928b0d025056244047` | 104310 |
| Methodology `STAGE2_PD3_ROLE_BOUNDED_ENTITLEMENT_CLARIFICATION_1_CORR1_CANDIDATE.md` | `cb08b51e1c2fbaec7765989a7a4e15db1788c53eb5fec43f2628ecb88c1d6c73` | 344754 |
| Regression REPORT | `9a58d387…f5f2c3` | 23332 |
| Regression RESULTS | `fe252b71…49a855` | 276802 |
| Regression FINDINGS | `6ae86657…f7cb758` | 108654 |
| Regression MANIFEST | `0e97785c…b9730ee88f` | 26757 |

Supporting frozen authorities consumed: PI-7 sourceClass binding CORR2, provenance sidecar CORR1, the 30-fact pilot input, field-source matrix CORR2, the three Owner-accepted overlays, and the historical Execution-1 Lane-A base. Each matches the hash that the regression manifest recorded as consumed. I also bound three surfaces the regression did not list: the coder-view schema successor `…CORR2_CORR1_CORR2_CORR1.json`, the Execution-1 A/B comparison, and census CORR1. Exact hashes are in the correction JSON and the MANIFEST.

## 4. Phase A — independent determination

I recomputed the deterministic surfaces with my own builder, written from the methodology. It does not reuse the regression harness. The registry parse gave 74 M, 62 TT and 13 D.

The recomputation found exactly 19 value mismatches plus 6 structural `componentSupply` mismatches. Its locator agreement with Codex's 19 is: 0 only in Codex, 0 only in mine, and 0 recomputed-value disagreements.

| Finding | Verdict | Deterministic basis (controlling rule → value) |
|---|---|---|
| REG-001 | CONFIRMED_DETERMINISTIC | Line 112's `factualPackageIdentity` is replaced with the frozen sidecar F0024 identity, which also equals cell 51 (the accepted overlay). Exactly 4 leaves change: bytes 139589→61728; SHA `4b686b24…`→`88b20920…5f10`; facts 105→50; locator package-level→record-level `case_id`. The 13 other keys and the key order are unchanged. The physical Stage-1 file independently hashes to 61728 / `88b20920…` / 50 facts. |
| REG-002 | CONFIRMED_DETERMINISTIC | C.0 C-1/C-2: the emitted set is the union of the selected M's §D-row D field. M-RECOGNISED-COMMAND-ORDER→D-04 (F-E-0182 ×2), M-ENFORCE-SANCTION→D-06 (A-E001), M-RES-CAPABILITY-ADVANTAGE→D-07 (A-E023). |
| REG-003 | CONFIRMED_DETERMINISTIC | Per §I, `sufficiencyExpression` is copied from the TT row `mechExpr`. All 4 stored expressions were stale; they held six leaves outside the 74-M registry. Every leaf in the new expressions is in the registry. Results were recomputed under F.3/F.5. All six edges are OPEN, and only A-E001 and A-E023 change (TRUE→OPEN). |
| REG-004 | CONFIRMED_DETERMINISTIC | H-3 complement of the physically recorded supply (c1 only) against the §D requiredComponents: A-E001 gives `[c2]` and A-E023 gives `[c2,c3,c4]`. H-7 makes both PARTIAL. |
| REG-005 | CONFIRMED_DETERMINISTIC | TT scope is SC-CLAIM. unit<enterprise and program<enterprise, and `scopeBridgeFactIds=[]`, so both become `UNRESOLVED_FAIL_CLOSED`. |
| REG-006 | CONFIRMED_DETERMINISTIC | PI-7 `sectionIFill` for C-B04/C33-S01 and F-M-0205/S-M1 is `OUTSIDE_FROZEN_VOCABULARY`. The stored values were documentaryType copies, which R-FORM forbids. |
| REG-007 | CONFIRMED_DETERMINISTIC | Each nested value is copied from the same record or bound by an explicit rule; see §5. |
| REG-008 | CONFIRMED_DETERMINISTIC | A-E023 keeps PLAN / DE-4 / FORMAL_ONLY. Under E (DE-4 cannot establish OP), the FO-OP and CUR conjuncts, the temporal and scope conjuncts, and H-7 PARTIAL, the leaf is OPEN and the expression is OPEN. `supportClass` DIRECT_SUPPORT is kept because no deterministic reassignment rule exists (H-8). |
| REG-009 | PRESERVED_ADVISORY | No NOT_DETERMINABLE field was filled. |
| REG-010 | PRESERVED_ADVISORY | Git state was recorded read-only. Nothing was reset or repaired. |

Per-edge F.3 gate failures, independent of characteristicity:

- RC-1 rows and F-E-0182 ×2: PARTIAL, temporal UNRESOLVED, FORMAL_ONLY, and plan state not CURRENT.
- A-E001: PARTIAL, scope UNRESOLVED and temporal UNRESOLVED.
- A-E023: PARTIAL, scope UNRESOLVED, temporal UNRESOLVED, FORMAL_ONLY and PLAN.

No edge in the view sits on the same side and target as another edge, so every sibling leaf is OPEN (E-R5) and never FALSE.

## 5. REG-007 — nested `componentSupply` authority

§I and both coder-view schema successors define the entry identically, character for character:

`{mechanismPropositionId, componentId, factIds[], relationInstanceId, organizationalObjectRef, linkageEvidence{class ∈ L-1..L-6 | NO_LAWFUL_LINKAGE, identifier}}`

§I also says there is "no copy of fact text beyond the fact IDs".

| Nested key | Value | Authority |
|---|---|---|
| mechanismPropositionId | the record's single `mechanismPropositionIds` member | §I; component ids are unique inside their M |
| componentId | existing `c1` (preserved) | recorded value |
| factIds | the record's single `factIds` member | H-5; each edge has exactly one fact and one sourceRef |
| relationInstanceId | the record's single `relationInstanceId`, unique across the view | J-R2 |
| organizationalObjectRef | the record's `organizationalObjectRef` | J-R3 |
| linkageEvidence | `{class: NO_LAWFUL_LINKAGE, identifier: null}` | Two independent grounds, below |

The two grounds for `linkageEvidence`:

1. **J-R7.** None of the four selected M rows declares REL-WITNESS, so the class is recorded as NO_LAWFUL_LINKAGE without running an F.4.1 test.
2. **F.4.1 cardinality.** Every class L-1..L-6 relates two or more records or facts. Each relationInstance here has exactly one fact, so the result is UNRESOLVED, recorded as NO_LAWFUL_LINKAGE. The identifier is null because no linkage record exists to identify.

**Reading invariance.** J-R7 can be read at the M row or at the TT row. All five consuming TT rows declare REL-WITNESS, and census CORR1 treats the outer join fields as TT-binding.

The chosen nested values are lawful under both readings:

- **TT reading:** each component binds to its edge's relationInstance, and no L-class can be instantiated.
- **M reading:** NO_LAWFUL_LINKAGE is mandated, and a non-null relationInstanceId or object reference is "voluntary metadata with no effect".

The alternative, nested `null`/`null` (Lane-B form), is lawful only under the M reading. It would also drop the Lane-A object binding at component level.

The outer join fields were **not** changed. The census ADV-2 outer A/B join divergence is **not** adjudicated. Under either reading, no edge state, leaf or result changes.

Removed legacy keys: `status`, the string `linkageEvidence` (near-verbatim fact text) and `entailmentBasis`. None of them is a §I field. Their exact old values are preserved verbatim in the ledger `oldValue` and in the byte-identical predecessor. Traceability gains typed fact, M and relation linkage.

The same corrected array was written to execution-cell carriers 9 and 56, so each cell now equals its SECTION_I consumer.

`REG007_NOT_DETERMINISTIC` did not arise.

## 6. Successor materialisation

| Metric | Value |
|---|---|
| Path | `STAGE2_EFFECTIVE_VIEW_MEASUREMENT_CORR1_RECORDS.jsonl` |
| SUCCESSOR_EFFECTIVE_VIEW_SHA256 | `3737bd5d5aa3b92f7f737fb6b35170ae35e936c2541d8b6fe053f8cb88a816c5` |
| SUCCESSOR_EFFECTIVE_VIEW_BYTES | 104402 |
| Records | 116 (order and semantic identities preserved) |
| CHANGED_RECORDS | 8 (lines 9, 56, 111, 112, 113, 114, 115, 116) |
| CHANGED_FIELD_PATHS | 27 |
| TOTAL_LEAF_DIFFS | 96 (CHANGED 20, ADDED 52, REMOVED 24) |
| UNEXPECTED_DIFFS | 0 |

How the leaf diffs break down:

- 20 CHANGED:
  - 4 for F0024 provenance;
  - 4 for discriminators;
  - 4 for expressions;
  - 8 for the edgeState, scopeBridgeState, sourceClass and result values on A-E001 and A-E023.
- 52 ADDED:
  - 48 from 8 carriers × 6 typed leaves;
  - 4 from the added `missingComponents` entries.
- 24 REMOVED: 8 carriers × 3 legacy keys.

Serialization follows the assembly contract §8 rule. The 108 unchanged lines are emitted as predecessor bytes verbatim. The output is pure ASCII with LF endings and exactly one trailing newline. The outer key order is preserved.

### The 19 previous deterministic mismatches (old → new)

| # | Edge | Field | Old | New |
|---|---|---|---|---|
| 1 | F0024 | factualPackageIdentity | 139589 / `4b686b24…` / 105 / package-level | 61728 / `88b20920…` / 50 / record-level |
| 2 | F-E-0182 ESS | discriminatorIds | [D-01] | [D-04] |
| 3 | F-E-0182 PW | discriminatorIds | [D-01] | [D-04] |
| 4 | A-E001 | discriminatorIds | [D-02] | [D-06] |
| 5 | A-E023 | discriminatorIds | [D-06] | [D-07] |
| 6 | F-E-0182 ESS | sufficiencyExpression | ALL_OF(…COMMAND-ORDER, DISCIPLINARY-ESCALATION, SUPERVISORY-DIRECT-AUDIT) | TT-STPSTJ-ESS mechExpr (5 leaves) |
| 7 | F-E-0182 PW | sufficiencyExpression | ALL_OF(…COMMAND-ORDER, FORMAL-PROCEDURAL-APPEAL, SANCTION-SYSTEM-AUDIT) | TT-STPSTJ-PW mechExpr (4 leaves) |
| 8 | A-E001 | sufficiencyExpression | ALL_OF(M-ENFORCE-SANCTION, M-FORMAL-RULES) | TT-STJSTP-PW mechExpr (4 leaves) |
| 9 | A-E023 | sufficiencyExpression | ALL_OF(M-RES-CAPABILITY-ADVANTAGE, M-MARKET-POSITIONING) | TT-NTSTJ-RS mechExpr (2 leaves) |
| 10–14 | A-E001 | missingComponents / scopeBridgeState / sourceClass / edgeState / result | [] / NOT_REQUIRED / PERIODICAL_PRINT_ARCHIVE / SUPPORTED / TRUE | [c2] / UNRESOLVED_FAIL_CLOSED / OUTSIDE_FROZEN_VOCABULARY / PARTIAL / OPEN |
| 15–19 | A-E023 | same five fields | [] / NOT_REQUIRED / FORM_10K / SUPPORTED / TRUE | [c2,c3,c4] / UNRESOLVED_FAIL_CLOSED / OUTSIDE_FROZEN_VOCABULARY / PARTIAL / OPEN |

The full ledger is in the correction JSON (`derivationLedger`, 27 entries). Each entry records semantic identity, path, old and new values, the controlling rule, the source authority and the derivation type, and states `NEW_ANALYTICAL_JUDGMENT = NO`.

## 7. Author self-check (re-parsed from the written successor)

```
F0024_SECTION_I_PROVENANCE_CONSISTENT = YES
DISCRIMINATOR_BINDINGS = PASS
SUFFICIENCY_EXPRESSIONS = PASS
COMPONENT_COVERAGE = PASS
SCOPE_BRIDGE_STATES = PASS
SOURCE_CLASS_BINDINGS = PASS
COMPONENTSUPPLY_SCHEMA = PASS
SECTION_I_COMPONENTSUPPLY_SCHEMA_ERRORS = 0
EXECUTION_CELL_COMPONENTSUPPLY_SCHEMA_ERRORS = 0
A_E023_DOWNSTREAM_CONSISTENCY = PASS
PREVIOUS_DETERMINISTIC_MISMATCHES_REMAINING = 0
ALL_SECTION_I_RECOMPUTED_SURFACES_MISMATCHES_REMAINING = 0
CELL_TO_SECTION_I_CARRIER_DIVERGENCES = 0
FIREWALL_VIOLATIONS = 0
SUPPORTCLASS_CHANGED = NO
UNCHANGED_LINES_BYTE_IDENTICAL = YES
```

The builder runs Phase A first. It writes nothing unless every gate passes. Two dry runs and the build produced the same successor SHA. The self-check zeros come from author-written checks. They are not independent proof, and the final regression was not re-run.

## 8. Firewalls

- **F-B-0025:** `sourceQualityState` is COMPETENT on line 111 and on cell 35 before and after. Only the line-111 / cell-9 `componentSupply` shape changed (REG-007). The UNADJUDICATED governance disagreement is not adjudicated.
- **Accepted values preserved:**
  - A-E023: PLAN / DE-4 / FORMAL_ONLY.
  - A-E001: DE-1 / CURRENT.
  - F-E-0182: P-D3 NOT_DETERMINABLE and FORMAL_ONLY.
  - Characteristicity, temporal and relevance values.
  - `supportClass` on every edge.
  - Counter and conflict arrays.
  - Outer join fields, `nonExpansionRationale` and fact identity.
- **Environment math:**
  - No Environment was assigned, inferred, ranked or scored.
  - No U-7, OM-1, MD-2 Φ, D2-10, HEDC, RULE FREEZE or 905 / 18-side replay was performed.
  - No Pair, ECS or friction was computed.
  - The successor contains 0 Environment or score fields.
- **Immutability:**
  - The WORKBENCH/DOWNLOADS tree, excluding this output directory (461 files), has the digest `1444be1a…` before and after.
  - Root-definitional v1.7 plus E9 corr3 (35 files) has the digest `6b29eeaa…` before and after.
  - The predecessor, methodology, historical Execution-1, overlays and regression package are unchanged.

## 9. Out-of-scope observations (recorded, not acted on)

1. **Recorded supply versus entailment.** REG-004 complements reflect *recorded* supply only. Whether C-B04 entails M-ENFORCE-SANCTION c2, or F-M-0205 entails M-RES-CAPABILITY-ADVANTAGE c2–c4, is an H-3 entailment judgment that I did not make. A bounded analytical re-test would be a separate act. Results stay OPEN under either answer, because the temporal and scope gates fail independently.
2. **Census ADV-2.** The outer A/B join divergence (Lane A non-null versus Lane B null) remains unadjudicated. This act left the outer join fields untouched.
3. **Schema succession.** The regression consumed coder-view schema `…CORR2_CORR1.json` (`0d08c7e1…`). The later successor `…CORR2_CORR1_CORR2_CORR1.json` (`0cb5a6b5…`) declares itself the single controlling execution view. The `componentSupply` definition is character-identical in both and in methodology §I, so this act is unaffected. The verifier may want to confirm which view binds.
4. **Coder rationale prose.** After REG-007, `entailmentBasis` prose lives only in history and in this ledger. Carrying coder rationale inside the effective view would need a §M schema decision.

## 10. Deviations

- Before loading the Coder mandate, my session-start root identification ran three read-only git commands: `git rev-parse --show-toplevel`, `git rev-parse HEAD` and `git status --porcelain`. `.git/index` mtime stayed 2026-10-02, so the index was not rewritten. No other git command ran, and the builder reads `.git` files only.
- At 2026-10-05T11:38:40-03:00, FETCH_HEAD, `refs/remotes/origin/HEAD` and its reflog showed another update after the regression's observation. The FETCH_HEAD content hash is unchanged and the reflog grew. This is consistent with host-side background fetch (inference). It is recorded in REG-010 and not repaired.
- The builder ran from a scratch directory outside the repository. It is not a project artifact. Its full source (SHA `d0bf877c…`) and Phase-A text are embedded in the correction JSON for replay with `--dry-run`. I deleted the scratch directory after the manifest.
- To learn its nested-key check, I read the regression harness source embedded in RESULTS, using a temporary extraction outside the repository that I then deleted. I did not use it as an oracle, and I did not re-run the regression.

## 11. Status and stopping point

| Item | State |
|---|---|
| ownerAccepted | false |
| independentlyVerified | false |
| controlling | false |
| Git | not closed |

The correction JSON SHA-256 is `b7c26c16e2c383be256e96ff425e29c97a37f92b72ccb8be85e54d2822d9d1dd`. The MANIFEST binds all package members.

STOP. I did not run the final regression again, perform IV, or take any Git or deployment action.
