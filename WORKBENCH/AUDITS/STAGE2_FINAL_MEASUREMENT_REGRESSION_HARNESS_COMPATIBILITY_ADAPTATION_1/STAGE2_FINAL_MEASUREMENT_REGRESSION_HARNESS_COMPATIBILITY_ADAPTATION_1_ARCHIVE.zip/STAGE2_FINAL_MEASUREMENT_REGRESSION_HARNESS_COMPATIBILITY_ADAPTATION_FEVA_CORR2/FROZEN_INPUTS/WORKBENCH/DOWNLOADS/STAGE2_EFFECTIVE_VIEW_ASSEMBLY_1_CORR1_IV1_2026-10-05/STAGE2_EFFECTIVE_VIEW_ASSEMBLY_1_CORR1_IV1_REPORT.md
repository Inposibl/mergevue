# STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_IV1_REPORT

**VERDICT: PASS — BLOCKING 0 / MAJOR 0 / MINOR 1.**

The CORR1 contract and effective dataset are byte-identical to the predecessor. Independent in-memory reconstruction from the four pinned inputs produces the exact 104,310-byte effective dataset in all six overlay permutations. The proof has exactly five allowed change locations and no unexpected differences. One inherited firewall wording defect is disclosed below; it does not change the assembled dataset or resolve the F-B-0025 disagreement.

## 1. Role, authority, scope and stopping point

- Actor: Codex. Active project role: AUDITOR. Owner task specialization: INDEPENDENT EFFECTIVE-VIEW ASSEMBLY AUDITOR.
- Mode: read-only independent verification, with writes limited to the three explicitly requested IV files.
- Authority: current Owner attachment `/Users/entp_psyche/.codex/attachments/f8560890-9aa7-4fd6-9e11-044278b83892/Pasted text.txt`, read in full; it explicitly appoints Codex and sets this bounded act.
- Read mandates: `AGENTS.md`, `AGENTS_A.md`, `MERGEVUE_CAUSALITY_PROOF_AND_AGENT_CONTROL.md`, and `skills/mergevue-agent-quality-gate/SKILL.md`.
- Independence: audited author identity is Z-Ai; Codex did not author or repair either assembly package in this act. Prior adjacent agent reports are context only and are not the independent assembly oracle.
- Root: `/Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)`.
- Branch / HEAD: `main` / `2567223087d99b40bdfd174eed32566be7080e44`.
- Baseline: no tracked dirty files; 673 pre-existing untracked paths. No Git mutation was performed.
- Output directory: `WORKBENCH/DOWNLOADS/STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_IV1_2026-10-05/`, physically contained in the authorized root; WORKBENCH and DOWNLOADS are not symlinks. The inspected input members are regular files.
- Stopping point: the three-file IV package. No final Stage-2 regression, repair, new analytical coding, Environment determination or Owner acceptance.

## 2. Required summary

```text
VERDICT = PASS
BLOCKING = 0
MAJOR = 0
MINOR = 1
CORR1_PACKAGE_IDENTITY = PASS
PACKAGE_MEMBER_COUNT = 4
CONTRACT_IDENTITY = PASS
CONTRACT_CHANGED = NO
EFFECTIVE_RECORDS_IDENTITY = PASS
EFFECTIVE_RECORDS_CHANGED = NO
EFFECTIVE_VIEW_SHA256_CHANGED = NO
PREDECESSOR_PACKAGE_UNCHANGED = YES
PROOF_DELTA_ALLOWED_ONLY = PASS
UNEXPECTED_PROOF_DIFFS = 0
PROCESS_HISTORY_CORRECTED = YES
PROCESS_HISTORY_ACCURATE = YES
SUBSTANTIVE_PROOF_FINDINGS_PRESERVED = YES
INDEPENDENT_ASSEMBLY_REPRODUCTION = PASS
REPRODUCED_EFFECTIVE_VIEW_SHA256 = a1fcae68939decd0a3c4a39c0a0bc48e8d285bd9cd7ce1928b0d025056244047
ORDER_INDEPENDENCE = PASS
CHANGED_RECORDS = 3
UNCHANGED_RECORDS = 113
DISTINCT_TARGET_FIELDS_CHANGED = 5
LEAF_DIFFERENCES = 8
OTHER_EFFECTIVE_DIFFS = 0
F0024_MINOR_PRECISION_PRESERVED = YES
FB0025_TOUCHED = NO
ENVIRONMENT_MATH_PRESERVED = YES
CORR1_MANIFEST_BINDINGS = PASS
CANDIDATE_STATUS_BOUNDARY = PASS
```

`SUBSTANTIVE_PROOF_FINDINGS_PRESERVED = YES` refers to every required assembly result, hash, count, precondition and no-touch finding in Owner §8. It does not certify the inaccurate explanatory phrase identified in MINOR-001.

## 3. Evidence and source-of-truth classification

**OWNER FACT:** audit authorization, exact expected identities, permitted changes, historical event baseline (§7 A-H), F-B-0025 remains UNADJUDICATED, and the forbidden/stop boundaries.

**SOURCE / RUNTIME FACT:** file bytes, physical SHA-256 and byte counts, JSON shapes, semantic target matches, old values, exact recursive differences, all six reproduced serializations, case-id key presence, and immutable predecessor identities.

**GOVERNANCE FACT:** Control Tree status legend and accepted root/E9 preservation boundaries. The Control Tree file has SHA-256 `360bafa29bad5ea93752323d4a217bf59aaec628e0e2b236350a2edd9c1f7128`, matching its sidecar; latest path binding is commit `7792c5e` dated 2026-09-04. No later full-tree version was found; the report-product addendum is a separate subject. The current Owner act settles this assembly's current scope.

**AGENT-REPORTED FACT:** author proof fields and the historical AB-comparison report. These were compared to independently established physical behavior. Their status text is not Owner acceptance.

**INFERENCE:** the candidate is suitable for separate Owner acceptance as this deterministic effective analytical view, with the disclosed reporting distinction. This is a recommendation, not acceptance.

Bound sources inspected include the predecessor and CORR1 four-file packages; BASE and all three overlay packages; frozen Stage-1 source map and provenance sidecar; only the specified AOL Stage-1 file for case-id/identity precision; root-definitional-v1.7 and E9 CORR3 file identities; pinned Stage-2 semantic CORR4 contract; and the earlier AB-comparison SD-1 for contextual corroboration. No 905-fact/18-side execution occurred.

## 4. Physical package identity and immutability

### CORR1 — exactly four members

| File | Bytes | Physical SHA-256 |
| --- | ---: | --- |
| `STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_MANIFEST.json` | 5095 | `c9ed25e97861add673eae70df72cbff0da6273cd268db0b23cdfc557384a1859` |
| `STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_PROOF.json` | 15285 | `6ebdf0d7e8bbc3b536c90880d9b6e96fe3565a010e60c465baef8ba8685b8ecd` |
| `STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_RECORDS.jsonl` | 104310 | `a1fcae68939decd0a3c4a39c0a0bc48e8d285bd9cd7ce1928b0d025056244047` |
| `STAGE2_EFFECTIVE_VIEW_ASSEMBLY_CONTRACT_1.md` | 16515 | `4e2ff3d00baa05dc82dc4f72318c413b0683cbe0d050ee026bb8b6ad7c6eee66` |

### Predecessor — unchanged

| File | Bytes | Physical SHA-256 |
| --- | ---: | --- |
| `STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_MANIFEST.json` | 3823 | `d5a4ca28d90fc96fc26b91725ac0a68b82af3236fbb1070c7bd7646a366bdbd8` |
| `STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_PROOF.json` | 12963 | `5e545b7ceffcef209d014afb7a39ce762c96412291d8b7e93d1ca50fcbb10f89` |
| `STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_RECORDS.jsonl` | 104310 | `a1fcae68939decd0a3c4a39c0a0bc48e8d285bd9cd7ce1928b0d025056244047` |
| `STAGE2_EFFECTIVE_VIEW_ASSEMBLY_CONTRACT_1.md` | 16515 | `4e2ff3d00baa05dc82dc4f72318c413b0683cbe0d050ee026bb8b6ad7c6eee66` |

All four predecessor hashes match the current Owner's full-length pins. CONTRACT and RECORDS were also compared directly byte-for-byte across predecessor and successor, not just by hash. CORR1 RECORDS contains exactly 116 JSONL records.

### Assembly inputs

| File | Bytes | Physical SHA-256 |
| --- | ---: | --- |
| `STAGE2_POST_RECONCILIATION_EXECUTION_1_CODER_A_RECORDS.jsonl` | 104314 | `8914e745d5df3fbcfc4c4d47be3643ab44a0a3e89fae3d3445b9a94a0b042c71` |
| `STAGE2_FM0205_PLAN_CURRENT_DRIFT_CORRECTION_1.json` | 11015 | `64f489d7569a58d86d4996d1e9abf8538580915ac37ef31e542a0f13188660c4` |
| `STAGE2_CO_PHYSICAL_STATE_DRIFT_CORRECTION_1.json` | 13892 | `3319e912014bfd1f2e5c84da5c141c4e1a329d6095c102f2c081a82dced5f84a` |
| `STAGE2_F0024_FACTUAL_PACKAGE_IDENTITY_CORRECTION_1.json` | 11108 | `0711b74240ddeecac7a95f15a0093ce44f3288f440929d6b803516e53ba6f983` |

Input byte counts are 104314 / 11015 / 13892 / 11108. Every physical SHA matches the Owner pin and unchanged CONTRACT §2. Full read-only file identities are bound in the IV manifest and rechecked before completion.

## 5. Exact recursive proof delta

The recursive comparison identifies exactly five change locations:

| Path | Delta |
| --- | --- |
| `artifact` | `STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_PROOF` → `STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_PROOF` |
| `detail.failClosedNote` | Replaced process-history statement |
| `terminalState` | `EFFECTIVE_VIEW_ASSEMBLY_1_READY_FOR_IV` → `EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_READY_FOR_IV` |
| `corr1` | Added lineage/correction metadata object |
| `supersedes` | Added predecessor-proof pointer |

Addition of a complete object is counted at its structural insertion location. All fields inside the two added objects were inspected: they record lineage, identities and correction scope only. Removing the added objects and restoring the three replaced values makes the full successor proof deeply identical to its predecessor. There are zero other changed existing descendants.

The main `act`, original author identity, original `generatedUtc`, contract identity, all required substantive values, resolved targets, permutation results, leaf-diff list, firewalls and candidate boundary are preserved. New CORR1 metadata has its own act/time. Both predecessor SHA pointers match physical predecessor files.

## 6. Process-history correction

The corrected note at proof line 272 preserves all eight Owner-specified elements:

| Owner element | Check and evidence classification |
| --- | --- |
| A — initial ensure_ascii=False probe failed before materialisation | Explicit in corrected note. Independently reproduced now: two round-trip mismatches, historical lines 113 and 114. The original timing is Owner-supplied history. |
| B — corrected to ensure_ascii=True and verified 116/116 | Explicit in corrected note. Independently reproduced now: 116/116 exact historical round trips. |
| C — later attempt wrote temporary RECORDS/PROOF, failed before manifest because false was used instead of False | Explicit in corrected note; matches the Owner-supplied event baseline. |
| D — temporary outputs were not adopted | Explicit in corrected note; no such partial package is represented as the candidate. Earlier transient contents are not recoverable from final files. |
| E — full pipeline rerun from pinned inputs | Explicit in corrected note. Current independent reproduction from those pins matches exact final bytes. Historical chronology is Owner-supplied. |
| F — all final gates re-executed | Explicit in corrected note. Assembly identity, target, precondition, permutation, serialization, order and exact-diff gates independently pass in this IV. Historical execution events are Owner-supplied. |
| G — final candidate identity unchanged | Physical hash and all six independently produced outputs equal `a1fcae68939decd0a3c4a39c0a0bc48e8d285bd9cd7ce1928b0d025056244047`. |
| H — no historical/overlay mutation | Current pinned files and predecessor hashes match; IV pre/post identity checks preserve inputs. The historical “at any point” assertion is checked against Owner-supplied history, not inferred from hashes. |

The obsolete sentence appears only in `corr1.defect` as an explicitly rejected historical quotation. It is absent from `detail.failClosedNote` and no longer asserted as fact.

**Evidence limit:** original raw authoring logs and original temporary-output bytes were not supplied or recovered. PROCESS_HISTORY_ACCURATE means the corrected record accurately preserves the explicit Owner history and agrees with current independently measurable consequences. It does not claim a forensic reconstruction of earlier tool calls.

## 7. Independent assembly reproduction

An independent Python standard-library oracle was written and executed in memory, without invoking the author's generator or validator and without materialising a second effective dataset.

1. Verify the four input hashes/byte counts before parsing.
2. Extract 1 + 3 + 1 correction objects directly from their overlay payloads.
3. Resolve SECTION_I targets by the conjunction of recordType, edgeId, membership of factId, mechanismPropositionId and targetId. Resolve the F0024 cell by recordType, side A, factId, mechanismPropositionId, targetId and field.
4. Require exactly one match per correction; compare each current value deeply with its full oldValue.
5. Require five distinct (record, effective field) pairs and zero collisions.
6. Apply every overlay-package permutation to a fresh in-memory historical copy.
7. Emit unchanged records as exact historical line bytes; serialize changed records with ensure_ascii=True, historical insertion order and separators `(', ', ': ')`, using LF and one trailing newline.
8. Compare every complete output directly to CORR1 physical bytes.
9. Independently compute the recursive historical-to-effective diff and compare it to the exact eight-entry Owner oracle.

All six permutations produce 104310 bytes and the same full SHA-256:

```text
1-2-3 PASS
1-3-2 PASS
2-1-3 PASS
2-3-1 PASS
3-1-2 PASS
3-2-1 PASS
SHA256 = a1fcae68939decd0a3c4a39c0a0bc48e8d285bd9cd7ce1928b0d025056244047
```

Semantic targets resolve to historical lines 116 (A-E023, three distinct fields), 115 (A-E001.evidenceForm), and 51 (F0024 cell.assignedValue). Line numbers are evidence descriptions, never resolution authority. The complete 17-key F0024 old object matches exactly; its remaining 13 keys are unchanged.

Record identities/order and all list ordering are preserved. BASE census: 110 execution-cell records plus six SECTION_I records. 113 unchanged records preserve their historical line bytes verbatim. Both escaped em-dashes remain historical ASCII escapes. The output is ASCII, has no CRLF/BOM, and ends with exactly one newline.

### Exact diff geometry

| Historical record | Field | Old | Effective |
| --- | --- | --- | --- |
| F0024 · line 51 | `assignedValue.caseIdLocator` | `package-level key 'case_id'` | `record-level key 'case_id'` |
| F0024 · line 51 | `assignedValue.packageFactCount` | `105` | `50` |
| F0024 · line 51 | `assignedValue.recordFileBytes` | `139589` | `61728` |
| F0024 · line 51 | `assignedValue.recordFileSha256` | `4b686b245e412a83424168da6c87db9b392b4ea16eeadff48c0b62e49c7198bb` | `88b20920149b3fcde03e4e060cf4361e9494fe0137540bbc654c526337fd5f10` |
| A-E001 · line 115 | `evidenceForm` | `DE-3` | `DE-1` |
| A-E023 · line 116 | `evidenceForm` | `DE-2` | `DE-4` |
| A-E023 · line 116 | `formalOperativeState` | `OPERATIVE` | `FORMAL_ONLY` |
| A-E023 · line 116 | `planCurrentState` | `CURRENT` | `PLAN` |

Three changed records; 113 unchanged; five distinct target fields; eight leaf differences; zero other differences. The observed diff set equals the independently defined expected set, including old and new values. A ninth leaf would fail the equality assertion. No keys or records were inserted, removed or reordered.

## 8. Firewalls, F0024 precision and Environment preservation

**F0024:** the live AOL Stage-1 file hashes to `88b20920149b3fcde03e4e060cf4361e9494fe0137540bbc654c526337fd5f10`, is 61728 bytes and contains 50 facts. It has BOTH top-level `case_id` and record-level `case_id` on all 50 facts. The source map hash is `665aac81c2e0127d08f0406186891959255391cb99ec34611a972209565f4a7f`; the sidecar hash is `84ab83d23209eae9f775844502676d462490ca8954f8d7a135d28acf5234d6af`. Both select the record-level locator. The single sidecar F0024/AOL identity deeply equals the corrected effective object. CORR1 contract and proof explicitly retain the BOTH-key explanation; no package-level-key absence claim is reintroduced.

**F-B-0025:** all 48 bearing records (execution cells 1–47 and SECTION_I line 111) are byte-identical to the historical base. Physical Lane-A sourceQualityState is `COMPETENT`, including its cell carrier at line 35. The disagreement remains **UNADJUDICATED** under the Owner instruction. This audit does not select either lane as the canonical winner. See MINOR-001 for the inaccurate wording that conflates these two states.

**Environment math:** 35 root v1.7/E9 CORR3 files are byte-identical to current HEAD; latest bindings are `b4bbf31bb188ccb3b5fe67f4efc04992867efa0c` (v1.7, 2026-09-08) and `cb8f890f876c46b8ca4559d54d426bf7b6c5467c` (E9 CORR3, 2026-09-12). A1–A4, R1–R4, T1 and the nine resource formulas are preserved by exact file identity, rather than recalculated or reinterpreted. Stage-2 semantic CORR4 is pinned at `2de49862fb0d63c5f1cd1745531199137e73b7b37abceecef6e735d497d38bb0` / 250512 bytes; its TT registry and discriminator→tree-target bridge remain in that unchanged file. The CORR1 dataset itself is byte-identical to its predecessor, and its complete historical-base delta touches only the authorized five fields.

Thus the preservation chain remains: Root Definitional/E9 unchanged → Stage-2 measures inputs only → no Environment assignment before a frozen determination contract → ECS only after two lawful Environment determinations. Preservation does not establish semantic sufficiency, U-7, OM-1, MD-2 Φ, D2-10, Historical Environment Determination Contract, RULE FREEZE, Environment assignment, Pair/ECS/friction, production authority or empirical validity.

## 9. Findings

### CORR1-IV1-MINOR-001 — inherited firewall wording imprecision

**Severity: MINOR. Confidence: HIGH. Classification: SOURCE / RUNTIME FACT.**

[CORR1 proof detail.firewalls.FB0025](</Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)/WORKBENCH/DOWNLOADS/STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_2026-10-05/STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_PROOF.json:266>) says `sourceQualityState remains UNADJUDICATED`. [Immutable contract §12.1](</Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)/WORKBENCH/DOWNLOADS/STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_2026-10-05/STAGE2_EFFECTIVE_VIEW_ASSEMBLY_CONTRACT_1.md:172>) repeats the same formulation. However, [Effective cell line 35](</Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)/WORKBENCH/DOWNLOADS/STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_2026-10-05/STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_RECORDS.jsonl:35>) carries `assignedValue = COMPETENT`, and [Effective SECTION_I line 111](</Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)/WORKBENCH/DOWNLOADS/STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_2026-10-05/STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_RECORDS.jsonl:111>) carries `sourceQualityState = COMPETENT`. Both are exactly unchanged from history.

The earlier AB-comparison SD-1 records Lane A `COMPETENT` versus Lane B `COMPETENT_SELF_DESCRIPTION_UNCORROBORATED`, without adjudication. That documentary context corroborates the distinction; the physical values were established directly in this IV.

**Consequence:** the explanatory wording can imply an UNADJUDICATED dataset literal. The accurate distinction is “the sourceQualityState disagreement remains UNADJUDICATED; physical Lane-A values are preserved.”

**Why non-blocking:** no effective bytes, target resolution, precondition, collision, order, leaf geometry, historical identity or Environment-math surface is affected. The executable assembly requirement is preservation with no winner selected, and that is independently satisfied. All required substantive assembly fields remain valid. This finding is inherited and unchanged, so it is not an unexpected CORR1 delta.

**Disposition:** no repair performed. Separate Owner acceptance must retain the distinction and must not promote the historical Lane-A `COMPETENT` value into an adjudicated result. Any wording correction requires a separately authorized act; neither the contract nor records were changed here.

No methodology/runtime divergence is resolved by this audit.

## 10. Manifest bindings and candidate boundary

The CORR1 manifest binds exactly CONTRACT, RECORDS and corrected CORR1 PROOF. Every output SHA/byte binding matches physical files. Every input SHA/byte binding matches its physical input. CORR1 naming, predecessor proof/manifest pointers and preserved lineage are consistent. The manifest's own SHA is its physical file hash shown above; no circular self-hash is claimed.

CORR1 manifest `independentlyVerified`, `ownerAccepted`, and `controlling` remain literal `false`. Its terminal state is `EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_READY_FOR_IV`. The proof likewise retains pre-IV candidate boundaries. This IV does not edit those files.

This audit PASS is evidence for a separate Owner acceptance. It is not Owner acceptance or authorization to run final regression.

## 11. Validation record, limitations and next action

Executed only read-only filesystem/Git inspection and in-memory Python analysis. No build, author validator, dev server, final Stage-2 regression or analytical rerun was executed. No memory files or Git mutations occurred.

An initial audit probe asserted that the physical F-B-0025 field itself was UNADJUDICATED and failed on the unchanged COMPETENT value. Direct inspection and the existing SD-1 then established the governance/physical distinction. The erroneous probe expectation was removed; the discrepancy is retained as MINOR-001. All final identity, delta and assembly assertions then passed. No package outputs were written during those probes.

The project quality skill's hard-fail scan was applied to this audit: role independence, bounded writes, source classification, independent oracle and no promotion to production/Owner authority. The false literal-state wording remains disclosed rather than silently accepted or repaired.

The proof-history chronology is checked against the current Owner's explicit history, with the forensic limitation stated in §6. Root/E9 verification is preservation of pinned/tracked bytes, not a new independent methodological certification. Current pinned file equality cannot by itself prove that no temporary historical write ever occurred.

**Recommended next action:** separate Owner acceptance of the exact CORR1 effective-view identity, retaining the F-B-0025 no-adjudication boundary and the disclosed MINOR. No next act is performed by this audit.

**Owner decision required for completing this IV:** NO. Separate Owner acceptance remains required before controlling use.

**Terminal state:** `EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_IV1_PASS`.

## Appendix — independent reproducibility oracle

The executed oracle below writes no files. Run from the authorized repository root with Python 3. It constructs the effective views in memory, independently verifies the packages and prints evidence as JSON. Its equality assertions fail for any additional/missing leaf, nonunique target, bad old value or different permutation bytes.

```python
from pathlib import Path
import json,hashlib,itertools,copy,subprocess,collections
root=Path.cwd().resolve()
d=root/'WORKBENCH/DOWNLOADS'
corr=d/'STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_2026-10-05'
pred=d/'STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_2026-10-05'
expected_contract='4e2ff3d00baa05dc82dc4f72318c413b0683cbe0d050ee026bb8b6ad7c6eee66'
expected_effective='a1fcae68939decd0a3c4a39c0a0bc48e8d285bd9cd7ce1928b0d025056244047'
expected_inputs=['8914e745d5df3fbcfc4c4d47be3643ab44a0a3e89fae3d3445b9a94a0b042c71','64f489d7569a58d86d4996d1e9abf8538580915ac37ef31e542a0f13188660c4','3319e912014bfd1f2e5c84da5c141c4e1a329d6095c102f2c081a82dced5f84a','0711b74240ddeecac7a95f15a0093ce44f3288f440929d6b803516e53ba6f983']
def physical(p):
 b=p.read_bytes()
 return {'path':str(p.relative_to(root)) if p.is_relative_to(root) else str(p),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'symlink':p.is_symlink()}
def ld(p): return json.loads(p.read_bytes())
def recursive(a,b,path=''):
 if type(a) is not type(b): return [{'path':path,'old':a,'new':b}]
 if isinstance(a,dict):
  out=[]
  for k in sorted(a.keys()|b.keys()):
   q=path+'.'+k if path else k
   if k not in a: out.append({'path':q,'operation':'ADD','new':b[k]})
   elif k not in b: out.append({'path':q,'operation':'REMOVE','old':a[k]})
   else: out.extend(recursive(a[k],b[k],q))
  return out
 if isinstance(a,list):
  if len(a)!=len(b): return [{'path':path,'old':a,'new':b}]
  return [v for i,(x,y) in enumerate(zip(a,b)) for v in recursive(x,y,f'{path}[{i}]')]
 return [] if a==b else [{'path':path,'old':a,'new':b}]
cm=ld(corr/'STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_MANIFEST.json')
cp=ld(corr/'STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_PROOF.json')
pp=ld(pred/'STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_PROOF.json')
assert {f.name for f in corr.iterdir()}=={'STAGE2_EFFECTIVE_VIEW_ASSEMBLY_CONTRACT_1.md','STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_RECORDS.jsonl','STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_PROOF.json','STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_MANIFEST.json'}
paths=[root/i['path'] for i in cm['inputs']]
assert [physical(p)['sha256'] for p in paths]==expected_inputs
assert [physical(p)['bytes'] for p in paths]==[104314,11015,13892,11108]
assert physical(corr/'STAGE2_EFFECTIVE_VIEW_ASSEMBLY_CONTRACT_1.md')['sha256']==expected_contract
assert physical(corr/'STAGE2_EFFECTIVE_VIEW_ASSEMBLY_CONTRACT_1.md')['bytes']==16515
for fn in ['STAGE2_EFFECTIVE_VIEW_ASSEMBLY_CONTRACT_1.md','STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_RECORDS.jsonl']:
 assert (corr/fn).read_bytes()==(pred/fn).read_bytes()
assert physical(corr/'STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_RECORDS.jsonl')['sha256']==expected_effective
assert physical(corr/'STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_RECORDS.jsonl')['bytes']==104310
pred_expected={'STAGE2_EFFECTIVE_VIEW_ASSEMBLY_CONTRACT_1.md':expected_contract,'STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_RECORDS.jsonl':expected_effective,'STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_PROOF.json':'5e545b7ceffcef209d014afb7a39ce762c96412291d8b7e93d1ca50fcbb10f89','STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_MANIFEST.json':'d5a4ca28d90fc96fc26b91725ac0a68b82af3236fbb1070c7bd7646a366bdbd8'}
assert set(f.name for f in pred.iterdir())==set(pred_expected)
assert all(physical(pred/f)['sha256']==h for f,h in pred_expected.items())
delta=recursive(pp,cp)
assert {x['path'] for x in delta}=={'artifact','terminalState','detail.failClosedNote','corr1','supersedes'}
allowed=copy.deepcopy(cp)
for k in ['corr1','supersedes']: del allowed[k]
allowed['artifact']=pp['artifact'];allowed['terminalState']=pp['terminalState'];allowed['detail']['failClosedNote']=pp['detail']['failClosedNote']
assert allowed==pp
note=cp['detail']['failClosedNote']
assert all(t in note for t in ['ensure_ascii=False','BEFORE any materialisation','ensure_ascii=True','116/116','temporary RECORDS and PROOF','false','False','never adopted','complete pipeline','pinned inputs','all final gates re-executed','No historical or accepted-overlay input','a1fcae68939decd0a3c4a39c0a0bc48e8d285bd9cd7ce1928b0d025056244047'])
assert 'No partial outputs were ever written' not in note
assert cp['supersedes']['sha256']==pred_expected['STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_PROOF.json']
assert cp['corr1']['predecessorManifestSha256']==pred_expected['STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_MANIFEST.json']
for x in cm['outputs']:
 i=physical(corr/x['file']);assert (i['sha256'],i['bytes'])==(x['sha256'],x['bytes'])
assert len(cm['outputs'])==3
assert cm['correction']['predecessorManifestSha256']==pred_expected['STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_MANIFEST.json']
assert cm['correction']['predecessorProofSha256']==pred_expected['STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_PROOF.json']
assert cm['terminalState']==cp['terminalState']=='EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_READY_FOR_IV'
assert all(cm['disclaimers'][k] is False for k in ['independentlyVerified','ownerAccepted','controlling'])
assert cp['candidateStatus']['EFFECTIVE_VIEW_OWNER_ACCEPTED']=='NO'
assert cp['candidateStatus']['EFFECTIVE_VIEW_INDEPENDENTLY_VERIFIED']=='NO'
base_bytes=paths[0].read_bytes(); lines=base_bytes.splitlines(keepends=True); base=[json.loads(l) for l in lines]
effective_bytes=(corr/'STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_RECORDS.jsonl').read_bytes()
eff_lines=effective_bytes.splitlines(keepends=True); eff=[json.loads(l) for l in eff_lines]
assert len(base)==len(eff)==116
assert collections.Counter(x['recordType'] for x in base)=={'POST_RECONCILIATION_EXECUTION_CELL_RECORD':110,'SECTION_I_RECORD':6}
def encode(r):return (json.dumps(r,ensure_ascii=True,separators=(', ',': '))+'\n').encode('ascii')
assert all(encode(r)==l for r,l in zip(base,lines))
probe_false_bad=[i+1 for i,(r,l) in enumerate(zip(base,lines)) if (json.dumps(r,ensure_ascii=False,separators=(', ',': '))+'\n').encode()!=l]
assert len(probe_false_bad)==2
ov=[ld(p) for p in paths[1:]]
groups=[[ov[0]['correctionRecord']],ov[1]['corrections'],ov[2]['correctionRecords']]
assert [len(g) for g in groups]==[1,3,1]
def resolve(records,c):
 if 'edgeId' in c:
  indices=[i for i,r in enumerate(records) if r.get('recordType')=='SECTION_I_RECORD' and r.get('edgeId')==c['edgeId'] and c['factId'] in r.get('factIds',[]) and c['mechanismPropositionId'] in r.get('mechanismPropositionIds',[]) and c['targetId'] in r.get('treeTargetIds',[])]
  key=c['field']
 else:
  assert c['lane']=='A' and c['factId']=='F0024' and c['mechanismPropositionId']=='M-RES-ROLE-CONTROLLED-ACCESS' and c['targetId']=='TT-STPSTJ-RS' and c['field']=='factualPackageIdentity'
  indices=[i for i,r in enumerate(records) if r.get('recordType')=='POST_RECONCILIATION_EXECUTION_CELL_RECORD' and r.get('side')=='A' and r.get('factId')==c['factId'] and r.get('mechanismPropositionId')==c['mechanismPropositionId'] and r.get('targetId')==c['targetId'] and r.get('field')==c['field']]
  key='assignedValue'
 assert len(indices)==1,indices
 i=indices[0];assert key in records[i]
 if 'edgeId' in c:assert not isinstance(records[i][key],(dict,list))
 return i,key
targets=[]
for gi,g in enumerate(groups):
 for c in g:
  i,key=resolve(base,c);assert base[i][key]==c['oldValue']
  targets.append({'overlay':gi+1,'recordLine':i+1,'recordType':base[i]['recordType'],'edgeId':c.get('edgeId'),'factId':c['factId'],'mechanismPropositionId':c['mechanismPropositionId'],'targetId':c['targetId'],'effectiveField':key})
assert len({(x['recordLine'],x['effectiveField']) for x in targets})==5
perms=[]
for perm in itertools.permutations(range(3)):
 candidate=copy.deepcopy(base)
 for gi in perm:
  for c in groups[gi]:
   i,k=resolve(candidate,c);assert candidate[i][k]==c['oldValue'];candidate[i][k]=copy.deepcopy(c['correctedValue'])
 b=b''.join(lines[i] if candidate[i]==base[i] else encode(candidate[i]) for i in range(116))
 assert b==effective_bytes
 assert b==b''.join(encode(r) for r in candidate)
 perms.append({'order':[i+1 for i in perm],'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'exactPhysicalMatch':True})
diffs=[]; changed=[]
for i,(a,b) in enumerate(zip(base,eff)):
 dr=recursive(a,b)
 if dr:changed.append(i+1)
 diffs.extend({'recordLine':i+1,**v} for v in dr)
assert changed==[51,115,116]
expected={(51,'assignedValue.recordFileBytes'):(139589,61728),(51,'assignedValue.recordFileSha256'):('4b686b245e412a83424168da6c87db9b392b4ea16eeadff48c0b62e49c7198bb','88b20920149b3fcde03e4e060cf4361e9494fe0137540bbc654c526337fd5f10'),(51,'assignedValue.packageFactCount'):(105,50),(51,'assignedValue.caseIdLocator'):("package-level key 'case_id'","record-level key 'case_id'"),(115,'evidenceForm'):('DE-3','DE-1'),(116,'evidenceForm'):('DE-2','DE-4'),(116,'formalOperativeState'):('OPERATIVE','FORMAL_ONLY'),(116,'planCurrentState'):('CURRENT','PLAN')}
assert {(v['recordLine'],v['path']):(v['old'],v['new']) for v in diffs}==expected
assert len(diffs)==8
assert all(eff_lines[i]==lines[i] for i in range(116) if i+1 not in changed)
assert eff[114]['planCurrentState']==base[114]['planCurrentState']=='CURRENT'
def identity(r):
 return {k:r.get(k) for k in ['recordType','side','edgeId','factId','factIds','mechanismPropositionId','mechanismPropositionIds','targetId','treeTargetIds','field','censusCellRef']}
assert [identity(r) for r in base]==[identity(r) for r in eff]
fb=[i for i,r in enumerate(base) if 'F-B-0025' in json.dumps(r)]
assert len(fb)==48 and all(eff_lines[i]==lines[i] for i in fb)
fb_section=[r for i,r in enumerate(eff) if i in fb and r['recordType']=='SECTION_I_RECORD']
assert len(fb_section)==1
assert fb_section[0]['sourceQualityState']==base[110]['sourceQualityState']=='COMPETENT'
fb_cell=[r for r in eff if r.get('factId')=='F-B-0025' and r.get('field')=='sourceQualityState']
assert len(fb_cell)==1 and fb_cell[0]['assignedValue']=='COMPETENT'
src=d/'STAGE2_CORR4_PILOT_STAGE1_SOURCE_MAP.json'; sidecar=d/'STAGE2_CORR4_PILOT_ANALYTICAL_PROVENANCE_SIDECAR_CORR1.jsonl'
assert physical(src)['sha256']=='665aac81c2e0127d08f0406186891959255391cb99ec34611a972209565f4a7f'
assert physical(sidecar)['sha256']=='84ab83d23209eae9f775844502676d462490ca8954f8d7a135d28acf5234d6af'
sm=[x for x in ld(src)['cases'] if x['caseSlug']=='aol-time-warner']; assert len(sm)==1;sm=sm[0]
fpi=eff[50]['assignedValue']; stage1=Path(sm['recordFile']); doc=ld(stage1)
assert physical(stage1)['sha256']==fpi['recordFileSha256']==sm['recordFileSha256']
assert physical(stage1)['bytes']==fpi['recordFileBytes']==sm['recordFileBytes']==61728
facts=doc[sm['recordListKey']] if sm['recordListKey'] else doc
assert isinstance(doc,dict) and 'case_id' in doc
assert len(facts)==50 and all('case_id' in r and r['case_id']==doc['case_id'] for r in facts)
assert sm['caseIdLocator']==fpi['caseIdLocator']=="record-level key 'case_id'"
sp=[json.loads(l) for l in sidecar.read_bytes().splitlines()]
sp=[r for r in sp if r.get('factId')=='F0024' and r.get('caseId')=='aol-time-warner' and r.get('sideId')=='AOL']
assert len(sp)==1 and sp[0]['factualPackageIdentity']==fpi
proof_findings={k:cp[k] for k in cp if k.isupper()}
assert all(pp[k]==v for k,v in proof_findings.items())
assert proof_findings=={'BASE_IDENTITY':'PASS','OVERLAY_1_IDENTITY':'PASS','OVERLAY_2_IDENTITY':'PASS','OVERLAY_3_IDENTITY':'PASS','CORRECTION_RECORDS':5,'DISTINCT_TARGET_FIELDS':5,'OVERLAY_COLLISIONS':0,'TARGETS_UNIQUE':'YES','OLD_VALUE_PRECONDITIONS':'PASS','ORDER_INDEPENDENCE':'PASS','BASE_RECORDS':116,'EFFECTIVE_RECORDS':116,'CHANGED_RECORDS':3,'UNCHANGED_RECORDS':113,'DISTINCT_TARGET_FIELDS_CHANGED':5,'LEAF_DIFFERENCES':8,'OTHER_EFFECTIVE_DIFFS':0,'RECORD_COUNT_PRESERVED':'YES','RECORD_ORDER_PRESERVED':'YES','FB0025_TOUCHED':'NO','HISTORICAL_PACKAGE_MUTATED':'NO','ENVIRONMENT_MATH_PRESERVED':'YES','EFFECTIVE_VIEW_SHA256':expected_effective,'EFFECTIVE_VIEW_BYTES':104310}
assert {(x['recordLine'],x['path'],json.dumps(x['old'],sort_keys=True),json.dumps(x['new'],sort_keys=True)) for x in cp['detail']['leafDiffs']}=={(x['recordLine'],x['path'],json.dumps(x['old'],sort_keys=True),json.dumps(x['new'],sort_keys=True)) for x in diffs}
math_dirs=[root/'docs/reference/root-definitional-v1.7',root/'docs/reference/root-definitional-e9-corr3']
math_files=[f for folder in math_dirs for f in folder.rglob('*') if f.is_file()]
control=root/'docs/governance/MERGEVUE_CONTROL_TREE_v2.1_2026-09-04.md'
assert physical(control)['sha256']=='360bafa29bad5ea93752323d4a217bf59aaec628e0e2b236350a2edd9c1f7128'
stage2=d/'STAGE2_SEMANTIC_SUCCESSOR_CANDIDATE_CORR4.md'
assert physical(stage2)['sha256']=='2de49862fb0d63c5f1cd1745531199137e73b7b37abceecef6e735d497d38bb0'
readonly=set(paths+math_files+[src,sidecar,stage1,control,stage2]+[f for f in corr.iterdir()]+[f for f in pred.iterdir()])
readonly.update(f for folder in [p.parent for p in paths] for f in folder.rglob('*') if f.is_file())
snap=[physical(f) for f in sorted(readonly)]
assert all(not x['symlink'] for x in snap)
git_state={'root':subprocess.check_output(['git','rev-parse','--show-toplevel'],text=True).strip(),'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'branch':subprocess.check_output(['git','branch','--show-current'],text=True).strip(),'trackedDirty':subprocess.check_output(['git','--no-optional-locks','status','--porcelain=v1','--untracked-files=no'],text=True),'untrackedPaths':subprocess.check_output(['git','--no-optional-locks','ls-files','--others','--exclude-standard'],text=True).splitlines()}
assert git_state['trackedDirty']==''
untracked=git_state.pop('untrackedPaths')
git_state['untrackedPathCount']=len(untracked)
git_state['untrackedPathsSha256']=hashlib.sha256(('\n'.join(untracked)+'\n').encode()).hexdigest()
out={'allAssertionsPassed':True,'repository':git_state,'corr1Members':[physical(f) for f in sorted(corr.iterdir())],'predecessorMembers':[physical(f) for f in sorted(pred.iterdir())],'pinnedInputs':[physical(p) for p in paths],'proofDelta':delta,'independentFindings':proof_findings,'semanticTargets':targets,'permutations':perms,'leafDiffs':diffs,'serialization':{'roundTripMatches':116,'ensureAsciiFalseMismatchLines':probe_false_bad,'pureAscii':effective_bytes.isascii(),'LFOnly':b'\r' not in effective_bytes,'oneTrailingNewline':effective_bytes.endswith(b'\n') and not effective_bytes.endswith(b'\n\n'),'unchangedHistoricalLinesVerbatim':113},'fb0025':{'bearingRecordCount':48,'allBytesUnchanged':True,'physicalSourceQualityState':fb_section[0]['sourceQualityState'],'governanceAdjudicationState':'UNADJUDICATED','sourceQualityCellLine':35,'sourceQualitySectionLine':111},'f0024Precision':{'stage1':physical(stage1),'topLevelCaseIdPresent':True,'recordLevelCaseIdCount':50,'sourceMap':physical(src),'provenanceSidecar':physical(sidecar),'recordLevelLocatorSelectedByBoth':True},'mathPreservation':{'stage2SemanticContract':physical(stage2),'rootAndE9Files':len(math_files),'trackedTreeClean':True,'preservationBasis':'Unchanged contract, unchanged CORR1 records versus predecessor, exact eight-leaf correction versus historical base, pinned Stage-2 semantic contract, root/E9 current file snapshots. No revalidation or new methodology claim.'},'readonlySnapshot':snap}
print(json.dumps(out,ensure_ascii=True))

```

