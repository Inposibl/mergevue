# STAGE-2 EVIDENCE INDEX — `MERGEVUE_STAGE2_CURRENT_STATE_RECONSTRUCTION_1`

**Date:** 2026-10-08 · Every load-bearing claim of the report is bound here to an exact path, commit/ref, locator, SHA-256 where computed or pinned, and an evidence classification per AGENTS.md §11 (OWNER-ACCEPTED FACT / METHOD FACT / SOURCE-RUNTIME FACT / DOCUMENTATION CLAIM / AGENT-REPORTED FACT / INFERENCE / NOT DETERMINABLE). SHAs marked **[recomputed]** were hashed from physical bytes by this act on 2026-10-08.

Repository root (all relative paths): `/Users/entp_psyche/Desktop/InvestProjects2026/MergeVue PayProduct (june 2026)/MergeVue-M&A (August 2026)`. Sibling workbench: `../MergeVue-M&A WORKBENCH/`.

## E1. Repository / preflight facts

| # | Claim | Evidence | Classification |
| --- | --- | --- | --- |
| E1.1 | HEAD = `9b57f0cb567d5a36e4ebcf3292cdbd18439f4faa`, branch `main`, subject "docs: bind Owner-accepted verified control-tree reconstruction CORR4" | `git rev-parse HEAD`; `git log --oneline -1` | SOURCE/RUNTIME FACT |
| E1.2 | Live remote `main` = `9b57f0c…`; local↔remote divergence 0/0 | `git ls-remote origin refs/heads/main`; `git rev-list --left-right --count main...origin/main` | SOURCE/RUNTIME FACT |
| E1.3 | Commit sequence `9b1545e` → `fcbcf86` → `3d7b777` → `c7a83a3` → `21ce98f` → `4f75669` → `ee55034` → `9b57f0c` on main, with authors/dates | `git log --oneline -15`; `git show --format` per commit | SOURCE/RUNTIME FACT |
| E1.4 | `9b1545e` adds 11 CORR10 files; `fcbcf86` adds 7 F0024 files; `3d7b777` adds 9 A-E001 files — all under `WORKBENCH/DOWNLOADS/…2026-10-07/` | `git show --name-only 9b1545e fcbcf86 3d7b777` | SOURCE/RUNTIME FACT |
| E1.5 | Rejected tree overlay bound `c7a83a3`, corrected `21ce98f`/`4f75669`, deleted `ee55034`, archived at `refs/archive/MERGEVUE_REJECTED_TREE_COMMITS_ROLLBACK_1` → `21ce98f` | `git show --name-status` per commit; `git for-each-ref` | SOURCE/RUNTIME FACT |
| E1.6 | 426 dirty/untracked paths; no Git mutation performed by this act | `git status --porcelain \| wc -l`; command ledger in `ACT_MANIFEST.json` | SOURCE/RUNTIME FACT |

## E2. Control tree (controlling status map)

| # | Claim | Evidence | Classification |
| --- | --- | --- | --- |
| E2.1 | B17.1 semantic successor CORR4 = OWNER_ACCEPTED / IV PASS / BOUND@2567223 | `WORKBENCH/AUDITS/MERGEVUE_VERIFIED_CURRENT_CONTROL_TREE_RECONSTRUCTION_1_CORR4/MERGEVUE_NODE_STATUS_MATRIX.json`, node `B17.1` (bound at `9b57f0c`) | OWNER-ACCEPTED FACT (tree) + corroborating files below |
| E2.2 | B17.2 pilot lock = OWNER_AUTHORIZED / PASS / BOUND@d14f197 | same, node `B17.2` | OWNER-ACCEPTED FACT |
| E2.3 | B17.3 stratification EXECUTED = OWNER_AUTHORIZED / **IV NOT_ESTABLISHED** / UNTRACKED; HOLD-6 provenance deviation carried; A/B artifacts in sibling WB `03_SOURCE_ARTIFACTS/STAGE2_CORR4_AB_COMPARISON_2026-10-02/` | same, node `B17.3` | OWNER-ACCEPTED FACT (tree); artifact existence SOURCE/RUNTIME FACT |
| E2.4 | B17.4 CORR10+A-E001+F0024 = **OWNER_ACCEPTANCE_NOT_ESTABLISHED**; IV PASS ×3 with exact report bytes; "Owner acceptance ATTESTED by binding-commit subject — exact acceptance NOT ESTABLISHED" | same, node `B17.4` (title + evidence fields) | OWNER-ACCEPTED FACT |
| E2.5 | B17.5 FEVA CORR1 = CANDIDATE / **IV NOT_RUN** / UNTRACKED; records SHA `3603c316…` recomputed by CORR4 | same, node `B17.5` | OWNER-ACCEPTED FACT |
| E2.6 | B17.6 sourceClass = OWNER_ACCEPTED_RESIDUALS / PASS / BOUND@31fd56e; B17.7 other untracked = CANDIDATE / NOT_ESTABLISHED | same, nodes `B17.6`/`B17.7` | OWNER-ACCEPTED FACT |
| E2.7 | B5.8 (HEDC bridge) blocked while B5.5/B5.7/B17.5 lifecycle-unresolved | `…_CORR4/MERGEVUE_CURRENT_CONTROL_TREE_CANDIDATE.md` line ~105 | OWNER-ACCEPTED FACT |

## E3. Contract / lock / pilot

| # | Claim | Evidence | Classification |
| --- | --- | --- | --- |
| E3.1 | Semantic successor CORR4 identity `2de49862fb0d63c5f1cd1745531199137e73b7b37abceecef6e735d497d38bb0` (250,512 B) is the "OWNER-ACCEPTED EXECUTABLE CONTRACT", identity check EXACT MATCH | `WORKBENCH/DOWNLOADS/STAGE2_CORR4_PILOT_VERSION_LOCK.md` §2 table (file dated 2026-09-26); contract bound at `2567223` as `STAGE2_SEMANTIC_SUCCESSOR_CANDIDATE_CORR4.md` | OWNER-ACCEPTED FACT (recorded) |
| E3.2 | Pilot lock terminal lineage `…CORR1_CORR2_CORR1_CORR2_CORR1_CORR1_CORR1` IV1 = PASS; parent IV1 FAIL 0B/3M; frozen coder-view schema `0cb5a6b5…` | `WORKBENCH/DOWNLOADS/STAGE2_CORR4_PILOT_LOCK_CORR1_CORR2_CORR1_CORR2_CORR1_CORR1_CORR1_AUTHOR_REPORT.md` §1–2 (bound `d14f197`); IV report in same commit | AGENT-REPORTED FACT (author) + OWNER-ACCEPTED FACT (B17.2) |
| E3.3 | Pilot A/B executed: 11,765 marks each, agreement 0.9070123; STRATIFIER_B provenance deviation recorded | Matrix B17.3 evidence field; sibling `03_SOURCE_ARTIFACTS/STAGE2_CORR4_AB_COMPARISON_2026-10-02/STAGE2_CORR4_PILOT_AB_COMPARISON_RESULT.json` + author report | AGENT-REPORTED FACT + artifact presence SOURCE/RUNTIME FACT; stratification-level IV = NOT_ESTABLISHED |

## E4. Post-pilot corrections (CORR10 / F0024 / A-E001)

| # | Claim | Evidence | Classification |
| --- | --- | --- | --- |
| E4.1 | CORR10.IV1 VERDICT = PASS; 0/0/0/4 ADVISORY; `INDEPENDENTLY_VERIFIED = YES` (component scope); **`OWNER_ACCEPTED = NO`**; prior CORR9.IV1 FAIL preserved; accepted methodology chain `2f595ab5…` (incorporating CORR1 `02505e92…`) + census `3133b758…` + manifest `f068e31c…` | `WORKBENCH/DOWNLOADS/STAGE2_SUPPORTCLASS_EVALUABILITY_SEMANTIC_SEPARATION_1_IMPLEMENTATION_1_CORR10_IV1_2026-10-07/…_IV1_REPORT.md` lines 49–74, 127–129 | AGENT-REPORTED FACT (independent auditor) |
| E4.2 | CORR10 manifest at authoring: `OWNER_ACCEPTED = NO`, `STATUS = BLOCKED` (awaiting acceptance) | `…_CORR10_2026-10-07/…_CORR10_MANIFEST.json` | AGENT-REPORTED FACT |
| E4.3 | CORR10 bound: commit subject "stage2: bind accepted CORR10 semantic-separation implementation", 2026-10-07 16:41 | `git show 9b1545e` | AGENT-REPORTED FACT (commit subject; per closure governance §20/373 the Git agent acts under explicit Owner authorization — the subject attests, does not prove, acceptance) |
| E4.4 | F0024.IV1 VERDICT = PASS; 0/0/0; CLAUDE 4.6 auditor; `STALE_IDENTITY_ACCEPTED = NO`; "The next governance step is the Owner acceptance decision"; live package 61,728 B = `88b20920…` | `WORKBENCH/DOWNLOADS/AOL_F0024_RECONCILIATION_1_IV1_2026-10-07/…_IV1_REPORT.md` lines 5–30, 255–263 | AGENT-REPORTED FACT (auditor) |
| E4.5 | F0024 bound: `fcbcf86` "stage2: bind accepted F0024 provenance reconciliation" | `git show fcbcf86` | AGENT-REPORTED FACT |
| E4.6 | A-E001.IV1 VERDICT = PASS (Codex, Owner-appointed); 0/0/0/5; lawful scope "LH program team ONLY"; `UNRESOLVED_FAIL_CLOSED`; B-1b fires; successor `[EVALUABLE, null, NON_DISCRIMINATING]`; Owner-frozen supplied `[c1]`/missing `[c2]` partition | `WORKBENCH/DOWNLOADS/A_E001_SEMANTIC_READJUDICATION_1_IV1_2026-10-07/…_IV1_REPORT.md` lines 7–19, 79–83 | AGENT-REPORTED FACT (auditor) |
| E4.7 | A-E001 bound: `3d7b777` "stage2: bind accepted A-E001 semantic readjudication"; scope+bearing decisions `b3900383…`/`e7624316…` | `git show 3d7b777`; FEVA v1 report §1 input table (SHAs pinned) | AGENT-REPORTED FACT |
| E4.8 | Separation methodology accepted: candidate `2f595ab5ddecc7e8149f751c661470bbae1fa3abfb1fb207b2b65c4c4565d6c8`, census `3133b758…`, manifest `f068e31c…` ("accepted" per CORR10 IV1 report §inputs) | `WORKBENCH/DOWNLOADS/STAGE2_SUPPORTCLASS_EVALUABILITY_SEMANTIC_SEPARATION_1_CORR2_CORR1_CORR1_CORR1_CORR1_2026-10-05/` | AGENT-REPORTED FACT (auditor-attested accepted inputs) |
| E4.9 | Owner REG-007 decision (nested `relationInstanceId = null`) exists and is treated as OWNER FACT; U-3 decision not reopened | `WORKBENCH/DOWNLOADS/STAGE2_A_E023_SUPPORTCLASS_H8_REDERIVATION_1_2026-10-05/STAGE2_A_E023_SUPPORTCLASS_H8_REDERIVATION_1.md` lines 13, 120; separation candidate line 254 | OWNER FACT as transcribed by author acts (conversational decision recorded in bound-candidate artifacts) |

## E5. Effective-view / regression chain

| # | Claim | Evidence | Classification |
| --- | --- | --- | --- |
| E5.1 | Predecessor view `a1fcae68939decd0a3c4a39c0a0bc48e8d285bd9cd7ce1928b0d025056244047`, 104,310 B, 116 records **[recomputed]** | `WORKBENCH/DOWNLOADS/STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_2026-10-05/STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_RECORDS.jsonl` | SOURCE/RUNTIME FACT |
| E5.2 | That chain's CORR1.IV1 = PASS (0B/0M/1 MINOR), `REPRODUCED_EFFECTIVE_VIEW_SHA256 = a1fcae68…` | `…_CORR1_IV1_2026-10-05/STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_IV1_REPORT.md` lines 3–41 | AGENT-REPORTED FACT (auditor) |
| E5.3 | Final regression input identities: view `a1fcae68…`, methodology `cb08b51e…`, assembly contract `4e2ff3d0…`; "The Owner designates the view as Owner-accepted/independently verified/controlling **for this act**" | `WORKBENCH/DOWNLOADS/STAGE2_FINAL_MEASUREMENT_REGRESSION_1_2026-10-05/STAGE2_FINAL_MEASUREMENT_REGRESSION_1_REPORT.md`, "Role, scope and authority" | OWNER DESIGNATION as transcribed by executor (scoped to that act) |
| E5.4 | Regression result: `FINAL_STAGE2_MEASUREMENT_REGRESSION = FAIL`; 116 records (110 execution cells: 107 PASS / 3 FAIL cells 9/51/56); SECTION_I 163 MATCH / 19 MISMATCH / 100 ND; `READY_FOR_POST_REGRESSION_SEMANTIC_METHOD_ACT = NO`; "Executor-authored local QA evidence. Not independent audit, Owner acceptance or controlling regression closure"; deterministic (2 replays); `GIT_MUTATED = YES` (reflog growth, background-fetch inference) | same report, "Required summary" block + header | AGENT-REPORTED FACT (executor) |
| E5.5 | CORRECTION_1 candidate records `3737bd5d5aa3b92f7f737fb6b35170ae35e936c2541d8b6fe053f8cb88a816c5` (116 records) **[recomputed]**; package members `b7c26c16…`/`3b0ec4db…`/`ee122a4b…` | `WORKBENCH/DOWNLOADS/STAGE2_FINAL_MEASUREMENT_REGRESSION_1_CORRECTION_1_2026-10-05/STAGE2_EFFECTIVE_VIEW_MEASUREMENT_CORR1_RECORDS.jsonl`; IV1 report package table | SOURCE/RUNTIME FACT + AGENT-REPORTED FACT |
| E5.6 | CORRECTION_1.IV1 = **HOLD**: 1 BLOCKING (REG-007 nested-reference selection not uniquely selected) + 1 MAJOR (A-E023 DIRECT_SUPPORT under DE-4 not proven preserved); `ownerAccepted = false`, `controlling = false`; "I did not run the final regression again" | `…_CORRECTION_1_IV1_2026-10-05/…_IV1_REPORT.md` lines 5–12, §11 | AGENT-REPORTED FACT (auditor) |
| E5.7 | Supersession of the direct-correction path: A-E001 as-frozen state HELD/HOLD-T/SEP-MIG-6c superseded via SEP-MIG-6a in the FINAL FEVA migration ledger | `STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_2026-10-07/…_CORR1_MIGRATION_LEDGER.json` (entry fields quoted in CORR1 report §3) | AGENT-REPORTED FACT (author) + IV corroboration at E5.9 |

## E6. FINAL FEVA chain (terminal candidate)

| # | Claim | Evidence | Classification |
| --- | --- | --- | --- |
| E6.1 | v1 records `ea0de2f072f0b13f15d36ff053ef047128de15b529d31cefeb1a3337462f6f0a` (104,937 B, 116 records) **[recomputed]**; 5-member package; inputs table pins F0024 patch `bf5d832f…`, A-E001 decisions, CORR10 builder `4fabec82…`, method `cb08b51e…`, sidecar `84ab83d2…`, source map `665aac81…`, live package `88b20920…` (61,728 B), view schema `0cb5a6b5…`; "Git closure authority: fcbcf86 / 3d7b777" | `WORKBENCH/DOWNLOADS/STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1_2026-10-07/STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1_REPORT.md` §1–2 | AGENT-REPORTED FACT (author) |
| E6.2 | v1 IV1 = **FAIL** (Codex): F01 CRITICAL/BLOCKING dual `supportClass`+`supportBearing` (SEP-I-4/SEP-BC-2); F02 MAJOR ledger-metadata-on-record; F03/F04 MINOR | Corroborated twice: `WORKBENCH/AUDITS/2026-10-07_REALITY_AUDIT/MERGEVUE_REALITY_AUDIT_2026-10-07.md` §4 (findings quoted; index `ST2-04 = FAILED_IV1_BY_CODEX`) + CORR1 report §Baseline/§1.F01 (failed package re-hashed against IV1-pinned identities). **IV1 report bytes NOT_FOUND in searched surface** | AGENT-REPORTED FACT (two corroborating secondary sources); bytes NOT_FOUND_IN_SEARCHED_SOURCES |
| E6.3 | Terminal candidate records **`3603c3169d7bdd67763ac0d2468d08cbb508d23dfeece4f7b396900b11dc68ec`**, 104,704 B, 116 records **[recomputed]**; exactly 2 changed lines (112, 115), 114 byte-verbatim; F0024 certification executed via CORR10 `certify()` | `WORKBENCH/DOWNLOADS/STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_2026-10-07/STAGE2_FINAL_EFFECTIVE_VIEW_ASSEMBLY_1_CORR1_RECORDS.jsonl` + `_REPORT.md` §2–5 | SOURCE/RUNTIME FACT (bytes) + AGENT-REPORTED FACT (semantics) |
| E6.4 | Candidate status flags: manifest `status = READY_FOR_INDEPENDENT_VERIFICATION`, `independentlyVerified = false`, `ownerAccepted = false`, `gitClosed = false`, `finalRegressionExecuted = false`; report §7: "CANDIDATE: NOT independently verified, NOT Owner-accepted, NOT Git-closed, no final measurement regression"; stopping point: "CORR1.IV1 not started (Codex is the designated independent auditor in a separate act)" | `…_CORR1_MANIFEST.json` top-level fields; `…_CORR1_REPORT.md` header + §7 | AGENT-REPORTED FACT (author; consistent with E2.5 control tree) |
| E6.5 | Reality audit (~2026-10-07 21:00) recorded CORR1 as unmaterialized ("build script has NOT been executed… no JSONL or manifest") — **now stale**: full 6-member package exists; CORR4 (2026-10-08) recomputed `3603c316…` | `WORKBENCH/AUDITS/2026-10-07_REALITY_AUDIT/MERGEVUE_REALITY_AUDIT_2026-10-07.md` §4/critical-gap 1 vs. directory listing + E2.5 | DOCUMENTATION CLAIM (superseded by physical state — SOURCE/RUNTIME FACT) |

## E7. Search completeness / negatives

| # | Claim | Evidence | Classification |
| --- | --- | --- | --- |
| E7.1 | No FEVA/Stage-2 measurement artifact postdates the CORR1 package in any ref | `git log --all` sweeps (`--grep=regression`, `--grep='effective.view'`); `find` over repo Workbench and sibling Workbench (`*EFFECTIVE_VIEW*`, `*FEVA*`, `*REGRESSION*`, `*CODER*`, `*STRATIFIER*`, `*PILOT*`); `git grep` at HEAD | SOURCE/RUNTIME FACT (bounded by searched surface) |
| E7.2 | No tracked path at HEAD contains a FEVA file (B17.5 UNTRACKED confirmed independently) | `git show 9b57f0c --name-status` (only CORR4 audit files); `git log --all --diff-filter=A -- '*FINAL_EFFECTIVE*'` empty | SOURCE/RUNTIME FACT |
| E7.3 | First-assembly v1 package directory `STAGE2_EFFECTIVE_VIEW_ASSEMBLY_1_2026-10-05/` is empty; only its CORR1 package + IV1 exist | `ls` of the directory | SOURCE/RUNTIME FACT |
| E7.4 | Historical (September) chains (semantic successor CORR1–CORR3, pilot-lock conflict, pilot-lock CORR1 sourceClass withdrawal) are preserved in Workbench and superseded by the rows above | `WORKBENCH/DOWNLOADS/STAGE2_SEMANTIC_SUCCESSOR*`, `STAGE2_CORR4_PILOT_LOCK_*`, memory-corroborated lineage; not load-bearing for current state | AGENT-REPORTED FACT (historical context only) |

## E8. Classification notes

- "OWNER-ACCEPTED FACT (tree)" means the Owner-accepted CORR4 control tree records it; per AGENTS.md §5.1–5.2 the tree is the single current status map, but tree rows remain reconcilable against primary evidence — this act found **no contradiction** between E2 rows and E3–E6 primary evidence.
- Three bind-commit subjects attest acceptance; none constitutes proof (AGENTS.md §3, §14; closure governance §20). The reconciliation consequence is stated in report §5.
- The only conversational Owner decisions **physically transcribed into bound artifacts** found by this act: CORR4 contract acceptance (`STAGE2_CORR4_PILOT_VERSION_LOCK.md` §2), sourceClass STOP RULE + residuals (inside the CORR1.IV1 report), REG-007 (inside the A-E023 re-derivation report and separation candidate), the `[c1]/[c2]` partition (inside the A-E001 decisions), and the a1fcae68 controlling designation scoped to the regression act.
